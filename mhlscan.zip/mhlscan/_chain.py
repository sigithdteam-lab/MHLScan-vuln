# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_chain.py - Chained verification untuk mengurangi false positive nuclei.

Aturan: CVE dianggap VERIFIED kalau:
1. Minimal 1 template nuclei match, DAN
2. Konfirmasi tambahan via salah satu:
   - versi target cocok dengan fixed_version CVE (kalau ada)
   - 2 template match berbeda
   - _intel: EPSS >= 0.3 ATAU KEV
"""

import _intel


def _version_in_range(target_ver, fixed_ver):
    if not target_ver or not fixed_ver:
        return None
    try:
        def _parse(v):
            import re
            m = re.findall(r"\d+", str(v))
            return tuple(int(x) for x in m[:3])
        return _parse(target_ver) < _parse(fixed_ver)
    except Exception:
        return None


def verify_chain(cve_id, target_ver, matches, fixed_version=None):
    """Return dict {verified, confidence, reasons, epss, kev}.

    matches: list dict {template_id, ...}
    """
    reasons = []
    n_matches = len(matches or [])

    epss = 0.0
    kev = False
    try:
        intel = _intel.batch_enrich([cve_id], verbose=False)
        if intel:
            epss = intel[0].get("epss", 0.0)
            kev = bool(intel[0].get("kev"))
    except Exception:
        pass

    if n_matches >= 2:
        reasons.append(f"2+ nuclei matches ({n_matches})")

    ver_check = _version_in_range(target_ver, fixed_version)
    if ver_check is True:
        reasons.append(f"version {target_ver} < fixed {fixed_version}")

    if kev:
        reasons.append("CISA KEV")
    if epss >= 0.3:
        reasons.append(f"EPSS {epss:.2f}")

    verified = bool(reasons)
    confidence = "high" if len(reasons) >= 2 else ("medium" if verified else "low")

    return {
        "cve": cve_id,
        "verified": verified,
        "confidence": confidence,
        "reasons": reasons,
        "epss": epss,
        "kev": kev,
        "matches": n_matches,
    }
