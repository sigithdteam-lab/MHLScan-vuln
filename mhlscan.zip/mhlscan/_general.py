# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_general.py — Generic exposure + stack-specific checks."""

import re


SEVERITY_ORDER = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}


def _u(r):
    return r.data or b''


def _is_html(r):
    ct = (r.headers.get('Content-Type') or '').lower()
    if 'text/html' in ct:
        return True
    body = _u(r)[:2048].lower()
    return any(sig in body for sig in
               (b'<!doctype', b'<html', b'<head', b'<body', b'<?xml'))


def _check_heapdump(r):
    if r.status != 200:
        return False
    ct = (r.headers.get('Content-Type') or '').lower()
    if 'application/octet-stream' in ct:
        cl = r.headers.get('Content-Length')
        if cl:
            try:
                if int(cl) > 1000000:
                    return True
            except ValueError:
                pass
        body = _u(r)[:200]
        if body[:4] in (b'JAVA', b'\x00\x00\x00\x00'):
            return True
    return False


def _is_env(r):
    if r.status != 200 or _is_html(r):
        return False
    if len(_u(r)) > 50000:
        return False
    lines = [l for l in _u(r).splitlines()
             if re.match(rb'^\s*[A-Z_][A-Z0-9_]*\s*=', l)]
    return len(lines) >= 3


GENERIC_CHECKS = [
    {"id": "git-config", "name": ".git/config exposed",
     "path": "/.git/config", "severity": "critical",
     "test": lambda r: r.status == 200 and b'[core]' in _u(r)},
    {"id": "git-head", "name": ".git/HEAD exposed",
     "path": "/.git/HEAD", "severity": "high",
     "test": lambda r: r.status == 200 and _u(r).startswith(b'ref:')},
    {"id": "env-file", "name": ".env exposed",
     "path": "/.env", "severity": "critical",
     "test": lambda r: _is_env(r)},
    {"id": "env-prod", "name": ".env.production exposed",
     "path": "/.env.production", "severity": "critical",
     "test": lambda r: _is_env(r)},
    {"id": "htaccess", "name": ".htaccess exposed",
     "path": "/.htaccess", "severity": "medium",
     "test": lambda r: (r.status == 200 and not _is_html(r)
                        and (b'<IfModule' in _u(r)
                             or b'RewriteEngine' in _u(r)))},
    {"id": "web-config", "name": "web.config exposed",
     "path": "/web.config", "severity": "high",
     "test": lambda r: (r.status == 200 and not _is_html(r)
                        and b'<configuration' in _u(r))},
    {"id": "ds-store", "name": ".DS_Store exposed",
     "path": "/.DS_Store", "severity": "low",
     "test": lambda r: r.status == 200 and _u(r)[:8] == b'\x00\x00\x00\x01Bud'},
    {"id": "backup-sql", "name": "SQL dump exposed",
     "path": "/backup.sql", "severity": "critical",
     "test": lambda r: (r.status == 200 and not _is_html(r)
                        and b'CREATE TABLE' in _u(r))},
    {"id": "phpinfo", "name": "phpinfo() exposed",
     "path": "/phpinfo.php", "severity": "high",
     "test": lambda r: r.status == 200 and b'PHP Version' in _u(r)},
    {"id": "apache-status", "name": "Apache server-status",
     "path": "/server-status", "severity": "high",
     "test": lambda r: r.status == 200 and b'Apache Server Status' in _u(r)},
    {"id": "nginx-status", "name": "Nginx stub_status",
     "path": "/nginx_status", "severity": "medium",
     "test": lambda r: r.status == 200 and b'Active connections' in _u(r)},
    {"id": "actuator-env", "name": "Spring Actuator /env",
     "path": "/actuator/env", "severity": "high",
     "test": lambda r: r.status == 200 and b'"propertySources"' in _u(r)},
    {"id": "actuator-heapdump", "name": "Spring Actuator /heapdump",
     "path": "/actuator/heapdump", "severity": "critical",
     "test": lambda r: _check_heapdump(r)},
    {"id": "swagger-ui", "name": "Swagger UI exposed",
     "path": "/swagger-ui/index.html", "severity": "medium",
     "test": lambda r: r.status == 200 and b'swagger-ui' in _u(r).lower()},
    {"id": "api-docs", "name": "OpenAPI JSON exposed",
     "path": "/v3/api-docs", "severity": "medium",
     "test": lambda r: r.status == 200 and b'"openapi"' in _u(r)},
    {"id": "admin-panel", "name": "Admin panel terdeteksi",
     "path": "/admin", "severity": "info",
     "test": lambda r: r.status in (200, 401, 403) and len(_u(r)) > 200},
]


STACK_CHECKS = {
    "wordpress": [
        {"id": "wp-users", "name": "WordPress user enumeration",
         "path": "/wp-json/wp/v2/users", "severity": "high",
         "test": lambda r: (r.status == 200
                            and b'"slug":' in _u(r)
                            and b'"name":' in _u(r))},
        {"id": "wp-xmlrpc", "name": "WordPress XML-RPC enabled",
         "path": "/xmlrpc.php", "severity": "medium",
         "test": lambda r: (r.status == 405
                            or (r.status == 200 and b'XML-RPC server' in _u(r)))},
        {"id": "wp-debug-log", "name": "WP debug.log exposed",
         "path": "/wp-content/debug.log", "severity": "high",
         "test": lambda r: (r.status == 200 and not _is_html(r)
                            and b'PHP ' in _u(r))},
        {"id": "wp-config-bak", "name": "wp-config.php.bak exposed",
         "path": "/wp-config.php.bak", "severity": "critical",
         "test": lambda r: r.status == 200 and b'DB_PASSWORD' in _u(r)},
        {"id": "wp-readme", "name": "WordPress version (readme)",
         "path": "/readme.html", "severity": "low",
         "test": lambda r: r.status == 200 and b'WordPress' in _u(r)},
    ],
    "laravel": [
        {"id": "lara-ignition", "name": "Laravel Ignition debug",
         "path": "/_ignition/health-check", "severity": "critical",
         "test": lambda r: (r.status == 200
                            and b'can_execute_commands' in _u(r))},
        {"id": "lara-telescope", "name": "Laravel Telescope",
         "path": "/telescope", "severity": "high",
         "test": lambda r: r.status == 200 and b'telescope' in _u(r).lower()},
        {"id": "lara-log", "name": "Laravel log exposed",
         "path": "/storage/logs/laravel.log", "severity": "critical",
         "test": lambda r: (r.status == 200 and not _is_html(r)
                            and b'.ERROR' in _u(r))},
    ],
    "codeigniter": [
        {"id": "ci-db-config", "name": "CI database.php exposed",
         "path": "/application/config/database.php", "severity": "critical",
         "test": lambda r: r.status == 200 and b'db_password' in _u(r)},
    ],
    "drupal": [
        {"id": "drupal-changelog", "name": "Drupal CHANGELOG.txt",
         "path": "/CHANGELOG.txt", "severity": "low",
         "test": lambda r: r.status == 200 and b'Drupal' in _u(r)},
    ],
    "joomla": [
        {"id": "joomla-config-bak", "name": "Joomla configuration.php~",
         "path": "/configuration.php~", "severity": "critical",
         "test": lambda r: r.status == 200 and b'$password' in _u(r)},
    ],
}


def _run(url, pool, timeout, checks, min_sev):
    threshold = SEVERITY_ORDER.get(min_sev, 2)
    findings = []
    for c in checks:
        if SEVERITY_ORDER.get(c["severity"], 0) < threshold:
            continue
        try:
            r = pool.request('GET', url.rstrip('/') + c["path"],
                             timeout=timeout, redirect=False)
            if c["test"](r):
                findings.append({
                    "id": c["id"], "name": c["name"],
                    "path": c["path"], "severity": c["severity"],
                    "url": url.rstrip('/') + c["path"],
                })
        except Exception:
            pass
    return findings


def scan_generic(url, pool, timeout=3, min_sev="medium"):
    return _run(url, pool, timeout, GENERIC_CHECKS, min_sev)


def scan_stack(url, pool, stack, timeout=3, min_sev="medium"):
    checks = STACK_CHECKS.get(stack, [])
    if not checks:
        return []
    return _run(url, pool, timeout, checks, min_sev)
