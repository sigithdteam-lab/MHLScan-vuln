# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_memory.py - Tactical memory (SQLite) untuk skip CVE yang sudah terbukti gagal."""

import sqlite3
import time
from pathlib import Path

DB_PATH = Path.home() / ".mhlscan" / "memory.db"
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

TTL_SUCCESS = 7 * 86400
TTL_FAILURE = 3 * 86400


def _conn():
    c = sqlite3.connect(str(DB_PATH), timeout=10)
    c.execute("""CREATE TABLE IF NOT EXISTS cve_memory (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        stack TEXT NOT NULL,
        version TEXT NOT NULL,
        cve_id TEXT NOT NULL,
        status TEXT NOT NULL,
        evidence TEXT,
        timestamp REAL NOT NULL
    )""")
    c.execute("""CREATE INDEX IF NOT EXISTS idx_sig
                 ON cve_memory(stack, version, cve_id)""")
    c.commit()
    return c


def signature(stack, version, cve_id):
    return f"{stack or ''}|{version or ''}|{cve_id or ''}"


def remember(stack, version, cve_id, status, evidence=""):
    """status: 'success' | 'failure'"""
    try:
        c = _conn()
        c.execute(
            "INSERT INTO cve_memory (stack, version, cve_id, status, evidence, timestamp) "
            "VALUES (?,?,?,?,?,?)",
            (stack or "", version or "", cve_id or "", status,
             (evidence or "")[:500], time.time())
        )
        c.commit()
        c.close()
    except Exception:
        pass


def recall(stack, version, cve_id):
    """Return dict {status, evidence, age_sec} atau None."""
    try:
        c = _conn()
        cur = c.execute(
            "SELECT status, evidence, timestamp FROM cve_memory "
            "WHERE stack=? AND version=? AND cve_id=? "
            "ORDER BY id DESC LIMIT 1",
            (stack or "", version or "", cve_id or "")
        )
        row = cur.fetchone()
        c.close()
        if not row:
            return None
        status, evidence, ts = row
        age = time.time() - ts
        ttl = TTL_SUCCESS if status == "success" else TTL_FAILURE
        if age > ttl:
            return None
        return {"status": status, "evidence": evidence, "age_sec": int(age)}
    except Exception:
        return None


def should_skip(stack, version, cve_id):
    """True kalau CVE sudah terbukti gagal verify dalam TTL."""
    r = recall(stack, version, cve_id)
    return bool(r and r["status"] == "failure")


def known_success(stack, version, cve_id):
    r = recall(stack, version, cve_id)
    return bool(r and r["status"] == "success")


def stats():
    try:
        c = _conn()
        cur = c.execute(
            "SELECT status, COUNT(*) FROM cve_memory GROUP BY status"
        )
        rows = dict(cur.fetchall())
        c.close()
        return {"success": rows.get("success", 0),
                "failure": rows.get("failure", 0)}
    except Exception:
        return {"success": 0, "failure": 0}


def prune():
    """Hapus entry yang sudah lewat TTL."""
    try:
        c = _conn()
        now = time.time()
        c.execute("DELETE FROM cve_memory WHERE "
                  "(status='success' AND ? - timestamp > ?) OR "
                  "(status='failure' AND ? - timestamp > ?)",
                  (now, TTL_SUCCESS, now, TTL_FAILURE))
        c.commit()
        c.close()
    except Exception:
        pass
