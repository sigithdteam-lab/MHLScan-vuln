# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_geoip.py - Ambil sampel IP publik berdasarkan kode negara (IPDeny)."""
import urllib.request
import ipaddress
import random

BASE_URL = "https://www.ipdeny.com/ipblocks/data/countries/{cc}.zone"


def get_ips_by_country(country_code, limit=100):
    cc = country_code.lower().strip()
    url = BASE_URL.format(cc=cc)

    print(f"  [*] Mengunduh data CIDR untuk negara {cc.upper()} dari IPDeny...")
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=15) as r:
            content = r.read().decode('utf-8')
    except Exception as e:
        print(f"  [-] Gagal mengambil data: {e}")
        return []

    cidrs = content.split()
    if not cidrs:
        print(f"  [-] Data kosong untuk kode negara {cc.upper()}")
        return []

    print(f"  [+] Ditemukan {len(cidrs)} blok CIDR. Memilih {limit} IP acak...")

    ips = set()
    random.shuffle(cidrs)

    for cidr in cidrs:
        if len(ips) >= limit:
            break
        try:
            net = ipaddress.ip_network(cidr, strict=False)
            hosts_count = net.num_addresses - 2
            if hosts_count <= 0:
                continue
            sample_count = min(3, hosts_count)
            for _ in range(sample_count):
                offset = random.randint(1, hosts_count)
                ip = net.network_address + offset
                ips.add(str(ip))
                if len(ips) >= limit:
                    break
        except Exception:
            pass

    return list(ips)
