# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_sqlscan.py - SQL injection scanner (sqlmap + sqlmap API + fallback).

Wrapper:
1. sqlmap (kalau terinstall) --level 1 --risk 1 --batch, tanpa --forms/--crawl default
2. sqlmap API (kalau user jalankan `python3 sqlmapapi.py -s`) untuk async scan
3. Fallback: deteksi error-based SQLi sederhana (tanpa sqlmap) -- "--'" probe
"""

import json
import re
import shutil
import subprocess
import tempfile
import time


def _has_sqlmap():
    return shutil.which("sqlmap") is not None


def _has_sqlmap_api():
    """Cek port default sqlmapapi 8775."""
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1.0)
        if s.connect_ex(("127.0.0.1", 8775)) == 0:
            s.close()
            return True
        s.close()
    except Exception:
        pass
    return False


def _parse_sqlmap_output(stdout):
    result = {
        "vulnerable": False,
        "dbms": None,
        "injectable_params": [],
        "techniques": [],
        "databases": [],
        "raw_tail": "",
    }
    if not stdout:
        return result
    try:
        if re.search(r"Parameter:\s*\S+\s*\([^)]+\)\s*is vulnerable", stdout, re.I):
            result["vulnerable"] = True
        elif re.search(r"is vulnerable", stdout, re.I):
            result["vulnerable"] = True

        for m in re.finditer(r"Parameter:\s*(\S+)\s*\(([^)]+)\)", stdout):
            result["injectable_params"].append(
                {"param": m.group(1), "type": m.group(2)})

        m = re.search(r"back-end DBMS:\s*(.+)", stdout, re.I)
        if m:
            result["dbms"] = m.group(1).strip()

        m = re.search(r"available databases \[\d+\]:(.*?)(?:\n\n|\Z)",
                      stdout, re.S)
        if m:
            for line in m.group(1).splitlines():
                v = line.strip().lstrip("[*]").strip()
                if v:
                    result["databases"].append(v)

        m = re.search(r"Types?:\s*(.+)", stdout, re.I)
        if m:
            result["techniques"] = [t.strip() for t in m.group(1).split(",")]

        result["raw_tail"] = stdout[-800:]
    except Exception:
        pass
    return result


def _run_sqlmap(url, data=None, params=None, level=1, risk=1, timeout=300):
    if not _has_sqlmap():
        return None
    out_dir = tempfile.mkdtemp(prefix="mhl_sqlmap_")
    args = [
        "sqlmap", "-u", url,
        "--batch", "--disable-coloring",
        "--level", str(level), "--risk", str(risk),
        "--smart", "--threads", "1",
        f"--output-dir={out_dir}",
        "--flush-session",
        "--timeout", "10",
        "--retries", "1",
        "--answers", "follow=N,redirect=N,crawl=N",
    ]
    if data:
        args += ["--data", data]
    if params:
        args += ["-p", params]

    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        out = (r.stdout or "") + "\n" + (r.stderr or "")
        return _parse_sqlmap_output(out)
    except subprocess.TimeoutExpired:
        return {"error": "timeout", "vulnerable": False}
    except Exception as e:
        return {"error": str(e), "vulnerable": False}


def _check_error_based(url, param, timeout=10):
    """Fallback: deteksi error-based SQLi via quote injection."""
    import requests
    try:
        requests.packages.urllib3.disable_warnings()
    except Exception:
        pass
    signatures = [
        r"SQL syntax.*MySQL",
        r"Warning.*mysql_",
        r"PostgreSQL.*ERROR",
        r"ORA-\d{5}",
        r"Microsoft OLE DB Provider for ODBC Drivers",
        r"Microsoft SQL Native Client error",
        r"ODBC SQL Server Driver",
        r"SQLite/JDBCDriver",
        r"System\.Data\.SQLite\.SQLiteException",
        r"Unclosed quotation mark",
        r"quoted string not properly terminated",
    ]
    payloads = ["'", "\"", "')", "\")", "';--", "\";--"]
    try:
        sep = "&" if "?" in url else "?"
        for p in payloads:
            test_url = f"{url}{sep}{param}={requests.utils.quote(p)}"
            try:
                r = requests.get(test_url, timeout=timeout, verify=False)
            except Exception:
                continue
            for sig in signatures:
                if re.search(sig, r.text, re.I):
                    return {
                        "vulnerable": True,
                        "param": param,
                        "payload": p,
                        "evidence": f"Error signature: {sig}",
                        "technique": "error-based (fallback)",
                    }
    except Exception:
        pass
    return {"vulnerable": False}


def scan_sqli(url, params=None, data=None, use_sqlmap=True, use_fallback=True,
              timeout=300):
    """Return dict {vulnerable, method, details, injectable_params, dbms}."""
    if not url:
        return {"vulnerable": False, "method": None, "details": "no url"}

    url_params = []
    if params:
        url_params = [p.strip() for p in params.split(",") if p.strip()]
    else:
        from urllib.parse import urlparse, parse_qs
        qs = urlparse(url).query
        url_params = list(parse_qs(qs).keys())

    # 1. sqlmap
    if use_sqlmap and _has_sqlmap():
        r = _run_sqlmap(url, data=data, params=params, timeout=timeout)
        if r and r.get("vulnerable"):
            return {
                "vulnerable": True,
                "method": "sqlmap",
                "injectable_params": r.get("injectable_params", []),
                "dbms": r.get("dbms"),
                "techniques": r.get("techniques", []),
                "databases": r.get("databases", []),
            }
        if r and not r.get("error"):
            # sqlmap sudah jalan dan tidak menemukan, tapi coba fallback
            pass

    # 2. Fallback error-based
    if use_fallback and url_params:
        for p in url_params[:5]:
            res = _check_error_based(url, p, timeout=15)
            if res.get("vulnerable"):
                return {
                    "vulnerable": True,
                    "method": "fallback-error-based",
                    "injectable_params": [{"param": res["param"],
                                           "type": res.get("technique")}],
                    "evidence": res.get("evidence"),
                }

    return {"vulnerable": False, "method": None}
