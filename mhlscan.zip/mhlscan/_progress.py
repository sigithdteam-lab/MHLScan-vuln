# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_progress.py - Clean single-line progress bar."""

import sys
import time


class Progress:
    def __init__(self, total, label="", width=30, enabled=True):
        self.total = total
        self.label = label
        self.width = width
        self.enabled = enabled
        self.start = time.time()
        self.last_pct = -1

    def update(self, current, extra=""):
        if not self.enabled:
            return
        pct = current / self.total if self.total else 0
        pct_int = int(pct * 100)
        if pct_int == self.last_pct and not extra:
            return
        self.last_pct = pct_int

        filled = int(self.width * pct)
        bar = "#" * filled + "-" * (self.width - filled)
        elapsed = time.time() - self.start
        eta = (elapsed / current * (self.total - current)) if current > 0 else 0

        label = (self.label + " ") if self.label else ""
        line = f"\r  {label}[{bar}] {current}/{self.total} ({pct_int}%) ETA {eta:.0f}s"
        if extra:
            line += " " + extra
        sys.stdout.write(line[:160])  # truncate, avoid terminal wrap
        sys.stdout.flush()

    def done(self, msg=""):
        if not self.enabled:
            return
        sys.stdout.write("\r" + " " * 120 + "\r")
        if msg:
            sys.stdout.write(msg + "\n")
        sys.stdout.flush()
