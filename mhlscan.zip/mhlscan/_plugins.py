# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_plugins.py — Deteksi plugin/ekstensi untuk WordPress, Joomla, Drupal."""

import re
from concurrent.futures import ThreadPoolExecutor, as_completed


WP_PLUGINS = [
    "woocommerce", "woocommerce-subscriptions", "woocommerce-memberships",
    "woocommerce-bookings", "easy-digital-downloads",
    "contact-form-7", "wpforms-lite", "gravityforms", "ninja-forms",
    "formidable", "fluentform",
    "wordpress-seo", "all-in-one-seo-pack", "seo-by-rank-math",
    "autodescription",
    "elementor", "elementor-pro", "js_composer", "siteorigin-panels",
    "beaver-builder-lite-version", "fusion-builder", "divi-builder",
    "wpbakery",
    "wordfence", "better-wp-security", "all-in-one-wp-security-and-firewall",
    "sucuri-scanner", "limit-login-attempts-reloaded",
    "updraftplus", "duplicator", "all-in-one-wp-migration",
    "wpvivid-backuprestore", "backwpup", "backup",
    "w3-total-cache", "wp-super-cache", "litespeed-cache",
    "wp-rocket", "autoptimize", "wp-optimize",
    "memberpress", "restrict-content-pro", "paid-memberships-pro",
    "learnpress", "tutor", "lifterlms",
    "mailchimp-for-wp", "monsterinsights", "optinmonster",
    "wpforms", "hubspot",
    "revslider", "layerslider", "essential-grid", "ml-slider",
    "nextgen-gallery", "envira-gallery-lite",
    "wp-file-manager", "duplicator-pro", "wpdiscuz", "user-registration",
    "advanced-custom-fields", "acf", "tablepress", "wpdatatables",
    "events-calendar-pro", "the-events-calendar", "bbpress",
    "buddypress", "wpml", "polylang", "redirection",
    "classic-editor", "akismet", "jetpack", "wp-mail-smtp",
    "tinymce-advanced", "cookie-law-info", "complianz-gdpr",
    "smush", "wordpress-popular-posts", "wp-statistics",
]

JOOMLA_COMPONENTS = [
    "com_akeeba", "com_admintools", "com_jce", "com_virtuemart",
    "com_k2", "com_djclassifieds", "com_easyblog", "com_easydiscuss",
    "com_community", "com_jomsocial", "com_sobipro", "com_hikashop",
    "com_jshopping", "com_eshop", "com_rsform", "com_rsdirectory",
    "com_phocadownload", "com_phocagallery", "com_docman",
    "com_jdownloads", "com_fabrik", "com_zoo", "com_mijoshop",
    "com_eventbooking", "com_jevents", "com_attachments",
    "com_oscommerce", "com_aicontactsafe", "com_jbusinessdirectory",
]

JOOMLA_MODULES = [
    "mod_custom", "mod_menu", "mod_login", "mod_search",
    "mod_breadcrumbs", "mod_articles_popular", "mod_articles_latest",
    "mod_articles_news", "mod_footer", "mod_languages",
    "mod_random_image", "mod_stats", "mod_syndicate",
    "mod_tags_popular", "mod_tags_similar", "mod_whosonline",
    "mod_wrapper", "mod_vvisit_counter",
]

DRUPAL_MODULES = [
    "views", "ctools", "token", "pathauto", "metatag",
    "webform", "admin_menu", "backup_migrate", "devel",
    "google_analytics", "imce", "entity", "field_group",
    "rules", "wysiwyg", "ckeditor", "captcha", "recaptcha",
    "composer_manager", "honeypot", "antibot", "password_policy",
    "reroute_email", "simplesamlphp_auth", "rest", "services",
    "feeds", "migrate_plus", "paragraphs", "entity_reference_revisions",
    "api_key_manager", "config_split", "config_ignore",
]

_PLUGIN_CACHE = {}


def _probe_wp_plugin(pool, url, slug, timeout):
    base = url.rstrip('/')
    for path in (f"/wp-content/plugins/{slug}/readme.txt",
                 f"/wp-content/plugins/{slug}/README.txt"):
        try:
            r = pool.request('GET', base + path, timeout=timeout,
                             redirect=False)
            if r.status in (200, 301, 302):
                text = (r.data or b'')[:16384].decode('utf-8', 'ignore')
                version = None
                m = re.search(r'Stable tag:\s*([\d.]+)', text, re.I)
                if not m:
                    m = re.search(r'Version:\s*([\d.]+)', text, re.I)
                if m:
                    version = m.group(1)
                return {"slug": slug, "path": path, "version": version,
                        "evidence": "readme.txt"}
        except Exception:
            pass

    path = f"/wp-content/plugins/{slug}/"
    try:
        r = pool.request('GET', base + path, timeout=timeout, redirect=False)
        if r.status in (200, 301, 403):
            return {"slug": slug, "path": path, "version": None,
                    "evidence": "dir"}
    except Exception:
        pass
    return None


def _probe_joomla_component(pool, url, comp, timeout):
    base = url.rstrip('/')
    for path in (f"/administrator/manifests/libraries/{comp}.xml",
                 f"/administrator/manifests/files/{comp}.xml",
                 f"/components/{comp}/{comp}.xml"):
        try:
            r = pool.request('GET', base + path, timeout=timeout,
                             redirect=False)
            if r.status in (200, 301, 302):
                text = (r.data or b'')[:8192].decode('utf-8', 'ignore')
                m = re.search(r'<version>\s*([\d.]+)\s*</version>', text)
                version = m.group(1) if m else None
                return {"slug": comp, "path": path, "version": version,
                        "evidence": "manifest.xml"}
        except Exception:
            pass

    path = f"/components/{comp}/"
    try:
        r = pool.request('GET', base + path, timeout=timeout, redirect=False)
        if r.status in (200, 301, 403):
            return {"slug": comp, "path": path, "version": None,
                    "evidence": "dir"}
    except Exception:
        pass
    return None


def _probe_joomla_module(pool, url, mod, timeout):
    base = url.rstrip('/')
    path = f"/modules/{mod}/{mod}.xml"
    try:
        r = pool.request('GET', base + path, timeout=timeout, redirect=False)
        if r.status in (200, 301, 302):
            text = (r.data or b'')[:8192].decode('utf-8', 'ignore')
            m = re.search(r'<version>\s*([\d.]+)\s*</version>', text)
            version = m.group(1) if m else None
            return {"slug": mod, "path": path, "version": version,
                    "evidence": "manifest.xml"}
    except Exception:
        pass
    return None


def _probe_drupal_module(pool, url, mod, timeout):
    base = url.rstrip('/')
    paths = (
        (f"/modules/contrib/{mod}/{mod}.info.yml", "yml"),
        (f"/modules/{mod}/{mod}.info.yml", "yml"),
        (f"/sites/all/modules/{mod}/{mod}.info", "d7"),
        (f"/modules/contrib/{mod}/{mod}.info", "d7"),
    )
    for path, fmt in paths:
        try:
            r = pool.request('GET', base + path, timeout=timeout,
                             redirect=False)
            if r.status not in (200, 301, 302):
                continue
            text = (r.data or b'')[:8192].decode('utf-8', 'ignore')
            if fmt == "yml":
                m = re.search(r"version:\s*['\"]?([\d.x\-]+)['\"]?", text)
            else:
                m = re.search(r'version\s*=\s*([\d.x\-]+)', text)
            version = m.group(1) if m else None
            return {"slug": mod, "path": path, "version": version,
                    "evidence": f"info.{fmt}"}
        except Exception:
            pass
    return None


def detect_plugins(url, pool, stack, timeout=5, max_workers=20):
    global _PLUGIN_CACHE
    from urllib.parse import urlparse
    host = urlparse(url).hostname
    cache_key = f"{host}:{stack}"
    if cache_key in _PLUGIN_CACHE:
        return _PLUGIN_CACHE[cache_key]

    found = []
    workers = max_workers
    probe_timeout = min(timeout, 2)

    with ThreadPoolExecutor(max_workers=workers) as ex:
        futures = []
        if stack == "wordpress":
            for slug in WP_PLUGINS:
                futures.append(ex.submit(_probe_wp_plugin, pool, url, slug, probe_timeout))
        elif stack == "joomla":
            for comp in JOOMLA_COMPONENTS:
                futures.append(ex.submit(_probe_joomla_component, pool, url, comp, probe_timeout))
            for mod in JOOMLA_MODULES:
                futures.append(ex.submit(_probe_joomla_module, pool, url, mod, probe_timeout))
        elif stack == "drupal":
            for mod in DRUPAL_MODULES:
                futures.append(ex.submit(_probe_drupal_module, pool, url, mod, probe_timeout))
        else:
            return []

        for fut in as_completed(futures):
            try:
                result = fut.result()
                if result:
                    found.append(result)
            except Exception:
                pass

    found = sorted(found, key=lambda x: x["slug"])
    _PLUGIN_CACHE[cache_key] = found
    return found
