# GNU GPL License V3
# mhlscan by sigit-hdteamlabs

# -*- coding: utf-8 -*-
"""CVE-2023-20198 - Cisco IOS XE Web UI Privilege Escalation."""

import re
import urllib3

from ._base import cve_module

urllib3.disable_warnings()


@cve_module(
    cve_id="CVE-2023-20198",
    name="Cisco IOS XE Web UI Privilege Escalation",
    severity="critical",
    requires=["http"],
    timeout=10,
    description="Unauthorized account creation via Web UI",
)
def test(url, timeout=10, oast_url=None, **kwargs):
    import requests

    if not url.startswith("http"):
        url = "http://" + url

    try:
        r = requests.post(
            url.rstrip("/") + "/webui/logoutconfirm.html?logon_hash=1",
            data="abcdef",
            timeout=timeout,
            verify=False,
            headers={"User-Agent": "Mozilla/5.0"},
        )

        server = r.headers.get("Server", "").lower()
        if "cisco" not in server:
            return {"status": "not_vulnerable",
                    "details": f"Bukan Cisco (Server: {server[:50]})"}

        body = (r.text or "").strip()
        if re.fullmatch(r'[0-9a-fA-F]{18}', body):
            return {
                "status": "vulnerable",
                "details": "Cisco IOS XE vulnerable",
                "evidence": f"18-char hash: {body}",
                "endpoint": "/webui/logoutconfirm.html",
            }

        return {"status": "not_vulnerable"}
    except Exception as e:
        return {"status": "unknown", "details": type(e).__name__}