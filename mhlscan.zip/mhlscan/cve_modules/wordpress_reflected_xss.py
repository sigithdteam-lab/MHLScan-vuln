# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""WordPress Reflected XSS detection (search page)."""
import re
import uuid
import requests
import urllib3

from ._base import cve_module

urllib3.disable_warnings()


@cve_module(
    cve_id="WP-REFLECTED-XSS",
    name="WordPress Reflected XSS (search)",
    severity="high",
    requires=["wordpress"],
    timeout=20,
    description="Cek reflected XSS via ?s= parameter",
    aggressive=False,
)
def test(url, timeout=20, oast_url=None, **kwargs):
    base = url.rstrip("/")
    marker = "MHL_" + uuid.uuid4().hex[:8]
    payload = f'<img src=x onerror="window.__xss_{marker}=true">'

    try:
        r = requests.get(base + "/",
                         params={"s": payload},
                         timeout=timeout, verify=False)
        if payload in r.text:
            return {
                "status": "vulnerable",
                "details": "Reflected XSS confirmed (payload raw in response)",
                "evidence": f"Payload: {payload}",
                "endpoint": "/?s=",
            }
        if marker in r.text:
            return {
                "status": "not_vulnerable",
                "details": "Marker reflected but escaped",
            }
        return {"status": "not_vulnerable", "details": "Marker not found"}
    except Exception as e:
        return {"status": "error", "details": type(e).__name__ + ": " + str(e)}