# GNU GPL License V3
# mhlscan by sigit-hdteamlabs

# -*- coding: utf-8 -*-
"""cve_modules/_base.py - Registry + decorator untuk CVE plugins."""

CVE_MODULES = {}


def cve_module(cve_id, name, severity="high", requires=None,
               timeout=15, description="", aggressive=False, stub=False):
    def decorator(fn):
        CVE_MODULES[cve_id] = {
            "id": cve_id,
            "name": name,
            "severity": severity,
            "requires": requires or [],
            "timeout": timeout,
            "description": description,
            "aggressive": aggressive,
            "stub": stub,
            "test": fn,
            "source": fn.__module__,
        }
        return fn
    return decorator


def get_modules():
    return dict(CVE_MODULES)


def disable(cve_id):
    if cve_id in CVE_MODULES:
        CVE_MODULES[cve_id]["disabled"] = True
        return True
    return False


def enable(cve_id):
    if cve_id in CVE_MODULES:
        CVE_MODULES[cve_id]["disabled"] = False
        return True
    return False


def is_disabled(cve_id):
    return CVE_MODULES.get(cve_id, {}).get("disabled", False)