# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""CVE-2016-3714 - ImageMagick ImageTragick RCE."""

from ._base import cve_module

try:
    from _imagemagick import test_cve_2016_3714 as _im_test
except ImportError:
    _im_test = None


@cve_module(
    cve_id="CVE-2016-3714",
    name="ImageMagick ImageTragick RCE",
    severity="high",
    requires=["upload_endpoint"],
    timeout=15,
    description="GhostScript command injection via SVG/image processing",
)
def test(url, timeout=15, oast_url=None, **kwargs):
    if _im_test is None:
        return {"status": "error", "details": "_imagemagick.py not found"}

    im_result = _im_test(url, oast_url=oast_url, timeout=timeout)

    if im_result["status"] == "potential":
        sev = "high" if im_result.get("vulnerable_version") else "medium"
        endpoint = (im_result["upload_endpoints"][0]["path"]
                    if im_result.get("upload_endpoints") else "/")
        return {
            "status": "potential",
            "severity": sev,
            "details": "ImageMagick " + str(im_result.get("imagemagick_version") or "?"),
            "evidence": " | ".join(im_result.get("evidence", [])),
            "endpoint": endpoint,
            "payload_file": im_result.get("payload_file"),
            "upload_endpoints": im_result.get("upload_endpoints", []),
            "imagemagick_version": im_result.get("imagemagick_version"),
        }

    return {
        "status": im_result["status"],
        "details": " | ".join(im_result.get("evidence", [])),
        "imagemagick_version": im_result.get("imagemagick_version"),
    }
