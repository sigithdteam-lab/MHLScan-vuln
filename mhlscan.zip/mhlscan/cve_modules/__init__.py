# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""cve_modules - CVE plugin registry with auto-discovery."""

import os
import importlib
from pathlib import Path

from ._base import CVE_MODULES, cve_module, get_modules, disable, enable, is_disabled


RED    = '\033[91m'
GREEN  = '\033[32m'
YELLOW = '\033[1;33m'
CYAN   = '\033[96m'
ENDC   = '\033[0m'


def discover():
    module_dir = Path(__file__).parent
    loaded = 0
    for f in sorted(module_dir.glob("*.py")):
        if f.name in ("__init__.py", "_base.py"):
            continue
        mod_name = f.stem
        try:
            importlib.import_module("cve_modules." + mod_name)
            loaded += 1
        except Exception as e:
            print(f"  {YELLOW}[!] cve_modules/{f.name}: {type(e).__name__}: {e}{ENDC}")
    return loaded


def run_all(url, timeout=15, oast_url=None, context=None, enable_aggressive=False):
    findings = []
    context = context or {}
    safe_context = {k: v for k, v in context.items()
                    if k not in ("url", "timeout", "oast_url")}

    for cve_id, module in CVE_MODULES.items():
        if module.get("disabled"):
            continue
        if module.get("aggressive") and not enable_aggressive:
            continue

        mod_timeout = module.get("timeout", timeout)
        try:
            result = module["test"](
                url, timeout=mod_timeout, oast_url=oast_url, **safe_context
            )
        except TypeError:
            try:
                result = module["test"](url, timeout=mod_timeout, oast_url=oast_url)
            except Exception as e:
                result = {"status": "error", "details": str(e)}
        except Exception as e:
            result = {"status": "error", "details": type(e).__name__ + ": " + str(e)}

        if not result:
            continue
        status = result.get("status", "unknown")
        if status not in ("vulnerable", "potential"):
            continue

        finding = {
            "id": cve_id,
            "name": module["name"],
            "severity": module["severity"],
            "type": "cve-plugin",
            "url": url,
            "endpoint": result.get("endpoint", url),
            "evidence": result.get("evidence", result.get("details", "")),
            "source": "cve_modules",
            "module": module["source"],
            "verified": (status == "vulnerable"),
            "confidence": status,
        }

        for key in ("payload_file", "upload_endpoints",
                    "imagemagick_version", "version", "details",
                    "priority_score"):
            if key in result:
                finding[key] = result[key]

        findings.append(finding)

    return findings


def list_modules(verbose=True):
    if not CVE_MODULES:
        print("  (tidak ada CVE module)")
        return

    print(f"  {CYAN}Registered CVE modules: {len(CVE_MODULES)}{ENDC}")
    for cve_id, m in sorted(CVE_MODULES.items()):
        status = "DISABLED" if m.get("disabled") else "active"
        stub_tag = "[STUB] " if m.get("stub") else ""
        reqs = ",".join(m["requires"]) if m["requires"] else "-"
        print(f"    {m['severity']:<8} {cve_id:<20} {stub_tag}{m['name'][:40]:<40} "
              f"[{status}] req={reqs}")


_loaded = discover()