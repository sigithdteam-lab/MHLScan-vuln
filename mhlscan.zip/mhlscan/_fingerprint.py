# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_fingerprint.py — Global stack detection (6 layers)."""

import re

SIGNATURES = SIGNATURES = {
    "jboss":       [(r"jboss|wildfly", "header:server"),
                    (r"jboss\.system", "body")],
    "tomcat":      [(r"apache-coyote|tomcat", "header:server")],
    "wso2":        [(r"wso2", "header:server")],
    "wordpress":   [(r"wp-content|wp-json|wp-includes|wp-block-library|wp-emoji|wp-settings", "body"),
                    (r"wordpress", "header:x-generator")],
    "joomla":      [(r"joomla|/media/system/js/", "body")],
    "drupal":      [(r"drupal", "header:x-generator"),
                    (r"sites/default/files|drupal\.js|drupal-settings-json", "body")],
    "laravel":     [(r"laravel_session|xsrf-token", "header:set-cookie")],
    "codeigniter": [(r"ci_session", "header:set-cookie")],
    "magento":     [(r"magento|mage/cookies", "header:set-cookie")],
    "prestashop":  [(r"prestashop", "body"),
                    (r"prestashop", "header:set-cookie")],
    "opencart":    [(r"opencart|catalog/view/theme", "body")],
    "ghost":       [(r"ghost/|content=\"Ghost", "body")],
    "typo3":       [(r"typo3|typo3conf", "body")],
    "concrete5":   [(r"concrete5|concrete/js", "body")],
    "modx":        [(r"modx|/manager/assets/", "body")],
    "bitrix":      [(r"bitrix|/bitrix/", "body")],
    "umbraco":     [(r"umbraco", "body")],
    "kentico":     [(r"kentico", "body")],
    "sitecore":    [(r"sitecore|/sitecore/", "body")],
    "sharepoint":  [(r"sharepoint|microsoftsharepoint", "header:server")],
    "liferay":     [(r"liferay", "body"),
                    (r"liferay", "header:server")],
    "alfresco":    [(r"alfresco|/share/", "body")],
    "plone":       [(r"plone|/acl_users/", "body")],
    "octobercms":  [(r"octobercms|october cms", "body")],
    "spring":      [(r"whitelabel error page|/actuator", "body"),
                    (r"spring", "header:x-application-context")],
    "nextjs":      [(r"__next_data__|__next", "body")],
    "nuxt":        [(r"__nuxt__|nuxt-link", "body")],
    "express":     [(r"express", "header:x-powered-by")],
    "django":      [(r"csrfmiddlewaretoken", "body"),
                    (r"django", "header:server")],
    "rails":       [(r"_rails_session|rails", "header:set-cookie"),
                    (r"x-runtime", "header:x-runtime")],
    "php":         [(r"php", "header:x-powered-by")],
    "aspnet":      [(r"asp\.net", "header:x-powered-by"),
                    (r"aspnet_sessionid", "header:set-cookie")],
    "iis":         [(r"microsoft-iis", "header:server")],
    "nginx":       [(r"^nginx", "header:server")],
    "apache":      [(r"^apache", "header:server")],
    "cloudflare":  [(r"cloudflare", "header:server")],
    "mikrotik_routeros": [(r"routeros|mikrotik|webfig", "body"),
                          (r"mikrotik", "header:server")],
    "cisco_ios_xe":      [(r"ciscowebui|ios-xe|cisco.*ios", "body"),
                          (r"cisco", "header:server")],
    "juniper_junos":     [(r"juniper|junos|jweb", "body"),
                          (r"juniper", "header:server")],
    "huawei":            [(r"huawei|quidway|echolife", "body")],
    "fortinet_fortigate":[(r"fortinet|fortigate|fortiweb", "body")],
    "paloalto_panos":    [(r"palo alto|panos|global-protect", "body")],
    "edgecore":          [(r"edge[- ]?core|edgecore", "body")],
    "openwrt":           [(r"openwrt|luci", "body")],
    "pfsense":           [(r"pfsense", "body")],
    "arista_eos":        [(r"arista", "body")],
    "ubiquiti":          [(r"ubiquiti|unifi|airmax", "body")],
    "tp_link":           [(r"tp-link", "body")],
    "zte":               [(r"zte|zxhn", "body")],

    "traefik":     [(r"traefik", "any")],
    "mlflow":      [(r"mlflow", "body"), (r"mlflow", "header:server")],
    "lollms":      [(r"lollms", "body")],
    "openflagr":   [(r"flagr", "body"), (r"openflagr", "body")],
    "gitlab":      [(r"gitlab", "body"), (r"gitlab", "header:server")],
    "jenkins":     [(r"jenkins", "body"), (r"x-jenkins", "header:x-jenkins")],
    "grafana":     [(r"grafana", "body"), (r"grafana", "header:server")],
    "kibana":      [(r"kibana", "body")],
    "jira":        [(r"jira", "body"), (r"atlassian", "header:server")],
    "confluence":  [(r"confluence", "body"), (r"atlassian", "header:server")],
    "bitbucket":   [(r"bitbucket", "body")],
    "sharepoint":  [(r"sharepoint", "header:server"), (r"microsoftsharepoint", "header:server")],
    "exchange":    [(r"exchange", "body"), (r"owa", "body")],
    "citrix":      [(r"citrix", "body"), (r"netscaler", "body"), (r"citrix_ns_id", "header:set-cookie")],
    "ivanti":      [(r"ivanti", "body"), (r"pulse secure", "body")],
    "sonicwall":   [(r"sonicwall", "body")],
    "screenconnect": [(r"screenconnect", "body"), (r"connectwise", "body")],
    "zabbix":      [(r"zabbix", "body")],
    "pandora":     [(r"pandora", "body"), (r"pandorafms", "body")],
    "nagios":      [(r"nagios", "body")],
    "solarwinds":  [(r"solarwinds", "body")],
    "vmware_vcenter": [(r"vsphere", "body"), (r"vcenter", "body")],
    "vmware_esxi": [(r"esxi", "body"), (r"vmware", "header:server")],
    "proxmox":     [(r"proxmox", "body")],
    "apache_camel": [(r"camel", "body")],
    "apache_activemq": [(r"activemq", "body")],
    "apache_druid": [(r"druid", "body")],
    "apache_hadoop": [(r"hadoop", "body"), (r"yarn", "body")],
    "apache_nifi": [(r"nifi", "body")],
    "apache_ofbiz": [(r"ofbiz", "body")],
    "apache_solr": [(r"solr", "body")],
    "apache_storm": [(r"storm", "body")],
    "apache_struts": [(r"struts", "body")],
    "apache_superset": [(r"superset", "body")],
    "apache_zeppelin": [(r"zeppelin", "body")],
    "atlassian":   [(r"atlassian", "any")],
    "autodesk":    [(r"autodesk", "body")],
    "cisco_sd_wan": [(r"vmanage", "body"), (r"sd-wan", "body")],
    "citrix_sharefile": [(r"sharefile", "body")],
    "d-link":      [(r"d-link", "body"), (r"dlink", "body")],
    "dell":        [(r"dell", "body")],
    "f5_bigip":    [(r"bigip", "body"), (r"big-ip", "body")],
    "hpe":         [(r"aruba", "body"), (r"hpe", "body")],
    "ibm":         [(r"ibm", "body"), (r"websphere", "body")],
    "lenovo":      [(r"lenovo", "body")],
    "netgear":     [(r"netgear", "body")],
    "oracle":      [(r"oracle", "body"), (r"weblogic", "body")],
    "paloalto_globalprotect": [(r"globalprotect", "body")],
    "progress":    [(r"progress", "body"), (r"moveit", "body")],
    "pulse_secure": [(r"pulse secure", "body"), (r"pulse", "body")],
    "qnap":        [(r"qnap", "body")],
    "samsung":     [(r"samsung", "body")],
    "sap":         [(r"sap", "body"), (r"netweaver", "body")],
    "synology":    [(r"synology", "body"), (r"dsm", "body")],
    "veeam":       [(r"veeam", "body")],
    "xerox":       [(r"xerox", "body")],
    "zyxel":       [(r"zyxel", "body")],

}

PRIORITY = [
    "mikrotik_routeros", "cisco_ios_xe", "juniper_junos",
    "huawei", "fortinet_fortigate", "paloalto_panos",
    "edgecore", "openwrt", "pfsense", "arista_eos",
    "ubiquiti", "tp_link", "zte",
    "sharepoint", "alfresco", "liferay", "octobercms",
    "prestashop", "opencart", "typo3", "concrete5", "modx",
    "bitrix", "umbraco", "kentico", "sitecore", "plone", "ghost",
    "jboss", "tomcat", "wso2", "spring", "wordpress", "laravel",
    "codeigniter", "drupal", "joomla", "magento", "nextjs", "nuxt",
    "django", "rails", "express", "aspnet", "php", "iis",
    "nginx", "apache", "cloudflare",
]

# Cookie signatures — sangat akurat untuk framework
COOKIE_SIGNATURES = {
    "wordpress":   ["wordpress_test_cookie", "wp-settings-", "wordpress_logged_in"],
    "laravel":     ["laravel_session", "xsrf-token"],
    "drupal":      ["sess", "ssess"],
    "joomla":      ["joomla_session", "joomla_user_state"],
    "codeigniter": ["ci_session", "csrf_cookie_name"],
    "django":      ["csrftoken", "sessionid"],
    "rails":       ["_session_id", "_rails_session"],
    "magento":     ["frontend", "adminhtml"],
    "php":         ["phpsessid"],
    "aspnet":      ["asp.net_sessionid", "aspxauth"],
}

# Active probes — SEMUA stack yang punya endpoint khas
ACTIVE_PROBES = {
    "wordpress": [
        ("/wp-login.php", b"wp-submit"),
        ("/wp-json/", b"namespaces"),
        ("/?rest_route=/", b"description"),
        ("/wp-includes/js/wp-emoji-release.min.js", b"wpemoji"),
        ("/wp-sitemap.xml", b"sitemapindex"),
        ("/xmlrpc.php", b"xml-rpc"),
        ("/wp-admin/", b"wp-admin"),
    ],
    "joomla": [
        ("/administrator/", b"joomla"),
        ("/language/en-GB/en-GB.xml", b"joomla"),
        ("/administrator/manifests/files/joomla.xml", b"version"),
        ("/media/system/js/core.js", b"joomla"),
        ("/templates/system/css/system.css", b""),
    ],
    "drupal": [
        ("/core/COPYRIGHT.txt", b"drupal"),
        ("/CHANGELOG.txt", b"drupal"),
        ("/core/misc/drupal.js", b"drupal"),
        ("/user/login", b"drupal"),
        ("/sites/default/files/", b"drupal"),
    ],
    "laravel": [
        ("/_ignition/health-check", b"can_execute_commands"),
        ("/telescope", b"telescope"),
        ("/api/user", b"unauthorized"),
        ("/sanctum/csrf-cookie", b""),
    ],
    "codeigniter": [
        ("/index.php/", b"codeigniter"),
        ("/user_guide/", b"codeigniter"),
        ("/application/config/database.php", b"db_"),
    ],
    "spring": [
        ("/actuator", b"links"),
        ("/actuator/health", b"status"),
        ("/actuator/env", b"propertysources"),
        ("/error", b"whitelabel"),
    ],
    "django": [
        ("/admin/login/", b"csrfmiddlewaretoken"),
        ("/admin/", b"django"),
    ],
    "rails": [
        ("/rails/info/properties", b"rails"),
        ("/rails/info/routes", b"rails"),
    ],
    "symfony": [
        ("/_profiler/", b"symfony"),
        ("/_wdt/", b"symfony"),
    ],
    "magento": [
        ("/customer/account/login/", b"magento"),
        ("/admin/", b"magento"),
    ],
    "aspnet": [
        ("/Account/Login", b"asp.net"),
        ("/login.aspx", b"asp.net"),
    ],
    "express": [
        ("/api", b"express"),
    ],
}


def detect(url, pool, timeout=3):
    info = {"stack": "unknown", "stacks": [], "server": "",
            "powered_by": "", "evidence": [], "status": 0}
    try:
        r = pool.request("GET", url, timeout=timeout, redirect=False)
        info["status"] = r.status
        info["server"] = r.headers.get("Server") or ""
        info["powered_by"] = r.headers.get("X-Powered-By") or ""
        body = (r.data or b"")[:65536].decode("utf-8", "ignore").lower()
        cookies = (r.headers.get("Set-Cookie") or "").lower()

        fields = {
            "body": body,
            "header:server": info["server"].lower(),
            "header:x-powered-by": info["powered_by"].lower(),
            "header:set-cookie": cookies,
            "header:x-generator": (r.headers.get("X-Generator") or "").lower(),
            "header:x-runtime": (r.headers.get("X-Runtime") or "").lower(),
            "header:x-application-context": (r.headers.get("X-Application-Context") or "").lower(),
        }

        # Layer 1: Signature-based (header + body)
        for stack, sigs in SIGNATURES.items():
            for pattern, field in sigs:
                hay = fields.get(field, "")
                if hay and re.search(pattern, hay):
                    if stack not in info["stacks"]:
                        info["stacks"].append(stack)
                        info["evidence"].append(f"{stack}: {field}")

        # Layer 2: Cookie analysis
        for stack, cookies_list in COOKIE_SIGNATURES.items():
            for cname in cookies_list:
                if cname in cookies:
                    if stack not in info["stacks"]:
                        info["stacks"].append(stack)
                        info["evidence"].append(f"{stack}: cookie={cname}")

        # Pilih stack prioritas
        for s in PRIORITY:
            if s in info["stacks"]:
                info["stack"] = s
                break

        # Layer 3: Active probes (jika ambigu)
        if info["stack"] in ("unknown", "php", "apache", "nginx", "cloudflare", "iis"):
            _active_probe(url, pool, timeout, info)

        # Layer 4: robots.txt (paling andal untuk WP)
        if info["stack"] in ("unknown", "php", "apache", "nginx"):
            _robots_probe(url, pool, timeout, info)

    except Exception as e:
        info["evidence"].append(f"error: {type(e).__name__}: {e}")
    return info


def _try_probe(pool, base, path, marker, timeout):
    try:
        r = pool.request("GET", base + path, timeout=timeout, redirect=False)
        ok = r.status in (200, 301, 302, 401, 403)
        if not ok:
            return False
        data = (r.data or b"").lower()
        if not marker:
            return True
        return marker in data
    except Exception:
        return False


def _active_probe(url, pool, timeout, info):
    base = url.rstrip("/")
    for stack, probes in ACTIVE_PROBES.items():
        for path, marker in probes:
            if _try_probe(pool, base, path, marker, timeout):
                info["stack"] = stack
                if stack not in info["stacks"]:
                    info["stacks"].append(stack)
                info["evidence"].append(f"{stack}: probe {path}")
                return


def _robots_probe(url, pool, timeout, info):
    base = url.rstrip("/")
    try:
        r = pool.request("GET", base + "/robots.txt", timeout=timeout,
                         redirect=False)
        if r.status != 200:
            return
        rb = (r.data or b"").lower()
        if b"wp-admin" in rb or b"wp-content" in rb:
            info["stack"] = "wordpress"
            if "wordpress" not in info["stacks"]:
                info["stacks"].append("wordpress")
            info["evidence"].append("wordpress: robots.txt")
            return
        if b"administrator" in rb and b"joomla" in rb:
            info["stack"] = "joomla"
            if "joomla" not in info["stacks"]:
                info["stacks"].append("joomla")
            info["evidence"].append("joomla: robots.txt")
            return
    except Exception:
        pass
