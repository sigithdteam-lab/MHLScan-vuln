# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_httpsmuggle.py - HTTP request smuggling detection (safe probe).

Probe CL.TE, TE.CL, TE.TE dengan teknik timing-based.
TIDAK mengirim payload berbahaya — hanya probe timing dan error.
"""

import socket
import ssl
import time
from urllib.parse import urlparse


def _connect(host, port=80, use_ssl=False, timeout=8):
    try:
        sock = socket.create_connection((host, port), timeout=timeout)
        if use_ssl:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            sock = ctx.wrap_socket(sock, server_hostname=host)
        return sock
    except Exception:
        return None


def _send_raw(sock, data):
    try:
        sock.sendall(data)
        return True
    except Exception:
        return False


def _recv_all(sock, timeout=3):
    sock.settimeout(timeout)
    chunks = []
    try:
        while True:
            b = sock.recv(4096)
            if not b:
                break
            chunks.append(b)
    except socket.timeout:
        pass
    except Exception:
        pass
    return b"".join(chunks)


def probe_cl_te(host, port, path, use_ssl=False, timeout=8):
    """CL.TE probe: Content-Length + Transfer-Encoding. Timing-based."""
    sock = _connect(host, port, use_ssl, timeout)
    if not sock:
        return None
    try:
        # Baseline request
        baseline = (
            f"GET {path} HTTP/1.1\r\n"
            f"Host: {host}\r\n"
            f"User-Agent: Mozilla/5.0\r\n"
            f"Connection: close\r\n\r\n"
        ).encode()
        t0 = time.time()
        _send_raw(sock, baseline)
        resp = _recv_all(sock, timeout=3)
        baseline_time = time.time() - t0
        sock.close()

        # Probe request (CL+TE)
        sock = _connect(host, port, use_ssl, timeout)
        if not sock:
            return None
        probe = (
            f"POST {path} HTTP/1.1\r\n"
            f"Host: {host}\r\n"
            f"User-Agent: Mozilla/5.0\r\n"
            f"Content-Length: 6\r\n"
            f"Transfer-Encoding: chunked\r\n"
            f"Connection: keep-alive\r\n\r\n"
            f"0\r\n\r\nX"
        ).encode()
        t0 = time.time()
        _send_raw(sock, probe)
        resp2 = _recv_all(sock, timeout=6)
        probe_time = time.time() - t0
        sock.close()

        delta = probe_time - baseline_time

        if delta > 3.0:
            return {
                "type": "CL.TE",
                "severity": "high",
                "evidence": f"Timing delta {delta:.1f}s (baseline {baseline_time:.1f}s)",
                "detail": "Server might be vulnerable to CL.TE smuggling",
            }

        # Cek 400 response ke probe (indikasi parsing ambigu)
        status_line = resp2.split(b"\r\n", 1)[0] if resp2 else b""
        if b" 400 " in status_line or b" 501 " in status_line:
            return {
                "type": "CL.TE",
                "severity": "medium",
                "evidence": f"HTTP {status_line.decode('utf-8', 'ignore')}",
                "detail": "Server rejects ambiguous request",
            }
    except Exception:
        pass
    finally:
        try:
            sock.close()
        except Exception:
            pass
    return None


def probe_te_cl(host, port, path, use_ssl=False, timeout=8):
    """TE.CL probe."""
    sock = _connect(host, port, use_ssl, timeout)
    if not sock:
        return None
    try:
        probe = (
            f"POST {path} HTTP/1.1\r\n"
            f"Host: {host}\r\n"
            f"User-Agent: Mozilla/5.0\r\n"
            f"Content-Length: 4\r\n"
            f"Transfer-Encoding: chunked\r\n"
            f"Connection: keep-alive\r\n\r\n"
            f"5c\r\n"
            f"GPOST /404 HTTP/1.1\r\n"
            f"Content-Length: 15\r\n\r\n"
            f"0\r\n\r\n"
        ).encode()
        t0 = time.time()
        _send_raw(sock, probe)
        resp = _recv_all(sock, timeout=6)
        elapsed = time.time() - t0
        sock.close()

        if elapsed > 3.0:
            return {
                "type": "TE.CL",
                "severity": "high",
                "evidence": f"Timing {elapsed:.1f}s",
            }
        status_line = resp.split(b"\r\n", 1)[0] if resp else b""
        if b" 400 " in status_line or b" 501 " in status_line:
            return {
                "type": "TE.CL",
                "severity": "medium",
                "evidence": f"HTTP {status_line.decode('utf-8', 'ignore')}",
            }
    except Exception:
        pass
    finally:
        try:
            sock.close()
        except Exception:
            pass
    return None


def scan_smuggle(url, timeout=10):
    """Scan HTTP smuggling di URL. Return dict {findings, tested}."""
    try:
        p = urlparse(url)
        host = p.hostname
        port = p.port or (443 if p.scheme == "https" else 80)
        use_ssl = p.scheme == "https"
        path = p.path or "/"
        if p.query:
            path = f"{path}?{p.query}"
    except Exception:
        return {"error": "invalid URL", "findings": []}

    findings = []
    print(f"    [*] Smuggling probe: {host}:{port}{path}")

    r = probe_cl_te(host, port, path, use_ssl, timeout)
    if r:
        findings.append(r)
        print(f"    [!] CL.TE: {r.get('evidence')}")

    r = probe_te_cl(host, port, path, use_ssl, timeout)
    if r:
        findings.append(r)
        print(f"    [!] TE.CL: {r.get('evidence')}")

    return {
        "url": url,
        "findings": findings,
        "tested": ["CL.TE", "TE.CL"],
    }


def status():
    return {
        "tests": ["CL.TE", "TE.CL"],
        "type": "timing_based_probe",
    }
