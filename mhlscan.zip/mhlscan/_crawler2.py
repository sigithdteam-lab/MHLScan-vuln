# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_crawler2.py - Advanced crawler (ZAP-class).

Kemampuan:
- BFS / DFS
- Sitemap.xml + robots.txt
- Form extraction (action, method, fields)
- JS endpoint extraction (fetch, axios, XHR, WebSocket)
- API spec discovery (Swagger, OpenAPI, GraphQL)
- Same-domain policy + rate limit
- Depth + max pages limit
"""

import re
import time
import urllib.parse
import requests
import urllib3
from collections import deque
from concurrent.futures import ThreadPoolExecutor, as_completed

urllib3.disable_warnings()


# =========================================================
# HELPERS
# =========================================================
def _normalize(url):
    """Normalisasi URL: buang fragment, sort query."""
    if not url:
        return None
    try:
        p = urllib.parse.urlparse(url)
        if not p.netloc:
            return None
        qs = urllib.parse.parse_qsl(p.query)
        qs.sort()
        new_q = urllib.parse.urlencode(qs)
        return urllib.parse.urlunparse(p._replace(
            scheme=p.scheme, netloc=p.netloc, query=new_q, fragment=""
        ))
    except Exception:
        return None


def _same_domain(url, base_domain):
    try:
        return urllib.parse.urlparse(url).netloc == base_domain
    except Exception:
        return False


def _is_static(url):
    """Skip static files yang tidak berguna untuk scan."""
    static_exts = (".jpg", ".jpeg", ".png", ".gif", ".svg", ".ico",
                   ".css", ".woff", ".woff2", ".ttf", ".eot",
                   ".mp3", ".mp4", ".avi", ".webm", ".pdf",
                   ".zip", ".rar", ".7z", ".tar", ".gz")
    return any(url.lower().endswith(ext) for ext in static_exts)


def _extract_links(html, base_url):
    """Ekstrak semua href dari <a>, <link>, <form action>."""
    links = set()
    base_p = urllib.parse.urlparse(base_url)

    # <a href="...">
    for m in re.finditer(r'<a[^>]+href=["\']([^"\']+)["\']',
                         html, re.I):
        href = m.group(1).strip()
        if href.startswith(("#", "javascript:", "mailto:", "tel:")):
            continue
        try:
            full = urllib.parse.urljoin(base_url, href)
            links.add(full)
        except Exception:
            pass

    # <link href="...">
    for m in re.finditer(r'<link[^>]+href=["\']([^"\']+)["\']',
                         html, re.I):
        href = m.group(1).strip()
        if href.startswith(("#", "javascript:")):
            continue
        try:
            full = urllib.parse.urljoin(base_url, href)
            links.add(full)
        except Exception:
            pass

    # <form action="...">
    for m in re.finditer(r'<form[^>]+action=["\']([^"\']+)["\']',
                         html, re.I):
        href = m.group(1).strip()
        if href.startswith(("#", "javascript:")):
            continue
        try:
            full = urllib.parse.urljoin(base_url, href)
            links.add(full)
        except Exception:
            pass

    return links


def _extract_forms(html, base_url):
    """Ekstrak form (action, method, fields)."""
    forms = []
    form_pattern = re.compile(r'<form[^>]*>(.*?)</form>', re.S | re.I)
    for m in form_pattern.finditer(html):
        form_tag = html[m.start():m.start() + 500]
        action_m = re.search(r'action=["\']([^"\']*)["\']', form_tag, re.I)
        method_m = re.search(r'method=["\']([^"\']*)["\']', form_tag, re.I)
        action = action_m.group(1) if action_m else ""
        method = (method_m.group(1) if method_m else "GET").upper()

        fields = []
        for fm in re.finditer(r'<input[^>]+name=["\']([^"\']+)["\']',
                              m.group(1), re.I):
            fields.append(fm.group(1))
        for fm in re.finditer(r'<textarea[^>]+name=["\']([^"\']+)["\']',
                              m.group(1), re.I):
            fields.append(fm.group(1))
        for fm in re.finditer(r'<select[^>]+name=["\']([^"\']+)["\']',
                              m.group(1), re.I):
            fields.append(fm.group(1))

        if action:
            try:
                full_action = urllib.parse.urljoin(base_url, action)
                forms.append({
                    "action": full_action,
                    "method": method,
                    "fields": list(set(fields)),
                })
            except Exception:
                pass

    return forms


def _extract_js_endpoints(html, base_url):
    """Ekstrak endpoint dari JS inline (fetch, axios, XHR)."""
    endpoints = set()
    patterns = [
        r'fetch\s*\(\s*["\']([^"\']+)["\']',
        r'axios\.\w+\s*\(\s*["\']([^"\']+)["\']',
        r'XMLHttpRequest[^;]*\.open\s*\(\s*["\'][^"\']*["\']\s*,\s*["\']([^"\']+)["\']',
        r'\.ajax\s*\(\s*{[^}]*url\s*:\s*["\']([^"\']+)["\']',
        r'\$\.get\s*\(\s*["\']([^"\']+)["\']',
        r'\$\.post\s*\(\s*["\']([^"\']+)["\']',
        r'new\s+WebSocket\s*\(\s*["\']([^"\']+)["\']',
        r'\.open\s*\(\s*["\'][^"\']*["\']\s*,\s*["\']([^"\']+)["\']',
        r'url\s*:\s*["\']([/][^"\']+)["\']',
    ]
    for pat in patterns:
        for m in re.finditer(pat, html, re.I):
            ep = m.group(1).strip()
            if ep and not ep.startswith(("#", "javascript:", "data:")):
                try:
                    full = urllib.parse.urljoin(base_url, ep)
                    endpoints.add(full)
                except Exception:
                    pass
    return endpoints


def _fetch_robots(base_url, timeout=10):
    """Parse robots.txt untuk Sitemap + Disallow hints."""
    urls = {"sitemaps": [], "disallow": []}
    try:
        r = requests.get(base_url.rstrip("/") + "/robots.txt",
                         timeout=timeout, verify=False)
        if r.status_code != 200:
            return urls
        for line in r.text.splitlines():
            line = line.strip()
            if line.lower().startswith("sitemap:"):
                urls["sitemaps"].append(line.split(":", 1)[1].strip())
            elif line.lower().startswith("disallow:"):
                path = line.split(":", 1)[1].strip()
                if path and path != "/":
                    urls["disallow"].append(path)
    except Exception:
        pass
    return urls


def _fetch_sitemap(base_url, sitemaps=None, timeout=10):
    """Parse sitemap.xml, return list URL."""
    found = []
    if not sitemaps:
        sitemaps = [base_url.rstrip("/") + "/sitemap.xml"]

    for sm in sitemaps[:5]:
        try:
            r = requests.get(sm, timeout=timeout, verify=False)
            if r.status_code != 200:
                continue
            for m in re.finditer(r'<loc>([^<]+)</loc>', r.text, re.I):
                found.append(m.group(1).strip())
        except Exception:
            continue
    return found


def _check_api_specs(base_url, timeout=5):
    """Cek spec API umum."""
    specs = [
        "/swagger.json", "/swagger-ui.html", "/swagger-ui/",
        "/openapi.json", "/api-docs", "/v2/api-docs", "/v3/api-docs",
        "/api/swagger.json", "/api/openapi.json",
        "/graphql", "/graphiql", "/__graphql",
    ]
    found = []
    for spec in specs:
        try:
            url = base_url.rstrip("/") + spec
            r = requests.get(url, timeout=timeout, verify=False)
            if r.status_code == 200:
                ct = (r.headers.get("Content-Type") or "").lower()
                body = (r.text or "")[:500].lower()
                if "json" in ct or spec.endswith(".json"):
                    if "swagger" in body or "openapi" in body or "\"paths\"" in body:
                        found.append({"url": url, "type": "openapi",
                                      "size": len(r.text or "")})
                elif "graphql" in spec or "graphiql" in spec:
                    if "graphiql" in body or "__schema" in body or "graphql" in body:
                        found.append({"url": url, "type": "graphql",
                                      "size": len(r.text or "")})
        except Exception:
            continue
    return found


# =========================================================
# CRAWLER
# =========================================================
def crawl(start_url, max_pages=50, max_depth=3, mode="bfs",
          rate_limit=1.0, timeout=10, same_domain=True,
          include_api_spec=True, include_sitemap=True):
    """Crawl target.

    Return dict {
        pages: [{url, status, depth, content_type}],
        forms: [{action, method, fields, source_url}],
        endpoints: [url],
        api_specs: [{url, type}],
        stats: {crawled, failed, total, duration},
    }
    """
    start = time.time()
    base_p = urllib.parse.urlparse(start_url)
    base_domain = base_p.netloc

    visited = set()
    queue = deque([(start_url, 0)])
    pages = []
    forms = []
    endpoints = set()
    api_specs = []
    failed = 0

    last_request = [0.0]

    def _rate_wait():
        if rate_limit > 0:
            elapsed = time.time() - last_request[0]
            if elapsed < rate_limit:
                time.sleep(rate_limit - elapsed)
            last_request[0] = time.time()

    print(f"    [*] Crawl: {start_url} (max {max_pages}, depth {max_depth}, {mode.upper()})")

    while queue and len(visited) < max_pages:
        if mode == "dfs":
            url, depth = queue.pop()
        else:
            url, depth = queue.popleft()

        norm = _normalize(url)
        if not norm or norm in visited:
            continue
        if same_domain and not _same_domain(norm, base_domain):
            continue
        if _is_static(norm):
            continue

        visited.add(norm)

        _rate_wait()
        try:
            r = requests.get(norm, timeout=timeout, verify=False,
                             allow_redirects=True)
        except Exception:
            failed += 1
            continue

        ct = (r.headers.get("Content-Type") or "").lower()
        pages.append({
            "url": norm,
            "status": r.status_code,
            "depth": depth,
            "content_type": ct.split(";")[0] if ct else "?",
        })

        # Skip non-HTML
        if "html" not in ct and "javascript" not in ct and "json" not in ct:
            continue

        html = r.text or ""

        # Ekstrak form
        page_forms = _extract_forms(html, norm)
        for f in page_forms:
            f["source_url"] = norm
            forms.append(f)

        # Ekstrak JS endpoint
        page_eps = _extract_js_endpoints(html, norm)
        endpoints.update(page_eps)

        # Ekstrak link untuk crawl lanjutan
        if depth < max_depth:
            links = _extract_links(html, norm)
            for link in links:
                if link not in visited:
                    queue.append((link, depth + 1))

        if len(pages) % 10 == 0:
            print(f"    progress: {len(pages)} pages, {len(forms)} forms, "
                  f"{len(endpoints)} endpoints")

    # Robots.txt
    if include_sitemap:
        robots = _fetch_robots(start_url, timeout=timeout)
        sitemap_urls = _fetch_sitemap(start_url, robots.get("sitemaps"),
                                      timeout=timeout)
        for sm in sitemap_urls:
            endpoints.add(sm)

    # API specs
    if include_api_spec:
        api_specs = _check_api_specs(start_url, timeout=5)

    duration = time.time() - start
    return {
        "start_url": start_url,
        "pages": pages,
        "forms": forms,
        "endpoints": sorted(endpoints)[:200],
        "api_specs": api_specs,
        "stats": {
            "crawled": len(pages),
            "failed": failed,
            "forms": len(forms),
            "endpoints": len(endpoints),
            "total": len(visited),
            "duration": round(duration, 2),
        },
    }


def status():
    return {
        "modes": ["bfs", "dfs"],
        "features": [
            "link_extraction", "form_extraction", "js_endpoints",
            "robots_txt", "sitemap", "api_specs",
            "rate_limit", "same_domain", "depth_limit",
        ],
    }
