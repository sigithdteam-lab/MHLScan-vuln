# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_context.py - Analyze reflection context in HTML."""

from html.parser import HTMLParser


class ContextParser(HTMLParser):
    """
    Detect where a needle appears in HTML:
      - "tag_attr:<name>" : inside attribute
      - "tag_body"        : inside element text
      - "script"          : inside <script>
      - "comment"         : inside HTML comment
      - "unknown"         : not found / not parsed
    """
    def __init__(self, needle):
        super().__init__()
        self.needle = needle
        self.context = "unknown"
        self._in_script = False
        self._in_style = False

    def handle_starttag(self, tag, attrs):
        for name, val in attrs:
            if val and self.needle in val:
                self.context = "tag_attr:" + name
                return
        if tag == "script":
            self._in_script = True
        elif tag == "style":
            self._in_style = True

    def handle_endtag(self, tag):
        if tag == "script":
            self._in_script = False
        elif tag == "style":
            self._in_style = False

    def handle_data(self, data):
        if self.needle not in data:
            return
        if self._in_script:
            self.context = "script"
        elif self._in_style:
            self.context = "style"
        else:
            self.context = "tag_body"

    def handle_comment(self, data):
        if self.needle in data:
            self.context = "comment"


def get_reflection_context(body, needle):
    """Detect context of needle in body. Returns string."""
    parser = ContextParser(needle)
    try:
        parser.feed(body or "")
    except Exception:
        return "unknown"
    return parser.context


def context_severity(context):
    """
    Map context → severity untuk reflected findings.
    Return None kalau context = unknown / style (tidak useful).
    """
    if not context or context == "unknown":
        return None
    if context.startswith("tag_attr"):
        attr = context.split(":", 1)[1].lower()
        if attr in ("href", "src", "action", "formaction", "data", "poster"):
            return "high"  # JS URL / redirect risk
        if attr.startswith("on"):
            return "critical"  # Event handler = direct XSS
        return "medium"
    if context == "script":
        return "high"
    if context == "tag_body":
        return "low"  # probably escaped
    if context == "comment":
        return "low"
    if context == "style":
        return None
    return None
