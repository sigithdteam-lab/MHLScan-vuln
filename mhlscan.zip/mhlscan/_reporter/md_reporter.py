# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
from datetime import datetime, timezone


class MarkdownReporter:
    def render(self, results, output_path):
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        lines = []
        lines.append("# MHLScan Report - " + ts + "\n\n")

        total_f = sum(len(r.get("findings", [])) for r in results)
        total_v = sum(len(r.get("vulnerabilities", [])) for r in results)
        lines.append("- Total targets: " + str(len(results)) + "\n")
        lines.append("- Total findings: " + str(total_f) + "\n")
        lines.append("- Total vulnerabilities: " + str(total_v) + "\n\n")

        for r in results:
            lines.append("## " + str(r.get("target", "?")) + "\n\n")
            lines.append("- IP: `" + str(r.get("ip", "-")) + "`\n")
            lines.append("- Stack: **" + str(r.get("stack", "unknown")) + "**\n")
            if r.get("server"):
                lines.append("- Server: `" + str(r["server"]) + "`\n")
            if r.get("waf"):
                lines.append("- WAF: **" + str(r["waf"]) + "**\n")
            ver = (r.get("version") or {}).get("version")
            if ver:
                lines.append("- Version: **" + str(ver) + "**\n")
            lines.append("\n")

            findings = r.get("findings", [])
            if findings:
                lines.append("### Findings\n\n")
                lines.append("| Severity | Name | PoC | Evidence |\n")
                lines.append("|----------|------|-----|----------|\n")
                for f in findings:
                    sev = f.get("severity", "?")
                    name = str(f.get("name", "-")).replace("|", "/")
                    poc = str(f.get("poc", "-")).replace("|", "/").replace("`", "'")
                    ev = str(f.get("evidence", "-")).replace("|", "/")[:100]
                    lines.append("| " + sev + " | " + name + " | `" + poc + "` | " + ev + " |\n")
                lines.append("\n")

            vulns = r.get("vulnerabilities", [])
            if vulns:
                lines.append("### Vulnerabilities\n\n")
                lines.append("| Severity | ID | Name | PoC |\n")
                lines.append("|----------|-----|------|-----|\n")
                for v in vulns:
                    sev = v.get("severity", "?")
                    vid = str(v.get("id", "-"))
                    vname = str(v.get("name", "-")).replace("|", "/")
                    poc = str(v.get("poc", "-")).replace("|", "/").replace("`", "'")
                    lines.append("| " + sev + " | " + vid + " | " + vname + " | `" + poc + "` |\n")
                lines.append("\n")

        with open(output_path, "w", encoding="utf-8") as f:
            f.write("".join(lines))
        return output_path
