# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_reporter - Modular report generators (JSON, MD, HTML, SARIF)."""
from pathlib import Path

from .json_reporter import JSONReporter
from .md_reporter import MarkdownReporter
from .html_reporter import HTMLReporter
try:
    from .sarif_reporter import SARIFReporter
except ImportError:
    SARIFReporter = None


def write_all(results, base_path):
    base_path = str(Path(base_path).with_suffix(""))
    paths = {}
    paths["json"] = JSONReporter().render(results, base_path + ".json")
    paths["md"]   = MarkdownReporter().render(results, base_path + ".md")
    paths["html"] = HTMLReporter().render(results, base_path + ".html")
    if SARIFReporter:
        try:
            paths["sarif"] = SARIFReporter().render(results, base_path + ".sarif")
        except Exception:
            pass
    return paths
