# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""SARIF 2.1.0 reporter - untuk GitHub Security / Jenkins / SonarQube."""
import json


class SARIFReporter:
    def render(self, results, output_path):
        sarif_results = []
        rules = {}

        for r in results:
            target = r.get("target", "")
            findings = r.get("findings", []) + r.get("vulnerabilities", [])
            for f in findings:
                rule_id = str(f.get("id", "unknown"))
                sev = (f.get("severity") or "info").lower()
                level = {
                    "critical": "error", "high": "error", "medium": "warning",
                    "low": "note", "info": "note",
                }.get(sev, "note")

                if rule_id not in rules:
                    rules[rule_id] = {
                        "id": rule_id,
                        "name": f.get("name", rule_id),
                        "shortDescription": {"text": f.get("name", rule_id)},
                        "defaultConfiguration": {"level": level},
                    }

                sarif_results.append({
                    "ruleId": rule_id,
                    "level": level,
                    "message": {"text": f.get("name", rule_id) + " - " + f.get("evidence", "")},
                    "locations": [{
                        "physicalLocation": {
                            "artifactLocation": {
                                "uri": f.get("url") or f.get("poc_url") or target,
                            },
                        },
                    }],
                })

        sarif = {
            "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
            "version": "2.1.0",
            "runs": [{
                "tool": {
                    "driver": {
                        "name": "MHLScan",
                        "version": "8.1.0",
                        "informationUri": "https://github.com/",
                        "rules": list(rules.values()),
                    },
                },
                "results": sarif_results,
            }],
        }

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(sarif, f, indent=2, ensure_ascii=False)
        return output_path
