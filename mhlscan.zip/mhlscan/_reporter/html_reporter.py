# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
import html as _html
from datetime import datetime, timezone


class HTMLReporter:
    def render(self, results, output_path):
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        total_f = sum(len(r.get("findings", [])) for r in results)
        total_v = sum(len(r.get("vulnerabilities", [])) for r in results)

        out = []
        out.append('<!DOCTYPE html><html><head><meta charset="utf-8">')
        out.append('<title>MHLScan Report</title>')
        out.append('<style>')
        out.append('body{font-family:system-ui,sans-serif;margin:20px;background:#f5f5f5;color:#222}')
        out.append('h1{color:#111}h2{border-bottom:2px solid #ccc;padding-bottom:5px;margin-top:30px}')
        out.append('table{border-collapse:collapse;width:100%;background:#fff;margin:10px 0}')
        out.append('th{background:#333;color:#fff;padding:8px;text-align:left}')
        out.append('td{padding:6px 8px;border-bottom:1px solid #eee}')
        out.append('.summary{background:#fff;padding:15px;border-radius:6px;margin:10px 0}')
        out.append('.sev-critical{color:#fff;background:#c00;padding:2px 6px;border-radius:3px;font-size:11px}')
        out.append('.sev-high{color:#fff;background:#e67e22;padding:2px 6px;border-radius:3px;font-size:11px}')
        out.append('.sev-medium{color:#fff;background:#f39c12;padding:2px 6px;border-radius:3px;font-size:11px}')
        out.append('.sev-low{color:#fff;background:#3498db;padding:2px 6px;border-radius:3px;font-size:11px}')
        out.append('.sev-info{color:#fff;background:#95a5a6;padding:2px 6px;border-radius:3px;font-size:11px}')
        out.append('code{background:#eef;padding:1px 4px;border-radius:3px;font-size:12px}')
        out.append('</style></head><body>')
        out.append('<h1>MHLScan Report</h1>')
        out.append('<p>' + ts + '</p>')
        out.append('<div class="summary"><strong>Targets:</strong> ' + str(len(results))
                   + ' | <strong>Findings:</strong> ' + str(total_f)
                   + ' | <strong>Vulnerabilities:</strong> ' + str(total_v) + '</div>')

        def badge(sev):
            s = (sev or "info").lower()
            return '<span class="sev-' + s + '">' + _html.escape(str(sev)) + '</span>'

        for r in results:
            out.append('<h2>' + _html.escape(str(r.get("target", "?"))) + '</h2>')
            out.append('<table>')
            out.append('<tr><th>IP</th><td><code>' + _html.escape(str(r.get("ip", "-"))) + '</code></td></tr>')
            out.append('<tr><th>Stack</th><td><strong>' + _html.escape(str(r.get("stack", "unknown"))) + '</strong></td></tr>')
            if r.get("waf"):
                out.append('<tr><th>WAF</th><td>' + _html.escape(str(r["waf"])) + '</td></tr>')
            out.append('</table>')

            findings = r.get("findings", [])
            if findings:
                out.append('<h3>Findings</h3>')
                out.append('<table><tr><th>Severity</th><th>Name</th><th>POC</th></tr>')
                for f in findings:
                    out.append('<tr><td>' + badge(f.get("severity"))
                               + '</td><td>' + _html.escape(str(f.get("name", "-")))
                               + '</td><td><code>' + _html.escape(str(f.get("poc", "-")))
                               + '</code></td></tr>')
                out.append('</table>')

            vulns = r.get("vulnerabilities", [])
            if vulns:
                out.append('<h3>Vulnerabilities</h3>')
                out.append('<table><tr><th>Severity</th><th>ID</th><th>Name</th><th>POC</th></tr>')
                for v in vulns:
                    out.append('<tr><td>' + badge(v.get("severity"))
                               + '</td><td>' + _html.escape(str(v.get("id", "-")))
                               + '</td><td>' + _html.escape(str(v.get("name", "-")))
                               + '</td><td><code>' + _html.escape(str(v.get("poc", "-")))
                               + '</code></td></tr>')
                out.append('</table>')

        out.append('</body></html>')
        with open(output_path, "w", encoding="utf-8") as f:
            f.write("\n".join(out))
        return output_path
