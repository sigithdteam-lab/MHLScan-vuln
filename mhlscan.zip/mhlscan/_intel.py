# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_intel.py - Multi-source CVE intelligence (KEV + EPSS + EDB + GitHub)."""

import os, json, time, subprocess, shutil
from pathlib import Path
import requests

CACHE_DIR = Path.home() / ".mhlscan" / "intel_cache"
CACHE_DIR.mkdir(parents=True, exist_ok=True)

KEV_URL = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"
EPSS_URL = "https://api.first.org/data/v1/epss"

KEV_TTL = 86400
EPSS_TTL = 86400
EXPLOIT_TTL = 604800

NL = chr(10)


def _load_cache(name, ttl):
    f = CACHE_DIR / f"{name}.json"
    if not f.exists():
        return None
    if (time.time() - f.stat().st_mtime) > ttl:
        return None
    try:
        return json.loads(f.read_text())
    except Exception:
        return None


def _save_cache(name, data):
    f = CACHE_DIR / f"{name}.json"
    try:
        f.write_text(json.dumps(data))
    except Exception:
        pass


def load_kev(verbose=True):
    """CISA Known Exploited Vulnerabilities catalog."""
    cached = _load_cache("kev", KEV_TTL)
    if cached:
        return cached
    try:
        if verbose:
            print("    [*] Loading CISA KEV catalog...")
        r = requests.get(KEV_URL, timeout=30)
        r.raise_for_status()
        data = r.json()
        catalog = {}
        for v in data.get("vulnerabilities", []):
            catalog[v["cveID"]] = {
                "vendorProject": v.get("vendorProject", ""),
                "product": v.get("product", ""),
                "name": v.get("vulnerabilityName", ""),
                "dateAdded": v.get("dateAdded", ""),
                "ransomware": v.get("knownRansomwareCampaignUse", "Unknown") == "Known",
            }
        _save_cache("kev", catalog)
        if verbose:
            print(f"    [+] KEV: {len(catalog)} actively exploited CVEs")
        return catalog
    except Exception as e:
        if verbose:
            print(f"    [-] KEV failed: {e}")
        return {}

def get_epss(cve_ids, verbose=True):
    if not cve_ids:
        return {}
    cache_key = "epss_" + "_".join(sorted(cve_ids))[:200]
    cached = _load_cache(cache_key, EPSS_TTL)
    if cached:
        return cached
    try:
        params = {"cve": ",".join(cve_ids)}
        r = requests.get(EPSS_URL, params=params, timeout=20)  # naik dari 15→20
        r.raise_for_status()
        data = r.json()
        result = {}
        for item in data.get("data", []):
            result[item["cve"]] = {
                "epss": float(item.get("epss", 0)),
                "percentile": float(item.get("percentile", 0)),
            }
        _save_cache(cache_key, result)
        return result
    except Exception as e:
        if verbose:
            print(f"    [-] EPSS failed: {e}")
        return {}

def check_exploitdb(cve_id):
    """Query searchsploit untuk PoC availability."""
    try:
        import _cve_db
        db = _cve_db._load("exploitdb")
        if cve_id in db:
            return db[cve_id]
    except Exception:
        pass

    if not shutil.which("searchsploit"):
        return None
    cache_key = f"edb_{cve_id}"
    cached = _load_cache(cache_key, EXPLOIT_TTL)
    if cached is not None:
        return cached
    try:
        r = subprocess.run(
            ["searchsploit", "--cve", cve_id, "--json"],
            capture_output=True, text=True, timeout=10)
        if r.returncode != 0:
            return None
        data = json.loads(r.stdout)
        matches = data.get("RESULTS_EXPLOIT", [])
        result = {
            "available": len(matches) > 0,
            "count": len(matches),
            "ids": [m.get("EDB-ID", "") for m in matches[:5]],
        }
        _save_cache(cache_key, result)
        return result
    except Exception:
        return None


def batch_enrich(cve_ids, verbose=True):
    """
    Enrich list CVE dengan semua sumber intelijen.
    Return list dict dengan priority_score.
    """
    if not cve_ids:
        return []

    kev = load_kev(verbose=verbose)
    epss_all = get_epss(cve_ids, verbose=verbose)

    results = []
    for cve_id in cve_ids:
        intel = {
            "cve": cve_id,
            "kev": cve_id in kev,
            "kev_ransomware": kev.get(cve_id, {}).get("ransomware", False),
            "kev_name": kev.get(cve_id, {}).get("name", ""),
            "kev_date": kev.get(cve_id, {}).get("dateAdded", ""),
            "epss": epss_all.get(cve_id, {}).get("epss", 0.0),
            "epss_percentile": epss_all.get(cve_id, {}).get("percentile", 0.0),
            "exploitdb": check_exploitdb(cve_id),
        }
        # Priority score (0-100)
        score = 0.0
        if intel["kev"]:
            score += 50.0
            if intel["kev_ransomware"]:
                score += 20.0
        score += intel["epss"] * 30.0
        if intel["exploitdb"] and intel["exploitdb"].get("available"):
            score += 15.0
        intel["priority_score"] = round(score, 1)
        results.append(intel)

        if verbose:
            flag = "!!!" if intel["kev"] else ("!" if intel["epss"] > 0.5 else ".")
            edb = "Y" if intel["exploitdb"] and intel["exploitdb"].get("available") else "N"
            print(f"    {flag} {cve_id}: KEV={intel['kev']} "
                  f"EPSS={intel['epss']:.2f} EDB={edb} Score={intel['priority_score']}")

    # Sort by priority desc
    results.sort(key=lambda x: x["priority_score"], reverse=True)
    return results
