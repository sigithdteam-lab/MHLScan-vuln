# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_httpmethods.py - HTTP Method Security Scanner (OWASP OTG-CONFIG-006)."""

import re
import random
import string
import warnings

try:
    from urllib3.exceptions import InsecureRequestWarning
    warnings.filterwarnings("ignore", category=InsecureRequestWarning)
except ImportError:
    pass


def _rand(n=8):
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=n))


def _mk(fid, name, severity, evidence, endpoint, url):
    return {
        "id": fid,
        "name": name,
        "severity": severity,
        "evidence": evidence,
        "endpoint": endpoint,
        "url": url,
        "source": "httpmethods",
        "type": "httpmethod",
    }


def scan_methods(url, pool, timeout=5, allow_put=False):
    base = url.rstrip("/")
    result = {
        "findings": [],
        "options_allow": None,
        "trace_enabled": False,
        "debug_enabled": False,
        "put_allowed": False,
        "directory_listing": False,
    }

    try:
        r = pool.request("OPTIONS", base, timeout=timeout, redirect=False)
        allow = r.headers.get("Allow")
        if r.status in (200, 204) and allow:
            result["options_allow"] = allow
            methods = [m.strip().upper() for m in allow.split(",")]
            if "PUT" in methods:
                result["findings"].append(_mk(
                    "HTTP-OPTIONS-PUT",
                    "OPTIONS advertises PUT method (upload risk)",
                    "medium", "Allow: " + allow, "/", base))
            elif "DELETE" in methods or "TRACE" in methods:
                result["findings"].append(_mk(
                    "HTTP-OPTIONS-RISKY",
                    "OPTIONS advertises risky methods",
                    "low", "Allow: " + allow, "/", base))
    except Exception:
        pass

    try:
        r = pool.request("TRACE", base, timeout=timeout, redirect=False)
        if r.status == 200:
            body = (r.data or b"")[:2000].decode("utf-8", "ignore")
            if "TRACE /" in body or "Max-Forwards" in body:
                result["trace_enabled"] = True
                result["findings"].append(_mk(
                    "HTTP-TRACE",
                    "TRACE method enabled (XST / cookie theft risk)",
                    "medium", "TRACE request reflected in response",
                    "/", base))
    except Exception:
        pass

    try:
        debug_path = "/mhlscan_probe_" + _rand(4) + ".aspx"
        r = pool.request("DEBUG", base + debug_path,
                         headers={"Command": "stop-debug", "Accept": "*/*"},
                         timeout=timeout, redirect=False)
        if r.status in (200, 201):
            result["debug_enabled"] = True
            result["findings"].append(_mk(
                "HTTP-DEBUG",
                "DEBUG method enabled (IIS info disclosure)",
                "high", "DEBUG returned HTTP " + str(r.status),
                debug_path, base))
    except Exception:
        pass

    for d in ["/", "/uploads/", "/images/", "/files/", "/backup/"]:
        try:
            r = pool.request("GET", base + d, timeout=timeout, redirect=False)
            if r.status == 200:
                body = (r.data or b"")[:8000].decode("utf-8", "ignore").lower()
                if (re.search(r"<title>index of ", body) or
                        "to parent directory" in body or
                        "directory listing for" in body):
                    result["directory_listing"] = True
                    result["findings"].append(_mk(
                        "HTTP-DIRLISTING",
                        "Directory listing enabled",
                        "medium", "Path: " + d, d, base))
                    break
        except Exception:
            pass

    if allow_put:
        marker = "MHLSCAN_PUT_PROOF_" + _rand(8)
        fname = "mhlscan_probe_" + _rand(6) + ".txt"
        target_url = base + "/" + fname
        try:
            r = pool.request("PUT", target_url,
                             body=marker.encode(),
                             headers={"Content-Type": "text/plain"},
                             timeout=timeout, redirect=False)
            if r.status in (200, 201, 204):
                try:
                    rg = pool.request("GET", target_url,
                                      timeout=timeout, redirect=False)
                    if rg.status == 200 and marker.encode() in (rg.data or b""):
                        result["put_allowed"] = True
                        result["findings"].append(_mk(
                            "HTTP-PUT",
                            "PUT method allows file upload (.txt)",
                            "high",
                            "Verified at: " + target_url + " — MANUAL CLEANUP REQUIRED",
                            "/" + fname, base))
                except Exception:
                    pass
        except Exception:
            pass

    return result
