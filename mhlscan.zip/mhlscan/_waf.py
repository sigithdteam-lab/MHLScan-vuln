# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_waf.py - WAF detection dengan 69+ signatures (XSStrike + sqlmap)."""

import json
import re
import warnings
from pathlib import Path

import requests
import urllib3

urllib3.disable_warnings()


WAF_DB_PATHS = [
    Path(__file__).parent / "db" / "wafSignatures.json",
    Path.home() / ".mhlscan" / "db" / "wafSignatures.json",
]

_WAF_DB_CACHE = None


def load_waf_db():
    global _WAF_DB_CACHE
    if _WAF_DB_CACHE is not None:
        return _WAF_DB_CACHE

    for path in WAF_DB_PATHS:
        if path.exists():
            try:
                _WAF_DB_CACHE = json.loads(path.read_text())
                return _WAF_DB_CACHE
            except Exception:
                continue

    _WAF_DB_CACHE = {}
    return _WAF_DB_CACHE


# Built-in fallback (kalau db/wafSignatures.json tidak ada)
BUILTIN_SIGNATURES = {
    "Cloudflare":  ["cf-ray", "cloudflare", "__cf_bm", "cf-cache-status"],
    "Wordfence":   ["wordfence", "wfvt_", "wfwaf-"],
    "Sucuri":      ["x-sucuri-id", "sucuri", "x-sucuri-cache"],
    "Akamai":      ["akamai", "ak-bmsc", "akamai-ghost"],
    "AWS WAF":     ["x-amzn-requestid", "awselb", "x-amzn-trace-id"],
    "Incapsula":   ["incap_ses", "visid_incap", "incapsula"],
    "F5 BIG-IP":   ["bigip", "tsxxxx", "bigipserver"],
    "Barracuda":   ["barra_counter_session", "barracuda"],
    "FortiWeb":    ["fortiweb", "fortinet"],
    "ModSecurity": ["mod_security", "modsecurity"],
}


def _fetch_probe(url, timeout=5):
    """Fetch target dengan payload trigger WAF."""
    probes = [
        url.rstrip("/") + "/?x=%3Cscript%3Ealert(1)%3C/script%3E",
        url.rstrip("/") + "/?id=1%27%20OR%20%271%27%3D%271",
        url.rstrip("/") + "/?q=../../etc/passwd",
    ]
    for probe_url in probes:
        try:
            r = requests.get(probe_url, timeout=timeout, verify=False,
                             allow_redirects=False,
                             headers={"User-Agent": "Mozilla/5.0"})
            combined = (str(r.headers) + " " + (r.text or "")[:4000]).lower()
            return {"status": r.status_code, "text": combined, "headers": str(r.headers).lower()}
        except Exception:
            continue
    return None


def detect_waf(url, timeout=5):
    """
    Detect WAF. Returns:
        {"waf": "Cloudflare", "confidence": "high", "evidence": "..."} atau None
    """
    probe = _fetch_probe(url, timeout=timeout)
    if not probe:
        return None

    text = probe["text"]
    db = load_waf_db()

    # 1. Cek dari XSStrike DB (69 signatures)
    for waf_name, waf_info in db.items():
        signatures = waf_info.get("signatures", []) if isinstance(waf_info, dict) else []
        for sig in signatures:
            if isinstance(sig, str) and sig and sig.lower() in text:
                return {
                    "waf": waf_name,
                    "confidence": "high",
                    "evidence": "signature: " + sig,
                }

    # 2. Fallback built-in
    for waf_name, sigs in BUILTIN_SIGNATURES.items():
        for sig in sigs:
            if sig in text:
                return {
                    "waf": waf_name,
                    "confidence": "medium",
                    "evidence": "builtin: " + sig,
                }

    # 3. Generic status detection
    if probe["status"] in (406, 429, 503):
        return {
            "waf": "Unknown WAF (HTTP " + str(probe["status"]) + ")",
            "confidence": "low",
            "evidence": "suspicious status",
        }

    return None
