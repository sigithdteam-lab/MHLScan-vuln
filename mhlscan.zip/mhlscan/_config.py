# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_config.py - Centralized configuration & constants."""

from pathlib import Path

# ============ ANSI COLORS ============
RED    = '\033[91m'
GREEN  = '\033[32m'
YELLOW = '\033[1;33m'
BLUE   = '\033[94m'
CYAN   = '\033[96m'
MAGENTA = '\033[95m'
BOLD   = '\033[1m'
DIM    = '\033[2m'
ENDC   = '\033[0m'

# ============ PATHS ============
BASE_DIR      = Path(__file__).parent
DB_DIR        = BASE_DIR / "db"
CACHE_ROOT    = Path.home() / ".mhlscan" / "nuclei"
CVE_DB_DIR    = Path.home() / ".mhlscan" / "cve_db"
PAYLOAD_DIR   = Path.home() / ".mhlscan" / "payloads"
REPORT_DIR    = BASE_DIR
TOOLS_DIR     = Path.home() / "tools"

# ============ DEFAULTS ============
DEFAULT_TIMEOUT   = 5
DEFAULT_WORKERS   = 10
DEFAULT_SEVERITY  = "medium"
DEFAULT_UA        = "Mozilla/5.0 (compatible; MHLScan/8.1)"

SEVERITY_ORDER = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}
SEVERITY_COLOR = {
    "critical": RED, "high": RED, "medium": YELLOW,
    "low": BLUE, "info": CYAN,
}

JAVA_STACKS = {"jboss", "tomcat", "wso2", "spring"}


class RuntimeConfig:
    """Global runtime config (di-set dari argparse di main())."""
    def __init__(self):
        self.timeout      = DEFAULT_TIMEOUT
        self.workers      = DEFAULT_WORKERS
        self.severity     = DEFAULT_SEVERITY
        self.stealth      = True
        self.aggressive   = False
        self.xss_scan     = False
        self.xss_blind    = False
        self.xss_crawl    = False
        self.rev_shell    = False
        self.lhost        = None
        self.lport        = 4444
        self.msf_enabled  = False
        self.msf_host     = "127.0.0.1"
        self.msf_port     = 55553
        self.msf_pass     = "msf"
        self.war_url      = None
        self.report_path  = None
        self.oast_url     = None


CONFIG = RuntimeConfig()
