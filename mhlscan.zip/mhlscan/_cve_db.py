# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_cve_db.py - Unified CVE database (KEV + EPSS + EDB + GitHub + Vendors)."""

import os, json, time, gzip, re
from pathlib import Path
from datetime import datetime, timezone
import requests

DB_DIR = Path.home() / ".mhlscan" / "cve_db"
DB_DIR.mkdir(parents=True, exist_ok=True)

KEV_URL = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"
EPSS_URL = "https://epss.cyentia.com/epss_scores-current.csv.gz"
GITHUB_API = "https://api.github.com/advisories"

TTL = {"kev": 86400, "epss": 86400, "exploitdb": 604800,
       "github": 86400, "vendor_fortinet": 43200, "vendor_paloalto": 43200,
       "vendor_cisco": 43200, "vendor_mikrotik": 43200, "vendor_juniper": 43200}


def _path(name):
    return DB_DIR / f"{name}.json"


def _should_refresh(name):
    p = _path(name)
    if not p.exists():
        return True
    ttl = TTL.get(name, 86400)
    return (time.time() - p.stat().st_mtime) > ttl


def _load(name):
    p = _path(name)
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text())
    except Exception:
        return {}


def _save(name, data):
    _path(name).write_text(json.dumps(data, indent=2))


# =========================================================
# SOURCE 1: CISA KEV
# =========================================================
def update_kev(force=False):
    if not force and not _should_refresh("kev"):
        print("  [=] KEV: cached, skip")
        return
    print("  [*] Downloading CISA KEV (~1300 actively exploited CVEs)...")
    try:
        r = requests.get(KEV_URL, timeout=60)
        r.raise_for_status()
        data = r.json()
        catalog = {}
        for v in data.get("vulnerabilities", []):
            catalog[v["cveID"]] = {
                "name": v.get("vulnerabilityName", ""),
                "vendor": v.get("vendorProject", ""),
                "product": v.get("product", ""),
                "dateAdded": v.get("dateAdded", ""),
                "ransomware": v.get("knownRansomwareCampaignUse", "Unknown") == "Known",
                "dueDate": v.get("dueDate", ""),
            }
        _save("kev", catalog)
        print(f"  [+] KEV: {len(catalog)} CVEs cached")
    except Exception as e:
        print(f"  [-] KEV failed: {e}")


# =========================================================
# SOURCE 2: EPSS
# =========================================================
def update_epss(force=False):
    if not force and not _should_refresh("epss"):
        print("  [=] EPSS: cached, skip")
        return
    print("  [*] Downloading EPSS scores (~50 MB compressed)...")
    import io
    try:
        r = requests.get(EPSS_URL, timeout=180, stream=True)
        r.raise_for_status()
        scores = {}
        with gzip.GzipFile(fileobj=io.BytesIO(r.content)) as gz:
            text = io.TextIOWrapper(gz, encoding="utf-8")
            next(text)  # skip header
            for line in text:
                parts = line.strip().split(",")
                if len(parts) >= 3 and parts[0].startswith("CVE-"):
                    try:
                        scores[parts[0]] = {
                            "epss": round(float(parts[1]), 4),
                            "percentile": round(float(parts[2]), 4),
                        }
                    except ValueError:
                        pass
        _save("epss", scores)
        print(f"  [+] EPSS: {len(scores)} CVE scores cached")
    except Exception as e:
        print(f"  [-] EPSS failed: {e}")

# =========================================================
# SOURCE 3: ExploitDB (searchsploit)
# =========================================================
def update_exploitdb(force=False):
    if not force and not _should_refresh("exploitdb"):
        print("  [=] ExploitDB: cached, skip")
        return
    import shutil, csv
    from pathlib import Path

    if not shutil.which("searchsploit"):
        print("  [-] searchsploit not installed (skip)")
        return

    csv_paths = [
        "/opt/exploitdb/files_exploits.csv",
        "/usr/share/exploitdb/files_exploits.csv",
        "/usr/local/share/exploitdb/files_exploits.csv",
    ]
    csv_file = None
    for p in csv_paths:
        if Path(p).exists():
            csv_file = p
            break

    if not csv_file:
        print("  [!] files_exploits.csv tidak ditemukan")
        _save("exploitdb", {})
        return

    print(f"  [*] Reading ExploitDB CSV ({csv_file})...")
    try:
        idx = {}
        total_rows = 0
        refs = 0
        with open(csv_file, "r", encoding="utf-8", errors="ignore") as f:
            reader = csv.DictReader(f)
            for row in reader:
                total_rows += 1
                codes = (row.get("codes", "") or "").strip()
                if not codes:
                    continue
                for token in codes.replace(",", ";").split(";"):
                    token = token.strip()
                    if not token.startswith("CVE-"):
                        continue
                    refs += 1
                    idx.setdefault(token, []).append({
                        "edb_id": row.get("id", ""),
                        "title": (row.get("description", "") or "")[:120],
                        "type": row.get("type", ""),
                        "platform": row.get("platform", ""),
                    })
        formatted = {}
        for cve, exploits in idx.items():
            formatted[cve] = {
                "available": True,
                "count": len(exploits),
                "ids": [e["edb_id"] for e in exploits[:10]],
                "exploits": exploits[:20],
            }
        _save("exploitdb", formatted)
        print(f"  [+] ExploitDB: {len(formatted)} CVE unik, {refs} referensi (dari {total_rows} exploit)")
    except Exception as e:
        print(f"  [-] ExploitDB CSV failed: {e}")



# =========================================================
# SOURCE 4: GitHub Advisory
# =========================================================
def update_github_advisory(force=False):
    token = os.environ.get("GITHUB_TOKEN", "")
    if not token:
        print("  [=] GitHub Advisory: skip (GITHUB_TOKEN not set)")
        print("      Setup: export GITHUB_TOKEN='ghp_xxx' (Settings → Developer → Personal access tokens)")
        return
    if not force and not _should_refresh("github"):
        print("  [=] GitHub Advisory: cached, skip")
        return
    print("  [*] Downloading GitHub Advisories...")
    advisories = {}
    try:
        headers = {"Authorization": f"Bearer {token}",
                   "Accept": "application/vnd.github+json"}
        page = 1
        while page <= 10:
            r = requests.get(GITHUB_API, headers=headers,
                             params={"per_page": 100, "page": page,
                                     "severity": "high,critical"},
                             timeout=30)
            if r.status_code != 200:
                break
            items = r.json()
            if not items:
                break
            for adv in items:
                for ident in adv.get("identifiers", []):
                    if ident.get("type") == "CVE":
                        advisories[ident["value"]] = {
                            "ghsa_id": adv.get("ghsa_id"),
                            "severity": adv.get("severity"),
                            "summary": adv.get("summary", "")[:200],
                        }
            page += 1
        _save("github", advisories)
        print(f"  [+] GitHub: {len(advisories)} advisories cached")
    except Exception as e:
        print(f"  [-] GitHub failed: {e}")


# =========================================================
# SOURCE 5: Vendor Feeds (best-effort)
# =========================================================
def update_vendor_feeds(force=False):
    """Vendor advisories — best effort RSS/scrape. Skip if fail."""
    print("  [*] Vendor feeds (best-effort)...")
    _update_fortinet(force)
    _update_paloalto(force)
    _update_cisco(force)


def _parse_rss_cves(xml_content):
    """Extract CVE IDs dari RSS content."""
    import xml.etree.ElementTree as ET
    cves = set()
    try:
        root = ET.fromstring(xml_content)
        for item in root.iter("item"):
            title = item.findtext("title", "") or ""
            desc = item.findtext("description", "") or ""
            for c in re.findall(r'CVE-\d{4}-\d+', title + " " + desc):
                cves.add(c)
    except Exception:
        pass
    return list(cves)


def _update_fortinet(force=False):
    if not force and not _should_refresh("vendor_fortinet"):
        return
    try:
        r = requests.get("https://www.fortiguard.com/rss/ir.xml", timeout=30)
        if r.status_code == 200:
            cves = _parse_rss_cves(r.content)
            _save("vendor_fortinet", {c: {"vendor": "fortinet"} for c in cves})
            print(f"    [+] Fortinet: {len(cves)} CVE")
    except Exception as e:
        print(f"    [-] Fortinet: {type(e).__name__}")


def _update_paloalto(force=False):
    if not force and not _should_refresh("vendor_paloalto"):
        return
    try:
        r = requests.get("https://security.paloaltonetworks.com/rss.xml", timeout=30)
        if r.status_code == 200:
            cves = _parse_rss_cves(r.content)
            _save("vendor_paloalto", {c: {"vendor": "paloalto"} for c in cves})
            print(f"    [+] Palo Alto: {len(cves)} CVE")
    except Exception as e:
        print(f"    [-] Palo Alto: {type(e).__name__}")


def _update_cisco(force=False):
    if not force and not _should_refresh("vendor_cisco"):
        return
    try:
        r = requests.get(
            "https://sec.cloudapps.cisco.com/security/center/rss/publicationRSS.x",
            timeout=30)
        if r.status_code == 200:
            cves = _parse_rss_cves(r.content)
            _save("vendor_cisco", {c: {"vendor": "cisco"} for c in cves})
            print(f"    [+] Cisco: {len(cves)} CVE")
    except Exception as e:
        print(f"    [-] Cisco: {type(e).__name__}")


# =========================================================
# AGGREGATE — UPDATE ALL
# =========================================================
def update_all():
    print()
    print("=" * 60)
    print(" UPDATING CVE DATABASE — ALL SOURCES")
    print("=" * 60)
    update_kev()
    update_epss()
    update_exploitdb()
    update_github_advisory()
    update_vendor_feeds()
    stats()


# =========================================================
# QUERY — look up 1 CVE across all sources
# =========================================================
def query(cve_id):
    r = {"cve": cve_id}

    kev = _load("kev")
    if cve_id in kev:
        r["kev"] = kev[cve_id]

    epss = _load("epss")
    if cve_id in epss:
        r["epss"] = epss[cve_id]

    edb = _load("exploitdb")
    if cve_id in edb:
        r["exploitdb"] = edb[cve_id]

    gh = _load("github")
    if cve_id in gh:
        r["github"] = gh[cve_id]

    for v in ["fortinet", "paloalto", "cisco"]:
        db = _load(f"vendor_{v}")
        if cve_id in db:
            r.setdefault("vendors", []).append(v)

    score = 0.0
    if r.get("kev"):
        score += 50.0
        if r["kev"].get("ransomware"):
            score += 20.0
    if r.get("epss"):
        score += r["epss"]["epss"] * 30.0
    if r.get("exploitdb"):
        score += 15.0
    r["priority_score"] = round(score, 1)

    return r


def stats():
    print()
    print("=" * 60)
    print(" CVE DATABASE STATUS")
    print("=" * 60)
    print(f"  {'Source':<20} {'Entries':>10}  {'Size':>10}  {'Age':>8}")
    print(f"  {'-'*20} {'-'*10}  {'-'*10}  {'-'*8}")
    for name in ["kev", "epss", "exploitdb", "github",
                 "vendor_fortinet", "vendor_paloalto", "vendor_cisco"]:
        p = _path(name)
        if p.exists():
            try:
                data = json.loads(p.read_text())
                age_h = (time.time() - p.stat().st_mtime) / 3600
                size_mb = p.stat().st_size / (1024 * 1024)
                print(f"  {name:<20} {len(data):>10}  {size_mb:>8.1f}MB  {age_h:>6.1f}h")
            except Exception:
                print(f"  {name:<20} {'corrupt':>10}")
        else:
            print(f"  {name:<20} {'-':>10}  {'-':>10}  {'-':>8}")
    print("=" * 60)
