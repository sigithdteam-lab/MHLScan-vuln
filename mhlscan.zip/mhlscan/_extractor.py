# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_extractor.py - Ekstrak info sensitif dari response body/header."""

import re


_PATTERNS = {
    "aws_keys": re.compile(r'AKIA[0-9A-Z]{16}'),
    "gcp_keys": re.compile(r'AIza[0-9A-Za-z\-_]{35}'),
    "github_tokens": re.compile(r'(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{36}'),
    "slack_tokens": re.compile(r'xox[baprs]-[A-Za-z0-9\-_]{10,}'),
    "jwt": re.compile(r'eyJ[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+'),
    "private_keys": re.compile(
        r'-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----'),
    "db_uris": re.compile(
        r'(?:mysql|postgres|postgresql|mongodb|mongodb\+srv|redis)://[^\s"\'<>]{4,200}'),
    "emails": re.compile(
        r'[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}'),
    "passwords_plain": re.compile(
        r'(?i)(?:password|passwd|pwd|pass)\s*[:=]\s*["\']([^"\']{3,80})["\']'),
    "bearer_tokens": re.compile(
        r'(?i)bearer\s+([A-Za-z0-9\-_.]{20,500})'),
    "basic_auth": re.compile(
        r'(?i)basic\s+([A-Za-z0-9+/=]{10,500})'),
}


def extract_from_response(body, headers=None, max_each=10):
    """Return dict {key: [values]} dari body + headers. Filter false positive."""
    result = {}
    if not body:
        body = ""
    if isinstance(body, bytes):
        try:
            body = body.decode("utf-8", "ignore")
        except Exception:
            body = ""

    # Batasi ukuran scan agar cepat
    body = body[:500000]

    for key, pat in _PATTERNS.items():
        try:
            matches = pat.findall(body)
            if not matches:
                continue
            if isinstance(matches[0], tuple):
                matches = [m[0] if isinstance(m, tuple) else m for m in matches]
            uniq = list(dict.fromkeys([m for m in matches if m and len(m) > 2]))
            if uniq:
                result[key] = uniq[:max_each]
        except Exception:
            pass

    if headers:
        hstr = str(headers)
        for key, pat in _PATTERNS.items():
            if key in result:
                continue
            try:
                m = pat.findall(hstr)
                if m:
                    result[key] = list(dict.fromkeys(m))[:max_each]
            except Exception:
                pass

    return result


def is_interesting(extracted):
    """True kalau ada credential/key yang benar-benar sensitif."""
    interesting_keys = ("aws_keys", "gcp_keys", "github_tokens",
                        "slack_tokens", "private_keys", "db_uris",
                        "bearer_tokens", "passwords_plain")
    return any(extracted.get(k) for k in interesting_keys)
