# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_nuclei.py — Dynamic Nuclei CVE loader (parallel download, no \\r issues)."""

import json
import subprocess
import shutil
import tempfile
from pathlib import Path
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests


INDEX_URL = ("https://raw.githubusercontent.com/projectdiscovery/"
             "nuclei-templates/main/cves.json")
RAW_BASE = ("https://raw.githubusercontent.com/projectdiscovery/"
            "nuclei-templates/main/")

CACHE_ROOT = Path.home() / ".mhlscan" / "nuclei"
INDEX_FILE = CACHE_ROOT / "index.json"

STACK_KEYWORDS = {
    # Web apps
    "wordpress":   ["wordpress", "wp-plugin", "wp-core"],
    "laravel":     ["laravel"],
    "codeigniter": ["codeigniter"],
    "drupal":      ["drupal"],
    "joomla":      ["joomla"],
    "magento":     ["magento"],
    "spring":      ["spring", "springboot"],
    "tomcat":      ["tomcat"],
    "wso2":        ["wso2"],
    # Network devices
    "mikrotik_routeros":  ["mikrotik", "routeros", "webfig", "winbox"],
    "cisco_ios":          ["cisco", "ios-xe", "ios xe"],
    "cisco_asa":          ["cisco asa", "adaptive security"],
    "juniper_junos":      ["juniper", "junos", "j-web", "jweb"],
    "huawei":             ["huawei", "quidway", "echolife"],
    "fortinet_fortigate": ["fortinet", "fortigate", "fortiweb", "fortios"],
    "paloalto_panos":     ["palo alto", "panos", "globalprotect"],
    "arista_eos":         ["arista", "eos"],
    "edgecore":           ["edgecore", "edge-core", "ecs"],
    "ubiquiti":           ["ubiquiti", "unifi", "airmax", "edgerouter"],
    "openwrt":            ["openwrt", "luci"],
    "pfsense":            ["pfsense"],
    "tp_link":            ["tp-link", "tplink"],
    "zte":                ["zte", "zxhn"],

    # === CVE 2025/2026 expanded coverage ===
    "traefik":            ["traefik"],
    "mlflow":             ["mlflow"],
    "openflagr":          ["openflagr", "flagr"],
    "lollms":             ["lollms"],
    "gitlab":             ["gitlab"],
    "jenkins":            ["jenkins"],
    "grafana":            ["grafana"],
    "kibana":             ["kibana", "elastic"],
    "jira":               ["jira", "atlassian"],
    "confluence":         ["confluence", "atlassian"],
    "bitbucket":          ["bitbucket", "atlassian"],
    "sharepoint":         ["sharepoint", "microsoftsharepoint"],
    "exchange":           ["exchange", "owa", "outlook"],
    "citrix":             ["citrix", "netscaler", "adc"],
    "ivanti":             ["ivanti", "pulse", "connect secure"],
    "sonicwall":          ["sonicwall", "sonic os"],
    "screenconnect":      ["screenconnect", "connectwise"],
    "zabbix":             ["zabbix"],
    "pandora":            ["pandora", "pandorafms"],
    "nagios":             ["nagios", "nagiosxi"],
    "solarwinds":         ["solarwinds"],
    "vmware_vcenter":     ["vcenter", "vsphere"],
    "vmware_esxi":        ["esxi", "vmware esxi"],
    "proxmox":            ["proxmox"],
    "apache_camel":       ["camel", "apache camel"],
    "apache_activemq":    ["activemq"],
    "apache_druid":       ["druid"],
    "apache_hadoop":      ["hadoop", "yarn"],
    "apache_nifi":        ["nifi"],
    "apache_ofbiz":       ["ofbiz"],
    "apache_solr":        ["solr"],
    "apache_storm":       ["storm"],
    "apache_struts":      ["struts"],
    "apache_superset":    ["superset"],
    "apache_zeppelin":    ["zeppelin"],
    "atlassian":          ["atlassian"],
    "autodesk":           ["autodesk"],
    "cisco_sd_wan":       ["sd-wan", "vmanage"],
    "citrix_sharefile":   ["sharefile"],
    "d-link":             ["d-link", "dlink"],
    "dell":               ["dell"],
    "f5_bigip":           ["bigip", "f5", "big-ip"],
    "hpe":                ["hpe", "aruba", "hp"],
    "ibm":                ["ibm", "websphere"],
    "lenovo":             ["lenovo"],
    "netgear":            ["netgear"],
    "oracle":             ["oracle", "weblogic", "ebs"],
    "paloalto_globalprotect": ["globalprotect"],
    "progress":           ["progress", "whatsup gold", "moveit"],
    "pulse_secure":       ["pulse secure", "pulse secure vpn"],
    "qnap":               ["qnap"],
    "samsung":            ["samsung"],
    "sap":                ["sap", "netweaver"],
    "synology":           ["synology", "dsm"],
    "veeam":              ["veeam"],
    "wordpress_plugin":   ["wp-plugin", "wordpress plugin"],
    "xerox":              ["xerox"],
    "zyxel":              ["zyxel"],

}

# === Auto-merge dengan dynamic stacks ===
# Setelah STACK_KEYWORDS didefinisikan, gabung dengan auto-generated
try:
    import _stack_dynamic
    _AUTO = _stack_dynamic.load_auto_stacks()
    for _stack, _info in _AUTO.items():
        _kws = _info.get("keywords", [])
        if _stack in STACK_KEYWORDS:
            _existing = set(STACK_KEYWORDS[_stack])
            _existing.update(_kws)
            STACK_KEYWORDS[_stack] = sorted(_existing)
        else:
            STACK_KEYWORDS[_stack] = _kws
    if _AUTO:
        print(f"[+] Auto-loaded {len(_AUTO)} dynamic stacks from nuclei index")
except Exception:
    pass


SEVERITY_ORDER = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}


def fetch_index(force=False):
    CACHE_ROOT.mkdir(parents=True, exist_ok=True)
    if INDEX_FILE.exists() and not force:
        age_h = (datetime.now(timezone.utc).timestamp()
                 - INDEX_FILE.stat().st_mtime) / 3600
        if age_h < 24:
            try:
                return json.loads(INDEX_FILE.read_text())
            except json.JSONDecodeError:
                pass
    print("  [*] Mengunduh indeks CVE dari Nuclei...")
    r = requests.get(INDEX_URL, timeout=60)
    r.raise_for_status()
    entries = []
    for line in r.text.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            entries.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    INDEX_FILE.write_text(json.dumps(entries))
    print(f"  [+] Indeks: {len(entries)} CVE templates cached")
    return entries


def load_index():
    if not INDEX_FILE.exists():
        return []
    try:
        return json.loads(INDEX_FILE.read_text())
    except json.JSONDecodeError:
        return []


def is_available():
    if not INDEX_FILE.exists():
        return False
    for s in STACK_KEYWORDS:
        if (CACHE_ROOT / s).exists() and any((CACHE_ROOT / s).glob("*.yaml")):
            return True
    return False


def _download_one(args):
    """Worker: download satu template. Return status string."""
    cve_id, rel_path, stack_dir = args
    dest = stack_dir / f"{cve_id}.yaml"
    if dest.exists():
        return "cached"
    try:
        r = requests.get(RAW_BASE + rel_path, timeout=20)
        if r.status_code == 200 and len(r.content) > 100:
            dest.write_text(r.text)
            return "downloaded"
        return "failed"
    except Exception:
        return "failed"


def update_stack(stack, min_severity="medium", workers=10):
    keywords = STACK_KEYWORDS.get(stack.lower())
    if not keywords:
        print(f"  [!] Stack '{stack}' tidak punya mapping keyword.")
        return 0

    stack_dir = CACHE_ROOT / stack
    stack_dir.mkdir(parents=True, exist_ok=True)

    entries = fetch_index()
    if not entries:
        print(f"  {RED}[!] Index Nuclei kosong! Gagal mengunduh cves.json.{ENDC}")
        return 0
    
    print(f"  [*] Total CVE di index: {len(entries)}")
    
    min_sev = SEVERITY_ORDER.get(min_severity, 2)
    matched = []
    for e in entries:
        info = e.get("Info", {})
        name = (info.get("Name") or "").lower()
        path = (e.get("file_path") or "").lower()
        sev = info.get("Severity", "info").lower()
        if SEVERITY_ORDER.get(sev, 0) < min_sev:
            continue
        if any(kw in name or kw in path for kw in keywords):
            matched.append(e)

    total = len(matched)
    print(f"  [*] {stack}: {total} template cocok, download paralel ({workers} workers)...")

    tasks = [(e.get("ID"), e.get("file_path"), stack_dir)
             for e in matched if e.get("ID") and e.get("file_path")]

    results = {"cached": 0, "downloaded": 0, "failed": 0}
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futures = {ex.submit(_download_one, t): t[0] for t in tasks}
        done = 0
        for fut in as_completed(futures):
            done += 1
            status = fut.result()
            results[status] = results.get(status, 0) + 1
            # Print progress tiap 20 item (pakai newline, bukan carriage return)
            if done % 20 == 0 or done == total:
                print(f"    [{stack}] {done}/{total} | "
                      f"dl={results['downloaded']} "
                      f"cache={results['cached']} "
                      f"fail={results['failed']}")

    manifest = {
        "stack": stack,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "keywords": keywords,
        "min_severity": min_severity,
        "matched": total,
        "downloaded": results["downloaded"],
        "cached": results["cached"],
        "failed": results["failed"],
    }
    (stack_dir / "_manifest.json").write_text(json.dumps(manifest, indent=2))
    print(f"  [+] {stack}: {results['downloaded']} baru, "
          f"{results['cached']} cached, {results['failed']} gagal")
          
    # PAKSA DOWNLOAD FALLBACK UNTUK NETWORK DEVICE
    if stack in NETDEV_CVE_LIST:
        download_netdev_fallback(stack)
        
    return results["downloaded"] + results["cached"]


def update_all(min_severity="high"):
    print("[*] Update SEMUA stack (dynamic, paralel)...")
    total = 0
    for stack in STACK_KEYWORDS:
        total += update_stack(stack, min_severity=min_severity)
    print(f"\n[+] Selesai: {total} template cached di {CACHE_ROOT}")
    return total


def get_templates_for_stack(stack, version=None):
    stack_dir = CACHE_ROOT / stack.lower()
    if not stack_dir.exists():
        return []
    
    templates = sorted(stack_dir.glob("*.yaml"))
    
    # VERSION-AWARE FILTERING
    if version and str(version) != "None":
        try:
            major_ver = int(str(version).split(".")[0])
            # Heuristik: WordPress 6+ rilis 2022+, Joomla 4+ rilis 2021+, Drupal 10+ rilis 2022+
            if stack in ("wordpress", "joomla") and major_ver >= 5:
                min_year = 2021
            elif stack == "drupal" and major_ver >= 9:
                min_year = 2021
            else:
                min_year = 2000 # Jangan filter jika tidak yakin
                
            filtered = []
            skipped = 0
            for t in templates:
                # Ekstrak tahun dari nama CVE-YYYY-XXXX
                import re
                match = re.search(r'CVE-(\d{4})-', t.name)
                if match:
                    cve_year = int(match.group(1))
                    if cve_year < min_year:
                        skipped += 1
                        continue
                filtered.append(t)
            
            if skipped > 0:
                print(f"  [*] Version-Aware Filter: Melewati {skipped} CVE usang (< {min_year})")
            return filtered
        except Exception:
            pass
            
    return templates


def has_binary():
    return shutil.which("nuclei") is not None


def run_nuclei(url, templates, timeout=120, concurrency=50,
                severity="critical,high", batch_size=50):
    if not has_binary():
        return False, "nuclei binary tidak ditemukan di PATH", []
    if not templates:
        return False, "tidak ada template", []
    all_findings = []
    total_batches = (len(templates) + batch_size - 1) // batch_size
    print(f"  [*] Menjalankan nuclei ({len(templates)} templates, "
          f"{total_batches} batch, c={concurrency})")
    for i in range(0, len(templates), batch_size):
        batch = templates[i:i + batch_size]
        n = i // batch_size + 1
        print(f"      Batch {n}/{total_batches} ({len(batch)} tmpl)...",
              end=' ', flush=True)
        tmp_dir = None
        try:
            tmp_dir = Path(tempfile.mkdtemp(prefix="mhlscan_"))
            for t in batch:
                (tmp_dir / t.name).write_text(t.read_text())
            cmd = ["nuclei", "-u", url, "-t", str(tmp_dir),
                   "-jsonl", "-no-color", "-severity", severity,
                   "-c", str(concurrency), "-rate-limit", "150",
                   "-timeout", "10", "-retries", "0", "-silent"]
            result = subprocess.run(cmd, capture_output=True, text=True,
                                    timeout=timeout)
            bf = []
            for line in result.stdout.splitlines():
                line = line.strip()
                if not line: continue
                try:
                    obj = json.loads(line)
                    bf.append({
                        "template_id": obj.get("template-id"),
                        "name": obj.get("info", {}).get("name"),
                        "severity": obj.get("info", {}).get("severity", "info"),
                        "matched_at": obj.get("matched-at"),
                    })
                except json.JSONDecodeError:
                    continue
            all_findings.extend(bf)
            print(f"✓ {len(bf)} finding(s)")
        except subprocess.TimeoutExpired:
            print(f"⚠ timeout")
        except Exception as e:
            print(f"✗ {type(e).__name__}")
        finally:
            if tmp_dir and tmp_dir.exists():
                shutil.rmtree(tmp_dir, ignore_errors=True)
    print(f"  [✓] Total: {len(all_findings)} findings")
    return True, "", all_findings


# CVE-only list (path dicari otomatis via GitHub API)
NETDEV_CVE_LIST = {
    "mikrotik_routeros": [
        "CVE-2018-14847", "CVE-2019-3924", "CVE-2023-30799",
        "CVE-2024-54772",
    ],
    "cisco_ios": [
        "CVE-2023-20198", "CVE-2023-20273", "CVE-2024-20399",
    ],
    "cisco_asa": ["CVE-2020-3187"],
    "juniper_junos": [
        "CVE-2023-36844", "CVE-2023-36845", "CVE-2024-21591",
    ],
    "fortinet_fortigate": [
        "CVE-2018-13379", "CVE-2022-40684", "CVE-2024-55591",
    ],
    "paloalto_panos": ["CVE-2024-0012", "CVE-2024-9474"],
    "huawei": ["CVE-2017-17215", "CVE-2018-10561"],
    "zte": ["CVE-2014-2321"],
}


def _github_search_cve_path(cve_id):
    """Cari path template Nuclei via GitHub API untuk CVE ID tertentu."""
    cache_file = CACHE_ROOT / "_path_cache" / f"{cve_id}.txt"
    cache_file.parent.mkdir(parents=True, exist_ok=True)
    if cache_file.exists():
        path = cache_file.read_text().strip()
        if path:
            return path
    
    try:
        url = f"https://api.github.com/search/code?q={cve_id}+repo:projectdiscovery/nuclei-templates+filename:{cve_id}.yaml"
        headers = {"Accept": "application/vnd.github+json", "User-Agent": "mhlscan"}
        r = requests.get(url, headers=headers, timeout=15)
        if r.status_code == 200:
            items = r.json().get("items", [])
            if items:
                path = items[0].get("path", "")
                if path:
                    cache_file.write_text(path)
                    return path
        elif r.status_code == 403:
            # Rate limit (60/hour tanpa token). Fallback ke path heuristic
            pass
    except Exception:
        pass
    
    # Fallback: tebak path standar
    year = cve_id.split("-")[1] if "-" in cve_id else "0000"
    for prefix in ["network/cves", "http/cves", "cloud/cves"]:
        heuristic = f"{prefix}/{year}/{cve_id}.yaml"
        try:
            test_url = f"https://raw.githubusercontent.com/projectdiscovery/nuclei-templates/main/{heuristic}"
            r = requests.head(test_url, timeout=5)
            if r.status_code == 200:
                cache_file.write_text(heuristic)
                return heuristic
        except Exception:
            pass
    
    return None


def download_netdev_fallback(stack):
    """Download network device CVE dengan path auto-detect via GitHub API."""
    cve_list = NETDEV_CVE_LIST.get(stack, [])
    if not cve_list:
        return 0

    stack_dir = CACHE_ROOT / stack
    stack_dir.mkdir(parents=True, exist_ok=True)
    base_url = "https://raw.githubusercontent.com/projectdiscovery/nuclei-templates/main/"
    downloaded = 0
    cached = 0
    failed = 0

    print(f"  [*] Auto-download {len(cve_list)} CVE untuk {stack}...")
    for cve_id in cve_list:
        dest = stack_dir / f"{cve_id}.yaml"
        if dest.exists():
            cached += 1
            continue
        
        path = _github_search_cve_path(cve_id)
        if not path:
            print(f"  [-] {cve_id}: path tidak ditemukan")
            failed += 1
            continue
        
        try:
            r = requests.get(base_url + path, timeout=15)
            if r.status_code == 200:
                dest.write_text(r.text)
                downloaded += 1
                print(f"  [+] {cve_id} ← {path}")
            else:
                print(f"  [-] {cve_id}: HTTP {r.status_code} ({path})")
                failed += 1
        except Exception as e:
            print(f"  [-] {cve_id}: {type(e).__name__}")
            failed += 1

    print(f"  [+] {stack}: {downloaded} baru, {cached} cached, {failed} gagal")
    return downloaded + cached

