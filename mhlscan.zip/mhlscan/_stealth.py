# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_stealth.py — Stealth layer (jitter + rotasi UA + rate limit + proxy rotate)."""

import warnings
try:
    from urllib3.exceptions import InsecureRequestWarning
    warnings.filterwarnings("ignore", category=InsecureRequestWarning)
except ImportError:
    pass

import time
import random
import threading
import string
from urllib.parse import urlparse

from urllib3.util import Retry


USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
    "Mozilla/5.0 (X11; Linux x86_64; rv:125.0) Gecko/20100101 Firefox/125.0",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:124.0) Gecko/20100101 Firefox/124.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (iPad; CPU OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 OPR/109.0.0.0",
    "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko",
]

ACCEPT_LANGS = [
    "en-US,en;q=0.9", "en-GB,en;q=0.9",
    "en-US,en;q=0.8,id;q=0.6", "id-ID,id;q=0.9,en;q=0.8",
    "en-US,en;q=0.9,fr;q=0.8", "de-DE,de;q=0.9,en;q=0.8",
]

ACCEPT_HEADERS = [
    "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
]


class RateLimiter:
    def __init__(self, rps=1.0):
        self.interval = 1.0 / rps if rps > 0 else 0
        self.last = {}
        self.lock = threading.Lock()

    def wait(self, host):
        if self.interval <= 0:
            return
        with self.lock:
            now = time.time()
            elapsed = now - self.last.get(host, 0)
            if elapsed < self.interval:
                time.sleep(self.interval - elapsed)
            self.last[host] = time.time()


class StealthPool:
    def __init__(self, base_pool, proxy_list=None,
                 jitter=(0.5, 2.0), rate_rps=1.0, rotate_ua=True,
                 timeout=None):
        self.base_pool = base_pool
        self.proxy_list = proxy_list or []
        self.jitter = jitter
        self.rotate_ua = rotate_ua
        self.rate = RateLimiter(rate_rps)
        self._p_idx = 0

        self._proxy_managers = []
        if self.proxy_list:
            from urllib3 import ProxyManager, Timeout
            t = timeout or Timeout(connect=5, read=10)
            for p in self.proxy_list:
                self._proxy_managers.append(
                    ProxyManager(proxy_url=p, timeout=t,
                                 cert_reqs='CERT_NONE', retries=False))

    def _pick_pool(self):
        if not self._proxy_managers:
            return self.base_pool
        pool = self._proxy_managers[self._p_idx]
        self._p_idx = (self._p_idx + 1) % len(self._proxy_managers)
        return pool

    def _build_headers(self, extra):
        h = {
            "Accept": random.choice(ACCEPT_HEADERS),
            "Accept-Language": random.choice(ACCEPT_LANGS),
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
            "Cache-Control": random.choice(["no-cache", "max-age=0", ""]),
        }
        if self.rotate_ua:
            h["User-Agent"] = random.choice(USER_AGENTS)
        if extra:
            h.update(extra)
        return h

    def _sleep_jitter(self):
        if self.jitter and self.jitter[1] > 0:
            time.sleep(random.uniform(self.jitter[0], self.jitter[1]))

    def request(self, method, url, headers=None, body=None, fields=None,
                redirect=False, timeout=None, **kw):
        host = urlparse(url).netloc
        self.rate.wait(host)
        self._sleep_jitter()
        h = self._build_headers(headers or {})
        pool = self._pick_pool()

        kwargs = {'headers': h, 'timeout': timeout}
        if body is not None:
            kwargs['body'] = body
        if fields is not None:
            kwargs['fields'] = fields
        kwargs.update(kw)

        if not redirect:
            kwargs['retries'] = Retry(total=0, redirect=0,
                                       raise_on_redirect=False)

        return pool.request(method, url, **kwargs)


def random_word(n=8):
    return "".join(random.choices(string.ascii_lowercase + string.digits, k=n))
