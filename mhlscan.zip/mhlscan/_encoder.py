# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_encoder.py - Payload encoding transformers."""

import base64
import urllib.parse
from html import escape as html_escape


def powershell_encoded(ps_command):
    """Base64 UTF-16-LE encoding untuk PowerShell -EncodedCommand.
    Bypass AMSI & simple AV signatures."""
    import base64
    return base64.b64encode(ps_command.encode("utf-16-le")).decode()


def url_encode(payload):
    return urllib.parse.quote(payload, safe="")


def double_url_encode(payload):
    return url_encode(url_encode(payload))


def html_entity(payload):
    return html_escape(payload, quote=True)


def unicode_escape(payload):
    return "".join("\\u{:04x}".format(ord(c)) for c in payload)


def base64_encode(payload):
    return base64.b64encode(payload.encode()).decode()


def hex_encode(payload):
    return "".join("\\x{:02x}".format(ord(c)) for c in payload)


def url_partial(payload):
    """Encode hanya karakter sensitif (bypass WAF ringan)."""
    keep = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    return "".join(c if c in keep else f"%{ord(c):02X}" for c in payload)


ENCODERS = {
    "none":    lambda p: p,
    "ps_b64":  powershell_encoded,
    "url":     url_encode,
    "url2":    double_url_encode,
    "urlp":    url_partial,
    "html":    html_entity,
    "unicode": unicode_escape,
    "b64":     base64_encode,
    "hex":     hex_encode,
}

ENCODING_ORDER = ["none", "url", "urlp", "html", "unicode", "url2", "b64", "ps_b64"]


def encode(payload, encoding="none"):
    """Encode payload dengan metode tertentu."""
    fn = ENCODERS.get(encoding)
    return fn(payload) if fn else payload


def try_all(payload, max_variants=4):
    """
    Generate multiple encoded variants untuk retry.
    Returns: list of (encoding_name, encoded_payload)
    """
    variants = []
    for enc in ENCODING_ORDER[:max_variants]:
        try:
            variants.append((enc, encode(payload, enc)))
        except Exception:
            continue
    return variants
