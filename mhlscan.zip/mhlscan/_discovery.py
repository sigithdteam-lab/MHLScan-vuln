# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_discovery.py - Multi-method host discovery + neighbor board.

Metode:
1. ICMP ping (via subprocess, paling universal)
2. TCP ping (connect ke port umum: 80, 443, 22, 445, 3389, 8080)
3. UDP ping (DNS/53, NTP/123, SNMP/161, mDNS/5353)
4. ARP scan (Linux: via /proc/net/arp + arping atau ARP broadcast)
5. Neighbor board (peta host hidup + MAC/vendor + gateway)

Tidak butuh scapy — pakai subprocess + socket + /proc/net/arp.
Scapy dipakai kalau tersedia (ARP scan lebih akurat).
"""

import os
import re
import socket
import struct
import subprocess
import sys
import time
import platform
from concurrent.futures import ThreadPoolExecutor, as_completed

# Cek scapy (opsional)
try:
    from scapy.all import ARP, Ether, srp, conf
    HAS_SCAPY = True
except ImportError:
    HAS_SCAPY = False


# =========================================================
# ICMP PING
# =========================================================
def icmp_ping(ip, timeout=1.0, count=1):
    """ICMP ping via subprocess. Return True kalau ada reply."""
    system = platform.system().lower()
    if system == "windows":
        cmd = ["ping", "-n", str(count), "-w", str(int(timeout * 1000)), ip]
    else:
        cmd = ["ping", "-c", str(count), "-W", str(max(1, int(timeout))), ip]

    try:
        r = subprocess.run(cmd, stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL,
                           timeout=timeout + 2)
        return r.returncode == 0
    except Exception:
        return False


# =========================================================
# TCP PING
# =========================================================
TCP_PING_PORTS = [80, 443, 22, 445, 3389, 8080, 23, 21, 1433, 3306]


def tcp_ping(ip, ports=None, timeout=1.0):
    """TCP connect ke beberapa port umum. Return (alive, port) atau (False, None)."""
    ports = ports or TCP_PING_PORTS
    for p in ports:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(timeout)
            if s.connect_ex((ip, p)) == 0:
                s.close()
                return True, p
            s.close()
        except Exception:
            continue
    return False, None


# =========================================================
# UDP PING
# =========================================================
def udp_ping(ip, ports=None, timeout=1.0):
    """UDP ping ke port yang biasanya reply: 53, 123, 161, 5353."""
    ports = ports or [53, 123, 161, 5353]
    for p in ports:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(timeout)
            # Payload UDP DNS query sederhana (untuk 53)
            if p == 53:
                payload = (b'\x00\x00\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00'
                           b'\x07example\x03com\x00\x00\x01\x00\x01')
            elif p == 123:
                payload = b'\x1b' + b'\x00' * 47  # NTP client request
            elif p == 161:
                payload = (b'\x30\x26\x02\x01\x01\x04\x06public'
                           b'\xa0\x19\x02\x04\x00\x00\x00\x01\x02\x01\x00'
                           b'\x02\x01\x00\x30\x0b\x30\x09\x06\x05\x2b\x06'
                           b'\x01\x02\x01\x01\x05\x00')
            else:
                payload = b'\x00'
            s.sendto(payload, (ip, p))
            try:
                data, _ = s.recvfrom(2048)
                s.close()
                if data:
                    return True, p
            except socket.timeout:
                pass
            s.close()
        except Exception:
            continue
    return False, None


# =========================================================
# ARP SCAN
# =========================================================
def _get_gateway_ip():
    """Ambil IP gateway default via /proc/net/route (Linux) atau route print (Win)."""
    system = platform.system().lower()
    if system == "linux":
        try:
            with open("/proc/net/route") as f:
                for line in f.readlines()[1:]:
                    parts = line.split()
                    if len(parts) < 3:
                        continue
                    if parts[1] == "00000000":
                        # Destination 0.0.0.0 = gateway
                        hex_ip = parts[2]
                        ip = ".".join(str(int(hex_ip[i:i+2], 16))
                                      for i in (6, 4, 2, 0))
                        return ip
        except Exception:
            pass
    return None


def _get_iface_netmask():
    """Ambil netmask interface utama. Return (iface, ip, netmask) atau None."""
    system = platform.system().lower()
    if system == "linux":
        try:
            r = subprocess.run(["ip", "-4", "addr", "show"],
                               capture_output=True, text=True, timeout=5)
            iface = None
            ip_addr = None
            mask = None
            for line in r.stdout.splitlines():
                m = re.match(r'^\d+:\s+(\S+):', line)
                if m:
                    iface = m.group(1)
                m2 = re.search(r'inet\s+(\d+\.\d+\.\d+\.\d+)/(\d+)', line)
                if m2 and iface and "lo" not in iface:
                    ip_addr = m2.group(1)
                    mask = int(m2.group(2))
                    return iface, ip_addr, mask
        except Exception:
            pass
    return None


def arp_scan_scapy(subnet, timeout=3):
    """ARP scan via scapy (butuh root). Return dict {ip: mac}."""
    if not HAS_SCAPY:
        return {}
    try:
        ans, _ = srp(
            Ether(dst="ff:ff:ff:ff:ff:ff") / ARP(pdst=subnet),
            timeout=timeout, verbose=False
        )
        result = {}
        for _, rcv in ans:
            result[rcv[ARP].psrc] = rcv[ARP].hwsrc
        return result
    except Exception:
        return {}


def arp_scan_proc(timeout=2):
    """ARP scan via /proc/net/arp (Linux). Return dict {ip: mac}."""
    if platform.system().lower() != "linux":
        return {}
    try:
        with open("/proc/net/arp") as f:
            lines = f.readlines()[1:]
        result = {}
        for line in lines:
            parts = line.split()
            if len(parts) >= 4 and parts[3] != "00:00:00:00:00:00":
                ip = parts[0]
                mac = parts[3]
                if mac and mac != "00:00:00:00:00:00":
                    result[ip] = mac
        return result
    except Exception:
        return {}


def arp_scan(subnet=None, timeout=3):
    """ARP scan: coba scapy, fallback ke /proc/net/arp."""
    if not subnet:
        info = _get_iface_netmask()
        if not info:
            return {}
        iface, ip_addr, prefix = info
        import ipaddress
        try:
            net = ipaddress.ip_network(f"{ip_addr}/{prefix}", strict=False)
            subnet = str(net)
        except Exception:
            return {}

    if HAS_SCAPY:
        try:
            if os.geteuid() == 0:
                result = arp_scan_scapy(subnet, timeout)
                if result:
                    return result
        except Exception:
            pass

    # Fallback /proc/net/arp
    return arp_scan_proc()


# =========================================================
# MAC VENDOR LOOKUP (OUI mini)
# =========================================================
OUI_VENDORS = {
    "00:50:56": "VMware", "00:0C:29": "VMware", "00:05:69": "VMware",
    "08:00:27": "VirtualBox", "52:54:00": "QEMU/KVM",
    "00:16:3E": "Xen", "00:15:5D": "Hyper-V",
    "B8:27:EB": "Raspberry Pi", "DC:A6:32": "Raspberry Pi",
    "00:1B:44": "SanDisk", "00:1A:2B": "Cisco",
    "00:00:0C": "Cisco", "00:1A:A1": "Cisco", "00:1E:13": "Cisco",
    "00:1B:0C": "Cisco", "00:1E:BD": "Cisco", "00:24:97": "Cisco",
    "00:1C:14": "VMware", "00:0D:3A": "Microsoft",
    "00:0F:66": "MikroTik", "08:55:31": "MikroTik",
    "6C:3B:6B": "MikroTik", "74:4D:28": "MikroTik",
    "B8:69:F4": "MikroTik", "CC:2D:E0": "MikroTik",
    "D4:CA:6D": "MikroTik", "E4:8D:8C": "MikroTik",
    "DC:2C:6E": "MikroTik", "18:FD:74": "MikroTik",
    "00:09:0F": "Fortinet", "08:5B:0E": "Fortinet",
    "70:4C:A5": "Fortinet", "90:6C:AC": "Fortinet",
    "00:1B:17": "Palo Alto", "00:1B:17:5C": "Palo Alto",
    "B4:0C:25": "Palo Alto", "D4:F4:BE": "Palo Alto",
    "00:0B:86": "Aruba", "00:1A:1E": "Aruba",
    "00:0F:B5": "Netgear", "00:18:4D": "Netgear",
    "00:1C:10": "Cisco-Linksys", "00:1E:E5": "Cisco-Linksys",
    "F4:F2:6D": "TP-Link", "50:C7:BF": "TP-Link",
    "14:CC:20": "TP-Link", "A4:2B:B0": "TP-Link",
    "00:1B:11": "D-Link", "00:1C:F0": "D-Link",
    "00:1E:58": "D-Link", "F0:7D:68": "D-Link",
    "00:0C:42": "RouterOS", "00:0C:43": "RouterOS",
    "2C:3A:E8": "Espressif", "84:F3:EB": "Espressif",
    "AC:67:B2": "Espressif", "24:0A:C4": "Espressif",
    "00:1A:A0": "Dell", "00:14:22": "Dell",
    "00:1B:21": "Intel", "00:1E:67": "Intel",
    "3C:97:0E": "Intel", "B4:96:91": "Intel",
    "F4:8E:38": "Intel", "00:16:EA": "Intel",
}


def mac_vendor(mac):
    if not mac:
        return None
    m = mac.upper().replace("-", ":")
    prefix = ":".join(m.split(":")[:3])
    return OUI_VENDORS.get(prefix)


# =========================================================
# HOST DISCOVERY (multi-method)
# =========================================================
def discover_host(ip, methods=None, timeout=1.5):
    """Coba berbagai metode discovery. Return dict hasil atau None."""
    methods = methods or ["arp", "icmp", "tcp", "udp"]
    result = {
        "ip": ip,
        "alive": False,
        "method": None,
        "mac": None,
        "vendor": None,
        "open_tcp_port": None,
        "open_udp_port": None,
    }

    # ARP sudah ditangani di level subnet (arp_scan), jadi cek dari cache
    if "arp" in methods:
        arp = arp_scan_proc()
        if ip in arp:
            result["alive"] = True
            result["method"] = "arp"
            result["mac"] = arp[ip]
            result["vendor"] = mac_vendor(arp[ip])
            return result

    if "icmp" in methods:
        if icmp_ping(ip, timeout=timeout):
            result["alive"] = True
            result["method"] = "icmp"
            return result

    if "tcp" in methods:
        alive, port = tcp_ping(ip, timeout=timeout)
        if alive:
            result["alive"] = True
            result["method"] = "tcp"
            result["open_tcp_port"] = port
            return result

    if "udp" in methods:
        alive, port = udp_ping(ip, timeout=timeout)
        if alive:
            result["alive"] = True
            result["method"] = "udp"
            result["open_udp_port"] = port
            return result

    return None


def discover_subnet(cidr, methods=None, workers=100, timeout=1.5,
                    max_hosts=1024):
    """Discovery subnet dengan multi-method.

    Return dict {
        live: [{ip, method, mac, vendor, open_tcp_port, open_udp_port}],
        dead_count: int,
        total: int,
        duration: float,
        gateway: str | None,
        iface: str | None,
    }
    """
    import ipaddress
    start = time.time()

    try:
        net = ipaddress.ip_network(cidr, strict=False)
    except ValueError as e:
        return {"error": str(e), "live": [], "total": 0}

    hosts = list(net.hosts())
    if len(hosts) > max_hosts:
        hosts = hosts[:max_hosts]

    methods = methods or ["arp", "icmp", "tcp"]
    print(f"  [*] Discovery {cidr} ({len(hosts)} host, methods={methods})")

    # 1. ARP scan dulu (paling cepat untuk LAN)
    arp_result = {}
    if "arp" in methods:
        print(f"    [*] ARP scan...")
        arp_result = arp_scan(str(net), timeout=3)
        print(f"    [+] ARP: {len(arp_result)} host")

    # 2. ICMP/TCP/UDP scan paralel
    live = []
    for ip_str, mac in arp_result.items():
        try:
            import ipaddress as _ip
            if _ip.ip_address(ip_str) in net:
                live.append({
                    "ip": ip_str,
                    "alive": True,
                    "method": "arp",
                    "mac": mac,
                    "vendor": mac_vendor(mac),
                    "open_tcp_port": None,
                    "open_udp_port": None,
                })
        except Exception:
            pass

    already = {r["ip"] for r in live}
    pending = [str(h) for h in hosts if str(h) not in already]

    if pending:
        done = 0
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futures = {ex.submit(discover_host, ip, methods, timeout): ip
                       for ip in pending}
            for fut in as_completed(futures):
                done += 1
                try:
                    r = fut.result()
                    if r and r["alive"]:
                        live.append(r)
                except Exception:
                    pass
                if done % 50 == 0:
                    print(f"    progress: {done}/{len(pending)} probed, "
                          f"{len(live)} live")

    duration = time.time() - start
    print(f"  {chr(27)}[32m[+] Live: {len(live)}/{len(hosts)} "
          f"({duration:.1f}s){chr(27)}[0m")

    iface_info = _get_iface_netmask()
    return {
        "cidr": cidr,
        "live": live,
        "dead_count": len(hosts) - len(live),
        "total": len(hosts),
        "duration": round(duration, 2),
        "gateway": _get_gateway_ip(),
        "iface": iface_info[0] if iface_info else None,
    }


# =========================================================
# NEIGHBOR BOARD
# =========================================================
def build_neighbor_board(cidr, discovery_result=None):
    """Bangun peta topologi subnet.

    Return dict {
        subnet, gateway, iface,
        hosts: [{ip, mac, vendor, method, likely_role}],
        by_vendor: {vendor: [ip]},
        likely_routers: [ip],
        likely_servers: [ip],
        likely_workstations: [ip],
    }
    """
    if discovery_result is None:
        discovery_result = discover_subnet(cidr)

    live = discovery_result.get("live", [])
    gateway_ip = discovery_result.get("gateway")
    iface = discovery_result.get("iface")

    hosts = []
    by_vendor = {}
    likely_routers = []
    likely_servers = []
    likely_workstations = []

    for h in live:
        ip = h["ip"]
        mac = h.get("mac")
        vendor = h.get("vendor") or "unknown"
        method = h.get("method")
        open_tcp = h.get("open_tcp_port")

        role = "unknown"
        if ip == gateway_ip:
            role = "gateway"
            likely_routers.append(ip)
        elif vendor and any(v in vendor.lower()
                            for v in ["mikrotik", "cisco", "juniper",
                                      "fortinet", "palo", "arista",
                                      "ubiquiti", "tp-link", "d-link",
                                      "netgear", "huawei", "zte"]):
            role = "network_device"
            likely_routers.append(ip)
        elif open_tcp in (22, 3389):
            role = "server_remote"
            likely_servers.append(ip)
        elif open_tcp in (80, 443, 8080, 8443):
            role = "server_web"
            likely_servers.append(ip)
        elif method in ("arp", "icmp"):
            role = "workstation"
            likely_workstations.append(ip)

        hosts.append({
            "ip": ip, "mac": mac, "vendor": vendor,
            "method": method, "likely_role": role,
        })
        by_vendor.setdefault(vendor, []).append(ip)

    return {
        "subnet": cidr,
        "gateway": gateway_ip,
        "iface": iface,
        "total_live": len(hosts),
        "hosts": sorted(hosts, key=lambda x: _ip_sort_key(x["ip"])),
        "by_vendor": by_vendor,
        "likely_routers": likely_routers,
        "likely_servers": likely_servers,
        "likely_workstations": likely_workstations,
    }


def _ip_sort_key(ip):
    try:
        return tuple(int(x) for x in ip.split("."))
    except Exception:
        return (999, 999, 999, 999)


def format_neighbor_board(board):
    """Format board untuk print di console."""
    lines = []
    lines.append("")
    lines.append(f"  {'=' * 70}")
    lines.append(f"  NEIGHBOR BOARD - {board['subnet']}")
    lines.append(f"  {'=' * 70}")
    lines.append(f"  Gateway : {board.get('gateway') or '?'}")
    lines.append(f"  Iface   : {board.get('iface') or '?'}")
    lines.append(f"  Live    : {board.get('total_live', 0)} host")
    lines.append("")

    if board.get("likely_routers"):
        lines.append(f"  Router / Network Devices ({len(board['likely_routers'])}):")
        for ip in board["likely_routers"][:20]:
            info = next((h for h in board["hosts"] if h["ip"] == ip), {})
            lines.append(f"    - {ip:<16} {info.get('vendor', '?')} "
                         f"({info.get('mac', '?')})")
        lines.append("")

    if board.get("likely_servers"):
        lines.append(f"  Servers ({len(board['likely_servers'])}):")
        for ip in board["likely_servers"][:20]:
            info = next((h for h in board["hosts"] if h["ip"] == ip), {})
            lines.append(f"    - {ip:<16} role={info.get('likely_role', '?')} "
                         f"{info.get('vendor', '')}")
        lines.append("")

    if board.get("likely_workstations"):
        lines.append(f"  Workstations ({len(board['likely_workstations'])}):")
        for ip in board["likely_workstations"][:20]:
            info = next((h for h in board["hosts"] if h["ip"] == ip), {})
            lines.append(f"    - {ip:<16} {info.get('vendor', '?')}")
        if len(board["likely_workstations"]) > 20:
            lines.append(f"    ... +{len(board['likely_workstations']) - 20}")
        lines.append("")

    if board.get("by_vendor"):
        lines.append("  By Vendor:")
        for vendor, ips in sorted(board["by_vendor"].items(),
                                  key=lambda x: -len(x[1]))[:10]:
            lines.append(f"    - {vendor:<20} {len(ips)} host")
        lines.append("")

    lines.append(f"  {'=' * 70}")
    return "\n".join(lines)


# =========================================================
# STATUS
# =========================================================
def status():
    info = _get_iface_netmask()
    return {
        "scapy": HAS_SCAPY,
        "iface": info[0] if info else None,
        "local_ip": info[1] if info else None,
        "prefix": info[2] if info else None,
        "gateway": _get_gateway_ip(),
        "methods": ["arp", "icmp", "tcp", "udp"],
    }
