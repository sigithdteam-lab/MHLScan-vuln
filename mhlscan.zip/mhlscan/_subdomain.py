# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_subdomain.py - Subdomain enumeration + IP grouping + protocol probe."""

import socket, subprocess, shutil, json, time, ssl
from urllib.parse import urlparse
from concurrent.futures import ThreadPoolExecutor, as_completed


WORDLIST = [
    "www", "mail", "ftp", "webmail", "smtp", "pop", "ns1", "webdisk", "ns2",
    "cpanel", "whm", "autodiscover", "autoconfig", "m", "imap", "test", "ns",
    "blog", "pop3", "dev", "www2", "admin", "forum", "news", "vpn", "ns3",
    "mail2", "new", "mysql", "old", "lists", "support", "mobile", "mx", "static",
    "docs", "beta", "shop", "sql", "secure", "demo", "cp", "calendar", "wiki",
    "web", "media", "email", "images", "img", "www1", "intranet", "portal",
    "video", "sip", "dns2", "api", "cdn", "stats", "dns1", "ns4", "www3",
    "dns", "search", "staging", "server", "mx1", "chat", "wap", "my", "svn",
    "mail1", "sites", "proxy", "ads", "host", "crm", "cms", "backup", "mx2",
    "info", "apps", "download", "remote", "db", "forums", "store", "relay",
    "files", "live", "newsletter", "app", "internal", "demo2", "beta2", "help",
    "pay", "vpn2", "cloud", "aws", "azure", "s3", "jenkins", "git", "gitlab",
    "jira", "confluence", "monitor", "grafana", "prometheus", "kibana",
    "elastic", "staging2", "dev2", "qa", "uat", "prod", "sandbox", "preview",
    "uat2", "dev3", "staging3", "test2", "admin2", "sso", "auth", "login",
]

INTERESTING_KW = [
    "dev", "staging", "test", "qa", "uat", "admin", "api", "internal",
    "debug", "backup", "old", "beta", "jenkins", "git", "jira", "monitor",
    "sandbox", "preview", "prod"
]

TWO_PART_TLDS = {
    "co.id", "or.id", "web.id", "my.id", "net.id", "ac.id", "sch.id",
    "go.id", "mil.id", "biz.id", "desa.id", "ponpes.id", "co.uk",
    "org.uk", "ac.uk", "gov.uk", "com.au", "net.au", "org.au",
    "co.jp", "or.jp", "ne.jp", "com.br", "com.sg", "com.my",
}


import ipaddress as _ipaddress


def classify_target(target):
    host = urlparse(target if "://" in target else "http://" + target).hostname
    if not host:
        return {"type": "unknown", "host": None, "base": None}

    try:
        _ipaddress.ip_address(host)
        return {"type": "ip", "host": host, "base": None}
    except ValueError:
        pass

    base = get_base_domain(host)
    is_root = (host == base or host == "www." + base)
    return {
        "type": "root_domain" if is_root else "subdomain",
        "host": host,
        "base": base,
    }


def get_base_domain(hostname):
    hostname = hostname.lower().strip()
    if hostname.startswith("www."):
        hostname = hostname[4:]
    parts = hostname.split(".")
    if len(parts) >= 3 and ".".join(parts[-2:]) in TWO_PART_TLDS:
        return ".".join(parts[-3:])
    elif len(parts) >= 2:
        return ".".join(parts[-2:])
    return hostname


def _resolve(hostname):
    try:
        return socket.gethostbyname(hostname)
    except Exception:
        return None


def _has_subfinder():
    return shutil.which("subfinder") is not None

def _has_amass():
    return shutil.which("amass") is not None


def _run_amass(domain, timeout=180):
    try:
        r = subprocess.run(
            ["amass", "enum", "-d", domain, "-passive",
             "-timeout", "2", "-silent"],
            capture_output=True, text=True, timeout=timeout)
        return [l.strip() for l in r.stdout.splitlines()
                if l.strip() and l.strip().endswith(domain)]
    except Exception:
        return []


def detect_wildcard_dns(domain):
    """Cek apakah domain punya wildcard DNS aktif."""
    import os
    token = "__mhlscan_wild_" + os.urandom(4).hex()
    try:
        socket.gethostbyname(f"{token}.{domain}")
        return True
    except socket.gaierror:
        return False
    except Exception:
        return False


def _run_subfinder(domain, timeout=120):
    try:
        r = subprocess.run(["subfinder", "-d", domain, "-silent", "-all"],
                          capture_output=True, text=True, timeout=timeout)
        return [l.strip() for l in r.stdout.splitlines() if l.strip()]
    except Exception:
        return []


def _run_crtsh(domain, timeout=15):
    try:
        import urllib.request
        url = f"https://crt.sh/?q=%25.{domain}&output=json"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.loads(r.read().decode("utf-8", "ignore"))
        names = set()
        for e in data:
            for n in e.get("name_value", "").split("\n"):
                n = n.strip().lower()
                if n.endswith("." + domain) and "*" not in n:
                    names.add(n)
        return list(names)
    except Exception:
        return []


def _brute(domain, workers=50, timeout=3):
    found = []
    candidates = [f"{w}.{domain}" for w in WORDLIST]

    def _check(h):
        try:
            old = socket.getdefaulttimeout()
            socket.setdefaulttimeout(timeout)
            try:
                return (h, socket.gethostbyname(h))
            finally:
                socket.setdefaulttimeout(old)
        except Exception:
            return None

    with ThreadPoolExecutor(max_workers=workers) as ex:
        futures = [ex.submit(_check, h) for h in candidates]
        for fut in as_completed(futures):
            r = fut.result()
            if r: found.append(r)
    return found


def probe_protocol(hostname, timeout=2):
    import urllib3
    urllib3.disable_warnings()
    try:
        p = urllib3.PoolManager(cert_reqs='CERT_NONE', timeout=timeout,
                                retries=False)
        r = p.request('HEAD', f'https://{hostname}', redirect=False)
        if r.status < 500:
            return 'https'
    except Exception:
        pass
    try:
        p = urllib3.PoolManager(cert_reqs='CERT_NONE', timeout=timeout,
                                retries=False)
        r = p.request('HEAD', f'http://{hostname}', redirect=False)
        if r.status < 500:
            return 'http'
    except Exception:
        pass
    return None


def sort_by_interest(hosts):
    def score(h):
        first = h.split('.')[0].lower()
        return 0 if any(k in first for k in INTERESTING_KW) else 1
    return sorted(hosts, key=score)


def enumerate_subdomains(domain, aggressive=False, workers=50, timeout=3):
    domain = get_base_domain(domain)
    result = {"domain": domain, "sources": {}, "unique": [], "resolved_ips": {},
              "groups": {}, "wildcard_dns": False,
              "stats": {"total": 0, "resolved": 0}}
    all_subs = set()

    result["wildcard_dns"] = detect_wildcard_dns(domain)
    if result["wildcard_dns"]:
        print(f"    {chr(27)}[33m[!] Wildcard DNS aktif — hasil resolve bisa false positive{chr(27)}[0m")

    if _has_subfinder():
        print(f"    [*] subfinder...")
        subs = _run_subfinder(domain)
        result["sources"]["subfinder"] = subs
        all_subs.update(subs)
        print(f"    [+] subfinder: {len(subs)}")

    if _has_amass():
        print(f"    [*] amass (passive)...")
        subs = _run_amass(domain)
        result["sources"]["amass"] = subs
        all_subs.update(subs)
        print(f"    [+] amass: {len(subs)}")

    print(f"    [*] crt.sh (passive)...")
    subs = _run_crtsh(domain)
    result["sources"]["crt.sh"] = subs
    all_subs.update(subs)
    print(f"    [+] crt.sh: {len(subs)}")

    if aggressive:
        print(f"    [*] DNS brute ({len(WORDLIST)} kata)...")
        pairs = _brute(domain, workers=workers, timeout=timeout)
        subs = [h for h, ip in pairs]
        result["sources"]["brute"] = subs
        all_subs.update(subs)
        print(f"    [+] brute: {len(subs)}")

    print(f"    [*] Resolving {len(all_subs)} hostname...")
    for sub in all_subs:
        ip = _resolve(sub)
        if ip:
            result["resolved_ips"][sub] = ip
            result["groups"].setdefault(ip, []).append(sub)

    result["unique"] = sort_by_interest(list(result["resolved_ips"].keys()))
    result["stats"]["total"] = len(all_subs)
    result["stats"]["resolved"] = len(result["unique"])
    return result


def prepare_scan_targets(enum_result, max_targets=50):
    hosts = enum_result["unique"][:max_targets]
    targets = []
    print(f"    [*] Validasi DNS & probe protocol untuk {len(hosts)} host...")

    def _check_host(h):
        if not _resolve(h):
            return None
        proto = probe_protocol(h)
        if proto:
            return f"{proto}://{h}"
        return None

    with ThreadPoolExecutor(max_workers=20) as ex:
        futures = {ex.submit(_check_host, h): h for h in hosts}
        for fut in as_completed(futures):
            res = fut.result()
            if res:
                targets.append(res)
    return targets
