# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_aspnet_waf.py - ASP.NET Request Validation + WAF detection."""

import re


ASPX_SIGNATURES = [
    {
        "id": "aspnet-request-validation",
        "name": "ASP.NET Request Validation",
        "type": "framework_protection",
        "code": 500,
        "page": re.compile(
            r'ASP\.NET has detected data in the request that is potentially dangerous|'
            r'Request Validation has detected a potentially dangerous client input value|'
            r'HttpRequestValidationException',
            re.I),
        "headers": None,
        "severity": "info",
    },
    {
        "id": "aspnet-waf-generic",
        "name": "ASP.NET WAF",
        "type": "waf",
        "code": 403,
        "page": re.compile(
            r'<title>403 - Forbidden: Access is denied\.</title>|'
            r'<h1>403 - Forbidden: Access is denied\.</h1>',
            re.I),
        "headers": None,
        "severity": "info",
    },
    {
        "id": "urlscan",
        "name": "UrlScan (Microsoft)",
        "type": "waf",
        "code": None,
        "page": re.compile(r'Rejected-By-UrlScan', re.I),
        "headers": re.compile(r'Rejected-By-UrlScan', re.I),
        "severity": "info",
    },
    {
        "id": "iis-server",
        "name": "Microsoft-IIS",
        "type": "server",
        "code": None,
        "page": None,
        "headers": re.compile(r'Microsoft-IIS', re.I),
        "severity": "info",
    },
]


def detect_aspnet_waf(response):
    if response is None:
        return None

    status = response.status
    headers = str(response.headers).lower()
    body = (response.data or b'')[:10000].decode('utf-8', 'ignore')

    for sig in ASPX_SIGNATURES:
        code_ok = (sig["code"] is None or status == sig["code"])
        page_ok = (sig["page"] is None or sig["page"].search(body))
        header_ok = (sig["headers"] is None or sig["headers"].search(headers))

        if code_ok and (page_ok or header_ok):
            return {
                "detected": True,
                "waf": sig["name"],
                "type": sig["type"],
                "severity": sig["severity"],
                "evidence": f"code={status}, page={bool(page_ok)}, headers={bool(header_ok)}",
            }

    return None
