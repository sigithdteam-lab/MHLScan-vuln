# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_version.py — Deteksi versi framework (fleksibel semua versi)."""

import re


SERVER_STACKS = {"nginx", "apache", "iis", "tomcat", "jboss", "wso2"}

MAX_MAJOR = {}


def _text(r, n=16384):
    return (r.data or b'')[:n].decode('utf-8', 'ignore')


def _req(pool, url, timeout=5):
    try:
        return pool.request('GET', url, timeout=timeout, redirect=False)
    except Exception:
        return None


def _regex_first(pattern, text, group=1):
    m = re.search(pattern, text, re.IGNORECASE)
    if not m:
        return None
    try:
        return m.group(group)
    except (IndexError, re.error):
        return None


def _validate_version(stack, version):
    return version if version else None


PROBES = {
    "wordpress": [
        ("/", r'<meta[^>]+name=["\']generator["\'][^>]+content=["\']WordPress\s+([\d.]+)', "high"),
        ("/feed/", r'<generator>https://wordpress\.org/\?v=([\d.]+)</generator>', "high"),
    ],
    "joomla": [
        ("/administrator/manifests/files/joomla.xml", r'<version>([\d.]+)</version>', "high"),
        ("/language/en-GB/en-GB.xml", r'<version>([\d.]+)</version>', "high"),
        ("/", r'content=["\']Joomla!\s*-?\s*([\d.]+)', "high"),
    ],
    "drupal": [
        ("/CHANGELOG.txt", r'Drupal\s+([\d.]+),\s+\d{4}-', "high"),
        ("/core/lib/Drupal.php", r"const VERSION = '([\d.]+)'", "high"),
        ("/", r'content=["\']Drupal\s+([\d.]+)', "high"),
    ],
    "laravel": [
        ("/composer.json", r'"laravel/framework"\s*:\s*"\^?([\d.]+)', "high"),
    ],
    "codeigniter": [
        ("/composer.json", r'"codeigniter4/framework"\s*:\s*"\^?([\d.]+)', "high"),
    ],
    "spring": [
        ("/actuator/info", r'"version"\s*:\s*"([\d.]+)"', "high"),
    ],
    "tomcat": [
        ("/docs/", r'Apache Tomcat/([\d.]+)', "high"),
        ("/RELEASE-NOTES.txt", r'Apache Tomcat Version\s+([\d.]+)', "high"),
    ],
}


def _parse_header(server_hdr):
    if not server_hdr:
        return None, None
    for pat, label in [
        (r'WildFly/([\d.]+)', "WildFly"),
        (r'JBoss[- ]?EAP/([\d.]+)', "JBoss EAP"),
        (r'JBoss[- ]?AS/([\d.]+)', "JBoss AS"),
        (r'Apache[- ]Tomcat/([\d.]+)', "Tomcat"),
        (r'Apache-Coyote/([\d.]+)', "Tomcat (Coyote)"),
        (r'nginx/([\d.]+)', "Nginx"),
        (r'Apache/([\d.]+)', "Apache"),
        (r'Microsoft-IIS/([\d.]+)', "IIS"),
    ]:
        m = re.search(pat, server_hdr, re.IGNORECASE)
        if m:
            return m.group(1), label
    return None, None


def detect_version(url, pool, stack, timeout=5):
    conf_rank = {"none": 0, "low": 1, "medium": 2, "high": 3}
    best = {"version": None, "confidence": "none", "evidence": ""}

    r = _req(pool, url, timeout)
    if r:
        v, label = _parse_header(r.headers.get('Server', ''))
        if v:
            best = {"version": v, "confidence": "medium",
                    "evidence": "Server: " + label}

    if not stack or stack == "unknown":
        return best

    for path, pattern, conf in PROBES.get(stack, []):
        if conf_rank[conf] <= conf_rank[best["confidence"]]:
            continue
        full = url.rstrip('/') + path
        r2 = _req(pool, full, timeout)
        if not r2 or r2.status not in (200, 301, 302):
            continue
        v = _regex_first(pattern, _text(r2))
        if v:
            best = {"version": v, "confidence": conf, "evidence": path}

    if not best["version"]:
        best["confidence"] = "none"
    return best
