# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_paramdiscovery.py - Parameter discovery (Arjun-class).

Cari parameter hidden di endpoint dengan:
1. HTML form + JS parsing
2. Wordlist-based probing (dengan deteksi reflection)
3. Header parameter discovery
"""

import re
import requests
import urllib3
from concurrent.futures import ThreadPoolExecutor, as_completed

urllib3.disable_warnings()


COMMON_PARAMS = [
    # Command / exec
    "cmd", "command", "exec", "execute", "run", "shell", "system",
    "ping", "query", "q",
    # File / path
    "file", "path", "dir", "folder", "filename", "fp", "doc",
    "url", "uri", "src", "source", "target", "dest", "redirect",
    "download", "upload", "include", "require", "load", "read",
    # ID / selection
    "id", "uid", "user_id", "item", "key", "pid", "page_id", "no",
    "index", "num", "n", "page", "p", "offset", "limit", "count",
    # Auth
    "user", "username", "email", "pass", "password", "passwd", "pwd",
    "token", "session", "auth", "api_key", "apikey", "key", "secret",
    "access_token", "refresh_token", "jwt", "otp",
    # Format
    "format", "type", "mode", "method", "action", "do", "op", "operation",
    "output", "callback", "debug", "test", "verbose",
    # API
    "api", "version", "v", "v1", "v2", "endpoint", "service",
    "request", "response", "data", "payload", "body", "input",
    # HTML
    "lang", "language", "locale", "country", "region", "timezone",
    "theme", "template", "layout", "view", "display", "style",
    # Misc
    "search", "s", "term", "filter", "sort", "order", "orderby",
    "group", "category", "tag", "label", "title", "name",
    "message", "comment", "note", "text", "content", "value", "val",
    "opt", "option", "config", "setting", "param", "args",
    "return", "next", "back", "link", "ref", "referrer",
]


def _detect_reflection(base_resp, test_resp, marker):
    """Deteksi apakah marker muncul di response."""
    if not test_resp:
        return False
    text = test_resp.text or ""
    if marker in text:
        return True
    # Cek di headers
    for v in test_resp.headers.values():
        if marker in str(v):
            return True
    return False


def discover_from_html(url, timeout=10):
    """Ekstrak parameter dari HTML + JS halaman."""
    params = set()
    try:
        r = requests.get(url, timeout=timeout, verify=False)
        html = r.text or ""
        # Form fields
        for m in re.finditer(r'name=["\']([A-Za-z_][\w\-\.]{0,50})["\']', html):
            params.add(m.group(1))
        # JS URL query
        for m in re.finditer(r'[?&]([A-Za-z_][\w\-\.]{0,50})=', html):
            params.add(m.group(1))
        # searchParams.get()
        for m in re.finditer(
            r'(?:searchParams|params|query)\.get\(["\']([\w\-]{1,50})["\']',
            html):
            params.add(m.group(1))
        # data attribute
        for m in re.finditer(r'data-([\w\-]{1,50})=', html):
            params.add(m.group(1))
    except Exception:
        pass
    return params


def discover_bruteforce(url, known_params=None, wordlist=None,
                        workers=20, timeout=8, min_delta=100,
                        max_found=50):
    """Bruteforce parameter: kirim ?param=marker, cek reflection/status change.

    Return list dict {param, evidence, type}.
    """
    known_params = set(known_params or [])
    wordlist = wordlist or COMMON_PARAMS

    # Baseline
    try:
        baseline = requests.get(url, timeout=timeout, verify=False)
        base_len = len(baseline.text or "")
        base_status = baseline.status_code
        base_hash = hash(baseline.text or "")
    except Exception:
        return []

    found = []

    def _probe(param):
        marker = "MHL_" + param.upper() + "_9x7z"
        try:
            sep = "&" if "?" in url else "?"
            test_url = f"{url}{sep}{param}={marker}"
            r = requests.get(test_url, timeout=timeout, verify=False)
            if not r:
                return None
            text = r.text or ""

            # Reflection check (paling kuat)
            if marker in text:
                return {"param": param, "type": "reflection",
                        "evidence": f"Marker reflected in response"}

            # Status code change
            if r.status_code != base_status and r.status_code in (200, 302, 500):
                if r.status_code == 500:
                    return {"param": param, "type": "error",
                            "evidence": f"HTTP 500 with param"}

            # Length change (delta > min_delta)
            delta = abs(len(text) - base_len)
            if delta >= min_delta:
                return {"param": param, "type": "length_delta",
                        "evidence": f"Response length delta {delta}"}

        except Exception:
            pass
        return None

    candidates = [p for p in wordlist if p not in known_params][:500]
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futures = {ex.submit(_probe, p): p for p in candidates}
        for fut in as_completed(futures):
            try:
                r = fut.result()
                if r:
                    found.append(r)
                    if len(found) >= max_found:
                        break
            except Exception:
                pass

    return found


def discover_headers(url, timeout=8):
    """Cari header khusus yang mungkin di-handle server."""
    common_headers = [
        "X-Forwarded-For", "X-Real-IP", "X-Originating-IP",
        "X-Remote-IP", "X-Remote-Addr", "X-Client-IP", "X-Host",
        "X-Forwarded-Host", "X-Original-URL", "X-Rewrite-URL",
        "X-Forwarded-Proto", "X-Forwarded-Scheme",
        "X-HTTP-Method-Override", "X-Method-Override",
    ]
    found = []
    try:
        base = requests.get(url, timeout=timeout, verify=False)
        base_status = base.status_code
        base_len = len(base.text or "")
    except Exception:
        return found

    for h in common_headers:
        try:
            r = requests.get(url, headers={h: "127.0.0.1"},
                             timeout=timeout, verify=False)
            if r.status_code != base_status or \
               abs(len(r.text or "") - base_len) > 200:
                found.append({
                    "header": h,
                    "status_delta": r.status_code - base_status,
                    "length_delta": len(r.text or "") - base_len,
                })
        except Exception:
            pass

    return found


def discover_all(url, timeout=10):
    """Gabungan: html + bruteforce + headers."""
    print(f"    [*] Discovering params for {url}...")
    html_params = discover_from_html(url, timeout=timeout)
    print(f"    [+] From HTML: {len(html_params)}")

    found = discover_bruteforce(url, known_params=html_params, timeout=timeout)
    print(f"    [+] From bruteforce: {len(found)}")

    headers = discover_headers(url, timeout=timeout)
    if headers:
        print(f"    [+] Headers: {len(headers)}")

    return {
        "url": url,
        "html_params": sorted(html_params),
        "bruteforce_findings": found,
        "header_findings": headers,
    }


def status():
    return {
        "wordlist_size": len(COMMON_PARAMS),
        "methods": ["html_parse", "bruteforce", "header_probe"],
    }
