# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_auth.py - Authentication manager (form, cookie, step-based)."""

import json
import time
from pathlib import Path
from urllib.parse import urljoin


class AuthConfig:
    def __init__(self, data):
        self.data = data
        self.login_url = data.get("login_url")
        self.username_selector = data.get("username_selector")
        self.password_selector = data.get("password_selector")
        self.username = data.get("username")
        self.password = data.get("password")
        self.submit_selector = data.get("submit_selector")
        self.success_selector = (
            data.get("success_indicator") or data.get("success_selector"))
        self.steps = data.get("steps")
        self.cookies = data.get("cookies")

    def is_step_based(self):
        return bool(self.steps)

    def is_cookie_only(self):
        return bool(self.cookies) and not self.login_url


class AuthManager:
    def __init__(self, config, pool):
        self.config = config
        self.pool = pool
        self.cookies = {}

    def login(self):
        """Perform login. Return (success, cookies_dict, error)."""
        if not self.config:
            return False, {}, "no auth config"

        if self.config.is_cookie_only():
            cookies = self._parse_cookie_string(self.config.cookies)
            self.cookies = cookies
            return True, cookies, None

        if not self.config.login_url:
            return False, {}, "no login_url"

        if self.config.is_step_based():
            return self._login_step_based()

        return self._login_simple()

    def _login_simple(self):
        """Simple form login (username/password POST)."""
        data = {
            self.config.username_selector.lstrip("#").lstrip("."): self.config.username,
            self.config.password_selector.lstrip("#").lstrip("."): self.config.password,
        }

        body = "&".join(k + "=" + v for k, v in data.items())

        try:
            r = self.pool.request(
                'POST', self.config.login_url,
                body=body.encode(),
                headers={
                    "Content-Type": "application/x-www-form-urlencoded",
                    "User-Agent": "Mozilla/5.0",
                },
                timeout=15, redirect=False,
            )

            cookies = self._extract_cookies(r)
            self.cookies = cookies

            if self.config.success_selector:
                body_text = (r.data or b"").decode("utf-8", "ignore")
                sel = self.config.success_selector.lstrip("#").lstrip(".")
                if sel in body_text:
                    return True, cookies, None
                return False, cookies, "success_selector not found"

            if r.status in (200, 301, 302):
                return True, cookies, None
            return False, cookies, "HTTP " + str(r.status)
        except Exception as e:
            return False, {}, type(e).__name__ + ": " + str(e)

    def _login_step_based(self):
        """Step-based flow (JSON steps)."""
        try:
            for step in self.config.steps:
                action = step.get("action")
                if action == "goto":
                    self.pool.request('GET', step["url"], timeout=15)
                elif action == "fill":
                    # POST sebagai form data sederhana
                    body = (step["selector"].lstrip("#").lstrip(".")
                            + "=" + step["value"])
                    self.pool.request(
                        'POST', self.config.login_url,
                        body=body.encode(),
                        headers={"Content-Type": "application/x-www-form-urlencoded"},
                        timeout=15,
                    )
                elif action == "click":
                    pass  # diabaikan tanpa browser
                elif action == "wait_for_timeout":
                    time.sleep((step.get("ms") or 500) / 1000)
            return True, self.cookies, None
        except Exception as e:
            return False, {}, type(e).__name__ + ": " + str(e)

    def _extract_cookies(self, response):
        cookies = {}
        try:
            for header, value in response.headers.items():
                if header.lower() == "set-cookie":
                    for cookie in value.split(","):
                        part = cookie.split(";")[0]
                        if "=" in part:
                            k, v = part.split("=", 1)
                            cookies[k.strip()] = v.strip()
        except Exception:
            pass
        return cookies

    def _parse_cookie_string(self, s):
        cookies = {}
        if not s:
            return cookies
        for cookie in s.split(";"):
            part = cookie.strip()
            if "=" in part:
                k, v = part.split("=", 1)
                cookies[k.strip()] = v.strip()
        return cookies

    def request_headers(self):
        """Return headers with cookies for authenticated requests."""
        if not self.cookies:
            return {}
        cookie_str = "; ".join(k + "=" + v for k, v in self.cookies.items())
        return {"Cookie": cookie_str}


def load_auth_config(path):
    """Load auth config dari file JSON."""
    try:
        data = json.loads(Path(path).read_text())
        return AuthConfig(data)
    except Exception as e:
        print("[auth] Load failed: " + str(e))
        return None
