# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_cve_intel.py - CVE Intelligence via NVD API (NIST)."""
import requests
import json
import time
import urllib.parse
import os
from pathlib import Path

CACHE_DIR = Path.home() / ".mhlscan" / "nvd_cache"
CACHE_DIR.mkdir(parents=True, exist_ok=True)

CPE_MAPPING = {
    "wordpress": "cpe:2.3:a:wordpress:wordpress",
    "drupal": "cpe:2.3:a:drupal:drupal",
    "joomla": "cpe:2.3:a:joomla:joomla",
    "laravel": "cpe:2.3:a:laravel:laravel",
    "codeigniter": "cpe:2.3:a:codeigniter:codeigniter",
    "magento": "cpe:2.3:a:magento:magento",
    "spring": "cpe:2.3:a:vmware:spring_framework",
    "tomcat": "cpe:2.3:a:apache:tomcat",
    "wso2": "cpe:2.3:a:wso2:api_manager",
    "nginx": "cpe:2.3:a:nginx:nginx",
    "apache": "cpe:2.3:a:apache:http_server",
    "iis": "cpe:2.3:a:microsoft:internet_information_services",
    "jboss": "cpe:2.3:a:redhat:jboss_enterprise_application_platform",
    "mikrotik_routeros": "cpe:2.3:o:mikrotik:routeros",
    "cisco_ios": "cpe:2.3:o:cisco:ios",
    "cisco_ios_xe": "cpe:2.3:o:cisco:ios_xe",
    "cisco_asa": "cpe:2.3:o:cisco:adaptive_security_appliance_software",
    "juniper_junos": "cpe:2.3:o:juniper:junos",
    "fortinet_fortigate": "cpe:2.3:o:fortinet:fortios",
    "paloalto_panos": "cpe:2.3:o:paloaltonetworks:pan-os",
    "huawei": "cpe:2.3:o:huawei:versatile_routing_platform",
    "arista_eos": "cpe:2.3:o:arista:eos",
    "edgecore": "cpe:2.3:o:edgecore:ecs",
    "ubiquiti": "cpe:2.3:o:ui:unifi_os",
    "openwrt": "cpe:2.3:o:openwrt:openwrt",
    "pfsense": "cpe:2.3:a:pfsense:pfsense",
    "tp_link": "cpe:2.3:h:tp-link:tp-link_router",
    "zte": "cpe:2.3:h:zte:zxhn",
}


def get_cves_from_nvd(stack, version):
    cpe_base = CPE_MAPPING.get(stack)
    if not cpe_base or not version:
        return []

    version = str(version).strip()
    cpe_name = f"{cpe_base}:{version}"

    cache_file = CACHE_DIR / f"{stack}_{version}.json"
    if cache_file.exists():
        age_days = (time.time() - cache_file.stat().st_mtime) / 86400
        if age_days < 7:
            try:
                return json.loads(cache_file.read_text())
            except Exception:
                pass

    api_key = os.environ.get("NVD_API_KEY", "").strip()
    headers = {"apiKey": api_key} if api_key else {}
    delay = 0.6 if api_key else 6.0

    print(f"    [*] Query NVD API untuk {stack} v{version}...")
    url = "https://services.nvd.nist.gov/rest/json/cves/2.0"
    params = {"cpeName": cpe_name, "isVulnerable": ""}

    try:
        time.sleep(delay)
        r = requests.get(url, params=params, headers=headers, timeout=15)
        if r.status_code != 200:
            return []

        data = r.json()
        vulns = data.get("vulnerabilities", [])

        results = []
        for v in vulns:
            cve = v.get("cve", {})
            cve_id = cve.get("id")

            metrics = cve.get("metrics", {})
            score = 0.0
            severity = "info"
            if "cvssMetricV31" in metrics:
                score = metrics["cvssMetricV31"][0]["cvssData"]["baseScore"]
                severity = metrics["cvssMetricV31"][0]["cvssData"]["baseSeverity"].lower()
            elif "cvssMetricV30" in metrics:
                score = metrics["cvssMetricV30"][0]["cvssData"]["baseScore"]
                severity = metrics["cvssMetricV30"][0]["cvssData"]["baseSeverity"].lower()

            desc = ""
            for d in cve.get("descriptions", []):
                if d.get("lang") == "en":
                    desc = d.get("value", "")
                    break

            results.append({
                "id": cve_id,
                "score": score,
                "severity": severity,
                "description": desc,
                "source": "nvd-api",
            })

        cache_file.write_text(json.dumps(results))
        print(f"    [+] NVD: {len(results)} CVE ditemukan untuk {stack} v{version}")
        return results

    except Exception as e:
        print(f"    [-] NVD error: {e}")
        return []
