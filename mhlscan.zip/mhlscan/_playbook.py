# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_playbook.py - Service playbook: filter checker per service."""

SERVICE_PLAYBOOK = {
    "ssh": {
        "ports": [22, 2222, 22022],
        "category": "remote_access",
        "checkers": ["ssh"],
    },
    "ftp": {
        "ports": [21, 2121],
        "category": "remote_access",
        "checkers": ["ftp"],
    },
    "http": {
        "ports": [80, 8000, 8080, 8081, 8888, 3000, 5000, 9000],
        "category": "web",
        "checkers": [],
    },
    "https": {
        "ports": [443, 8443],
        "category": "web_ssl",
        "checkers": [],
    },
    "mysql": {
        "ports": [3306, 33060],
        "category": "database",
        "checkers": ["mysql"],
    },
    "postgresql": {
        "ports": [5432],
        "category": "database",
        "checkers": ["postgresql"],
    },
    "redis": {
        "ports": [6379],
        "category": "cache",
        "checkers": ["redis"],
    },
    "mongodb": {
        "ports": [27017, 27018],
        "category": "database",
        "checkers": ["mongodb"],
    },
    "memcached": {
        "ports": [11211],
        "category": "cache",
        "checkers": ["memcached"],
    },
    "elasticsearch": {
        "ports": [9200, 9300],
        "category": "search",
        "checkers": ["elasticsearch"],
    },
    "smb": {
        "ports": [445, 139],
        "category": "file_sharing",
        "checkers": ["smb"],
    },
    "rdp": {
        "ports": [3389],
        "category": "remote_access",
        "checkers": [],
    },
    "vnc": {
        "ports": [5900, 5901],
        "category": "remote_access",
        "checkers": ["vnc"],
    },
    "docker": {
        "ports": [2375, 2376],
        "category": "container",
        "checkers": ["docker"],
    },
    "telnet": {
        "ports": [23],
        "category": "remote_access",
        "checkers": ["telnet"],
    },
}


def get_playbook(service_name):
    svc = (service_name or "").lower()
    for key, pb in SERVICE_PLAYBOOK.items():
        if key in svc or svc in key:
            return pb
    return {"ports": [], "category": "unknown", "checkers": []}


def allowed_checkers(service_name):
    return get_playbook(service_name).get("checkers", [])
