# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_stack_dynamic.py - Auto-generate STACK_KEYWORDS dari Nuclei index.

Parse ~/.mhlscan/nuclei/index.json, ekstrak stack keyword dari setiap CVE,
simpan ke ~/.mhlscan/nuclei/auto_stacks.json.

Update otomatis setiap --update-nuclei.
"""

import json
import re
from pathlib import Path
from datetime import datetime

NUCLEI_ROOT = Path.home() / ".mhlscan" / "nuclei"
INDEX_FILE = NUCLEI_ROOT / "index.json"
AUTO_STACKS_FILE = NUCLEI_ROOT / "auto_stacks.json"

# Regex untuk ekstrak nama produk dari CVE name
# Contoh: "MLflow Job API - Authentication Bypass" -> "mlflow"
#         "Traefik - Authentication Bypass" -> "traefik"
#         "LolLMS <= 2.2.0 - File Upload" -> "lollms"
_PRODUCT_PATTERNS = [
    # "Product <= version - vuln type"
    re.compile(r"^([A-Za-z][A-Za-z0-9_\- ]{1,40}?)\s+(?:<|<=|=|>|>=)\s*[\d\.]+\s*-", re.I),
    # "Product - vuln type" (dash separator)
    re.compile(r"^([A-Za-z][A-Za-z0-9_\- ]{1,40}?)\s+-\s+", re.I),
    # "Product Wordpress Plugin ..."
    re.compile(r"^([A-Za-z][A-Za-z0-9_\- ]{1,40}?)\s+(?:plugin|theme|module|component|extension)\b", re.I),
]

# Stop words yang bukan produk
_STOP_WORDS = {
    "wp", "wordpress", "plugin", "theme", "module", "component",
    "cve", "remote", "local", "unauth", "unauthenticated",
    "arbitrary", "code", "execution", "rce", "lfi", "ssrf", "xss",
    "sqli", "sql", "injection", "path", "traversal", "auth",
    "authentication", "bypass", "disclosure", "upload", "file",
    "server", "sensitive", "information", "privilege",
    "escalation", "denial", "service", "dos", "csrf",
    "cross", "site", "scripting", "xxe", "xml", "external",
    "entity", "open", "redirect", "deserialization",
    "vulnerability", "exploit", "poc", "detection", "version",
    "the", "a", "an", "and", "or", "for", "with", "via",
    "multiple", "various", "all", "any",
}

# Path stack dari Nuclei (misal http/cves/2026/CVE-2026-XXXX.yaml)
_PATH_STACK_PATTERNS = {
    "http": None,  # skip generic
    "network": None,
    "cloud": None,
    "dns": None,
}


def _normalize(name):
    """Normalisasi nama produk: lowercase, hapus non-alnum kecuali dash."""
    if not name:
        return ""
    name = name.lower().strip()
    name = re.sub(r"[^a-z0-9\-_ ]", "", name)
    name = re.sub(r"\s+", "-", name)
    name = name.strip("-")
    return name


def _is_valid_stack(name):
    if not name or len(name) < 2 or len(name) > 30:
        return False
    if name in _STOP_WORDS:
        return False
    # Harus ada minimal 1 huruf
    if not re.search(r"[a-z]", name):
        return False
    return True


def _extract_product(cve_name):
    """Ekstrak nama produk dari CVE name."""
    if not cve_name:
        return None
    for pat in _PRODUCT_PATTERNS:
        m = pat.match(cve_name)
        if m:
            candidate = m.group(1).strip()
            normalized = _normalize(candidate)
            if _is_valid_stack(normalized):
                return normalized
    return None


def _extract_from_path(file_path):
    """Ekstrak hint stack dari file path Nuclei."""
    if not file_path:
        return None
    # Contoh: http/cves/2026/CVE-2026-0545.yaml -> None (generic)
    # Contoh: http/cves/wordpress/CVE-2026-0594.yaml -> "wordpress"
    parts = file_path.lower().split("/")
    for part in parts:
        if part in ("http", "network", "cloud", "dns", "cves", "cve"):
            continue
        if re.match(r"^cve-\d{4}-\d+$", part):
            continue
        if re.match(r"^\d{4}$", part):
            continue
        # Kalau ada folder nama produk, ambil
        if len(part) > 2 and _is_valid_stack(part):
            return part
    return None


def _extract_from_tags(tags):
    """Ekstrak keyword dari Nuclei tags."""
    if not tags:
        return []
    result = []
    for tag in tags:
        if isinstance(tag, str):
            tag_low = tag.lower().strip()
            if _is_valid_stack(tag_low):
                result.append(tag_low)
    return result


def build_auto_stacks():
    """Parse Nuclei index, generate {stack: [keywords]}."""
    if not INDEX_FILE.exists():
        print(f"  [!] Nuclei index tidak ada: {INDEX_FILE}")
        print(f"      Jalankan: python3 mhlscan.py --update-nuclei")
        return {}

    try:
        index = json.loads(INDEX_FILE.read_text())
    except Exception as e:
        print(f"  [!] Gagal baca index: {e}")
        return {}

    print(f"  [*] Parsing {len(index)} template...")

    stacks = {}
    cve_count = 0

    for entry in index:
        cve_id = entry.get("ID", "")
        if not cve_id.startswith("CVE-"):
            continue

        # Filter tahun (2024-2026)
        try:
            year = int(cve_id.split("-")[1])
        except (IndexError, ValueError):
            continue
        if year < 2024:
            continue

        cve_count += 1

        name = entry.get("Info", {}).get("Name", "")
        file_path = entry.get("file_path", "")
        tags = entry.get("Info", {}).get("Tags", [])
        severity = (entry.get("Info", {}).get("Severity") or "").lower()

        # Ekstrak stack dari berbagai sumber
        candidates = set()

        # 1. Dari name
        product = _extract_product(name)
        if product:
            candidates.add(product)

        # 2. Dari path
        path_stack = _extract_from_path(file_path)
        if path_stack:
            candidates.add(path_stack)

        # 3. Dari tags
        for tag in _extract_from_tags(tags):
            candidates.add(tag)

        # Simpan
        for stack in candidates:
            stacks.setdefault(stack, {
                "cves": [],
                "keywords": set(),
                "count": 0,
            })
            stacks[stack]["cves"].append(cve_id)
            stacks[stack]["count"] += 1

            # Keyword tambahan: nama produk, nama stack
            if product and product != stack:
                stacks[stack]["keywords"].add(product)
            stacks[stack]["keywords"].add(stack)

    # Konversi sets ke lists, batasi CVE per stack
    result = {}
    for stack, data in stacks.items():
        if data["count"] < 1:
            continue
        result[stack] = {
            "keywords": sorted(data["keywords"]),
            "cve_count": data["count"],
            "sample_cves": sorted(data["cves"])[:10],
        }

    print(f"  [+] {cve_count} CVE 2024-2026 diproses")
    print(f"  [+] {len(result)} stack terdeteksi")

    # Statistik
    top = sorted(result.items(), key=lambda x: -x[1]["cve_count"])[:20]
    print(f"  [+] Top 20 stack (by CVE count):")
    for stack, info in top:
        print(f"      {stack:<25} {info['cve_count']} CVE")

    # Simpan
    AUTO_STACKS_FILE.parent.mkdir(parents=True, exist_ok=True)
    AUTO_STACKS_FILE.write_text(json.dumps({
        "generated_at": datetime.now().isoformat(),
        "total_cves": cve_count,
        "total_stacks": len(result),
        "stacks": result,
    }, indent=2))

    print(f"  [+] Saved: {AUTO_STACKS_FILE}")
    return result


def load_auto_stacks():
    """Load auto_stacks.json kalau ada."""
    if not AUTO_STACKS_FILE.exists():
        return {}
    try:
        data = json.loads(AUTO_STACKS_FILE.read_text())
        return data.get("stacks", {})
    except Exception:
        return {}


def merge_with_static(static_stacks):
    """Gabung static STACK_KEYWORDS dengan auto-generated."""
    auto = load_auto_stacks()
    merged = dict(static_stacks)

    for stack, info in auto.items():
        keywords = info.get("keywords", [])
        if stack in merged:
            # Gabung keyword
            existing = set(merged[stack]) if isinstance(merged[stack], list) else set()
            existing.update(keywords)
            merged[stack] = sorted(existing)
        else:
            # Tambah stack baru
            merged[stack] = keywords

    return merged


def status():
    auto = load_auto_stacks()
    return {
        "auto_stacks_file": str(AUTO_STACKS_FILE),
        "auto_stacks_exists": AUTO_STACKS_FILE.exists(),
        "total_stacks": len(auto),
        "top_10": sorted(
            [(s, info.get("cve_count", 0)) for s, info in auto.items()],
            key=lambda x: -x[1]
        )[:10],
    }


if __name__ == "__main__":
    build_auto_stacks()
