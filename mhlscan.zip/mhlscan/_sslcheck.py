# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_sslcheck.py - SSL certificate expiry check."""

import socket
import ssl
from datetime import datetime, timezone


def check_cert(host, port=443, timeout=10):
    """Return dict {expires, days_left, expired, warning, severity} atau None."""
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        with socket.create_connection((host, port), timeout=timeout) as sock:
            with ctx.wrap_socket(sock, server_hostname=host) as ss:
                cert = ss.getpeercert()
                if not cert:
                    return None
                not_after = cert.get("notAfter")
                if not not_after:
                    return None
                try:
                    # Format OpenSSL: "Jun  1 00:00:00 2025 GMT"
                    from email.utils import parsedate_to_datetime
                    exp = parsedate_to_datetime(not_after)
                    if exp.tzinfo is None:
                        exp = exp.replace(tzinfo=timezone.utc)
                except Exception:
                    return None

                now = datetime.now(timezone.utc)
                delta = exp - now
                days = delta.days

                if days < 0:
                    severity = "high"
                    warning = "EXPIRED"
                elif days < 7:
                    severity = "medium"
                    warning = "Expires within 7 days"
                elif days < 30:
                    severity = "low"
                    warning = "Expires within 30 days"
                else:
                    severity = "info"
                    warning = None

                return {
                    "host": host,
                    "port": port,
                    "expires": not_after,
                    "days_left": days,
                    "expired": days < 0,
                    "warning": warning,
                    "severity": severity,
                }
    except Exception:
        return None
