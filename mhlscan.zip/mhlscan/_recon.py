# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_recon.py - Port scan + service detect + OS + DB + headers + cookies."""

import socket
import ssl
import re
import subprocess
import http.client
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlparse

NL = chr(10)
CRLF = bytes([13, 10])

PORTS_COMMON = [
    21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 443, 445,
    993, 995, 1433, 1521, 2049, 2375, 3306, 3389, 5432, 5900, 5984,
    6379, 7001, 8000, 8009, 8080, 8081, 8443, 8888, 9000, 9090,
    9200, 9300, 10000, 11211, 27017,
    # Network devices (Mikrotik, Cisco, Juniper, dll)
    8291, 8728, 8729, 830, 23, 2000, 4443, 4433,
]

SERVICE_MAP = {
    21: "ftp", 22: "ssh", 23: "telnet", 25: "smtp", 53: "dns",
    80: "http", 110: "pop3", 111: "rpcbind", 135: "msrpc",
    139: "netbios", 143: "imap", 443: "https", 445: "smb",
    993: "imaps", 995: "pop3s", 1433: "mssql", 1521: "oracle",
    2049: "nfs", 2375: "docker", 3306: "mysql", 3389: "rdp",
    5432: "postgresql", 5900: "vnc", 5984: "couchdb",
    6379: "redis", 7001: "weblogic", 8000: "http-alt",
    8009: "ajp", 8080: "http-alt", 8081: "http-alt",
    8443: "https-alt", 8888: "http-alt", 9000: "http-alt",
    9090: "http-alt", 9200: "elasticsearch", 9300: "es-transport",
    10000: "webmin", 11211: "memcached", 27017: "mongodb",
    # Network devices
    8291: "mikrotik-winbox", 8728: "mikrotik-api", 8729: "mikrotik-api-ssl",
    830: "netconf", 23: "telnet", 2000: "cisco-sccp",
    4443: "cisco-anyconnect", 4433: "juniper-ssl",
}

DB_PORTS = {
    3306: "mysql", 5432: "postgresql", 27017: "mongodb",
    6379: "redis", 9200: "elasticsearch", 1433: "mssql",
    1521: "oracle", 5984: "couchdb", 11211: "memcached",
}

COOKIE_FINGERPRINTS = {
    "php": [b"phpsessid"],
    "java": [b"jsessionid"],
    "aspnet": [b"asp.net_sessionid", b"aspxauth"],
    "laravel": [b"laravel_session", b"xsrf-token"],
    "codeigniter": [b"ci_session"],
    "django": [b"csrftoken"],
    "rails": [b"_session_id", b"_rails_session"],
    "wordpress": [b"wordpress_test_cookie", b"wordpress_logged_in", b"wp-settings"],
    "joomla": [b"joomla_session"],
    "drupal": [b"ssess", b"sess"],
    "magento": [b"frontend", b"adminhtml"],
}


def scan_port(host, port, timeout=2):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        r = s.connect_ex((host, port))
        s.close()
        return r == 0
    except Exception:
        return False


def grab_banner(host, port, timeout=3):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect((host, port))
        if port in (80, 8000, 8080, 8081, 8888, 9000, 9090):
            s.send(b"HEAD / HTTP/1.0" + CRLF + b"Host: " + host.encode() + CRLF + CRLF)
        elif port in (443, 8443):
            try:
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                s = ctx.wrap_socket(s, server_hostname=host)
                # PERBAIKAN: Tambahkan Host header untuk HTTPS
                s.send(b"HEAD / HTTP/1.0" + CRLF + b"Host: " + host.encode() + CRLF + CRLF)
            except Exception:
                pass
        elif port == 6379:
            s.send(b"PING" + CRLF)
        elif port == 11211:
            s.send(b"stats" + CRLF)
        elif port == 9200:
            s.send(b"GET / HTTP/1.0" + CRLF + b"Host: " + host.encode() + CRLF + CRLF)
        data = s.recv(2048)
        s.close()
        return data
    except Exception:
        return None


def analyze_http(url, timeout=5):
    try:
        p = urlparse(url)
        host = p.hostname
        if not host:
            return None
        port = p.port or (443 if p.scheme == "https" else 80)
        if p.scheme == "https":
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            conn = http.client.HTTPSConnection(host, port, timeout=timeout, context=ctx)
        else:
            conn = http.client.HTTPConnection(host, port, timeout=timeout)
        conn.request("GET", p.path or "/", headers={"User-Agent": "Mozilla/5.0"})
        resp = conn.getresponse()
        hdrs = dict(resp.getheaders())
        resp.read(1024)
        conn.close()

        cookies = hdrs.get("Set-Cookie", "").lower()
        techs = []
        session_type = None
        for tech, patterns in COOKIE_FINGERPRINTS.items():
            for pat in patterns:
                if pat in cookies.encode():
                    techs.append(tech)
                    if session_type is None:
                        session_type = tech
                    break

        result = {
            "status": resp.status,
            "server": hdrs.get("Server", ""),
            "powered_by": hdrs.get("X-Powered-By", ""),
            "generator": hdrs.get("X-Generator", ""),
            "csp": "Content-Security-Policy" in hdrs,
            "hsts": "Strict-Transport-Security" in hdrs,
            "cookies": hdrs.get("Set-Cookie", "")[:200],
            "technologies": techs,
            "session_type": session_type,
        }
        return result
    except Exception:
        return None


def analyze_tls(host, port=443, timeout=5):
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect((host, port))
        ss = ctx.wrap_socket(s, server_hostname=host)
        version = ss.version()
        cipher = ss.cipher()
        ss.close()
        return {"version": version, "cipher": cipher[0] if cipher else None}
    except Exception:
        return None


def guess_os(host, timeout=3):
    try:
        r = subprocess.run(["ping", "-c", "1", "-W", "2", host],
                           capture_output=True, text=True, timeout=5)
        m = re.search(r"ttl=(\d+)", r.stdout, re.I)
        if m:
            ttl = int(m.group(1))
            if ttl <= 64:
                return "linux"
            if ttl <= 128:
                return "windows"
            return "network-device"
    except Exception:
        pass
    return "unknown"


def recon(url, ports=None, timeout=2, max_workers=50):
    if ports is None:
        ports = PORTS_COMMON
    host = url
    if url.startswith(("http://", "https://")):
        p = urlparse(url)
        host = p.hostname or url
        if p.port and p.port not in ports:
            ports = list(ports) + [p.port]

    result = {
        "host": host,
        "open_ports": [],
        "services": {},
        "banners": {},
        "databases": [],
        "os_guess": "unknown",
        "http": None,
        "tls": None,
    }

    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = {ex.submit(scan_port, host, p, timeout): p for p in ports}
        for fut in as_completed(futures):
            try:
                if fut.result():
                    result["open_ports"].append(futures[fut])
            except Exception:
                pass
    result["open_ports"].sort()

    for port in result["open_ports"]:
        svc = SERVICE_MAP.get(port, "unknown")
        result["services"][port] = svc
        banner = grab_banner(host, port)
        if banner:
            result["banners"][port] = banner[:300].decode("utf-8", "ignore").strip()
        if port in DB_PORTS:
            result["databases"].append(DB_PORTS[port])

    if url.startswith(("http://", "https://")):
        result["http"] = analyze_http(url, timeout=min(timeout * 2, 5))

    if 443 in result["open_ports"]:
        result["tls"] = analyze_tls(host, 443, timeout)

    result["os_guess"] = guess_os(host)
    return result
