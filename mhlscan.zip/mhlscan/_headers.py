# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_headers.py - HTTP security headers audit."""

SECURITY_HEADERS = [
    ("Strict-Transport-Security", "HSTS", "medium"),
    ("Content-Security-Policy", "CSP", "medium"),
    ("X-Frame-Options", "Clickjacking protection", "low"),
    ("X-Content-Type-Options", "MIME sniffing protection", "low"),
    ("Referrer-Policy", "Referrer policy", "low"),
    ("Permissions-Policy", "Feature policy", "low"),
]


def check_headers(headers):
    """Return dict {present: [...], missing: [...], findings: [...]}."""
    hmap = {}
    for k, v in (headers or {}).items():
        hmap[k.lower()] = v

    present = []
    missing = []
    findings = []
    for hdr, label, sev in SECURITY_HEADERS:
        if hdr.lower() in hmap:
            present.append({"header": hdr, "value": str(hmap[hdr.lower()])[:200]})
        else:
            missing.append({"header": hdr, "severity": sev, "label": label})
            findings.append({
                "id": "hdr-missing-" + hdr.lower().replace("-", "_"),
                "name": f"Missing {hdr}",
                "severity": sev,
                "evidence": f"Header '{hdr}' not present ({label})",
                "source": "headers",
                "type": "http-header",
            })

    return {"present": present, "missing": missing, "findings": findings}
