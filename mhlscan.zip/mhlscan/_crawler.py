# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_crawler.py - Sync BFS crawler (extract endpoints, forms, params)."""

import re
from collections import deque
from urllib.parse import urljoin, urlparse, parse_qs
from html.parser import HTMLParser


class LinkExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
        self.forms = []
        self.inputs = []

    def handle_starttag(self, tag, attrs):
        d = dict(attrs)
        if tag == "a" and d.get("href"):
            self.links.append(d["href"])
        elif tag == "form":
            self.forms.append({
                "action": d.get("action", ""),
                "method": (d.get("method") or "GET").upper(),
                "inputs": [],
            })
        elif tag in ("input", "textarea", "select"):
            if self.forms:
                self.forms[-1]["inputs"].append({
                    "name": d.get("name", ""),
                    "type": d.get("type", "text"),
                    "value": d.get("value", ""),
                })
            self.inputs.append({
                "name": d.get("name", ""),
                "type": d.get("type", "text"),
            })
        elif tag == "script" and d.get("src"):
            self.links.append(d["src"])
        elif tag == "link" and d.get("href"):
            self.links.append(d["href"])


def _is_same_domain(url, base):
    try:
        return urlparse(url).netloc == urlparse(base).netloc
    except Exception:
        return False


def _normalize(url, base):
    """Resolve relative → absolute, strip fragment."""
    if not url:
        return None
    if url.startswith(("#", "javascript:", "mailto:", "tel:", "data:")):
        return None
    try:
        full = urljoin(base, url)
        parsed = urlparse(full)
        if parsed.scheme not in ("http", "https"):
            return None
        clean = parsed._replace(fragment="").geturl()
        return clean
    except Exception:
        return None


def extract_get_params(url):
    """Return list of (base_url_without_qs, param_name)."""
    try:
        parsed = urlparse(url)
        if not parsed.query:
            return []
        base = parsed._replace(query="", fragment="").geturl()
        params = parse_qs(parsed.query, keep_blank_values=True)
        return [(base, p) for p in params.keys()]
    except Exception:
        return []


def crawl(start_url, pool, max_pages=50, max_depth=3, timeout=5,
          verbose=False):
    """
    BFS crawl target. Returns dict:
      {
        "pages": [urls visited],
        "endpoints": [{"url": ..., "params": [...], "source": ...}],
        "forms": [{"action": ..., "method": ..., "inputs": [...]}],
        "get_params": [(base, name), ...]
      }
    """
    result = {
        "pages": [],
        "endpoints": [],
        "forms": [],
        "get_params": [],
    }

    parsed = urlparse(start_url)
    if not parsed.scheme:
        start_url = "http://" + start_url
        parsed = urlparse(start_url)

    seen = {start_url}
    queue = deque([(start_url, 0)])
    seen_params = set()

    while queue and len(result["pages"]) < max_pages:
        url, depth = queue.popleft()
        if depth > max_depth:
            continue

        if verbose:
            print("  [crawl] " + url)

        try:
            r = pool.request('GET', url, timeout=timeout, redirect=False)
            status = getattr(r, "status", 0)
            body = (r.data or b"")[:200000].decode("utf-8", "ignore")
        except Exception as e:
            if verbose:
                print("  [crawl] ERROR: " + type(e).__name__)
            continue

        if status not in (200, 301, 302, 401, 403):
            continue

        result["pages"].append(url)

        # Extract params dari URL ini
        for base, pname in extract_get_params(url):
            key = (base, pname)
            if key not in seen_params:
                seen_params.add(key)
                result["get_params"].append({"url": base, "param": pname})

        # Parse HTML
        parser = LinkExtractor()
        try:
            parser.feed(body)
        except Exception:
            continue

        # Links → crawl queue
        for link in parser.links:
            abs_url = _normalize(link, url)
            if not abs_url or not _is_same_domain(abs_url, start_url):
                continue
            if abs_url in seen:
                continue
            seen.add(abs_url)

            # Extract params dari link
            for base, pname in extract_get_params(abs_url):
                key = (base, pname)
                if key not in seen_params:
                    seen_params.add(key)
                    result["get_params"].append({
                        "url": base, "param": pname, "source": "link",
                    })

            # Masukkan ke queue (hanya kalau bukan asset)
            parsed_url = urlparse(abs_url)
            path = parsed_url.path.lower()
            if any(path.endswith(ext) for ext in
                   (".png", ".jpg", ".jpeg", ".gif", ".svg", ".css", ".js",
                    ".pdf", ".zip", ".woff", ".woff2", ".ttf", ".ico",
                    ".mp4", ".mp3", ".webp")):
                continue

            queue.append((abs_url, depth + 1))

        # Forms
        for form in parser.forms:
            action = _normalize(form["action"] or url, url)
            if not action or not _is_same_domain(action, start_url):
                continue
            result["forms"].append({
                "action": action,
                "method": form["method"],
                "inputs": form["inputs"],
            })

    result["endpoints"] = [{"url": p} for p in result["pages"]]
    return result


def to_scan_targets(crawl_result, max_targets=100):
    """Convert crawl result → list URL untuk scan."""
    targets = set()
    for p in crawl_result.get("pages", [])[:max_targets]:
        targets.add(p)
    for param in crawl_result.get("get_params", [])[:max_targets]:
        targets.add(param["url"])
    for form in crawl_result.get("forms", [])[:max_targets]:
        targets.add(form["action"])
    return list(targets)[:max_targets]
