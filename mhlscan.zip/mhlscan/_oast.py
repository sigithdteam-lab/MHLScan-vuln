# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_oast.py - Interactsh client untuk out-of-band detection (RCE/blind/SSRF)."""

import base64
import json
import secrets
import string
import threading
import time
import urllib.request
import urllib.error

try:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import padding, rsa
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    from cryptography.hazmat.backends import default_backend
    HAS_CRYPTO = True
except ImportError:
    HAS_CRYPTO = False


DEFAULT_SERVER = "https://oast.live"


class InteractshClient:
    def __init__(self, server=DEFAULT_SERVER, timeout=15):
        if not HAS_CRYPTO:
            raise RuntimeError("pip install cryptography")
        self.server = server.rstrip("/")
        self.timeout = timeout
        self.correlation_id = None
        self.secret_key = None
        self.public_key = None
        self._private_key = None
        self._registered = False
        self._test_nonces = {}

    def _generate_keys(self):
        self._private_key = rsa.generate_private_key(
            public_exponent=65537, key_size=2048,
            backend=default_backend(),
        )
        pub = self._private_key.public_key()
        pem = pub.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        self.public_key = base64.b64encode(pem).decode()

    def register(self):
        if not HAS_CRYPTO:
            return False
        try:
            self._generate_keys()
            self.correlation_id = "".join(
                secrets.choice(string.ascii_lowercase + string.digits)
                for _ in range(20))
            self.secret_key = "".join(
                secrets.choice(string.ascii_lowercase + string.digits)
                for _ in range(32))

            payload = json.dumps({
                "public-key": self.public_key,
                "secret-key": self.secret_key,
                "correlation-id": self.correlation_id,
            }).encode()

            req = urllib.request.Request(
                self.server + "/register",
                data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                r.read()
                self._registered = True
                return True
        except Exception as e:
            print("[oast] Register failed: " + str(e))
            return False

    def generate_url(self, test_id=None):
        """Generate unique OAST subdomain. Returns dict."""
        if not self._registered:
            return None
        nonce = "".join(secrets.choice(string.ascii_lowercase + string.digits)
                        for _ in range(13))
        domain = self.server.replace("https://", "").replace("http://", "")
        host = self.correlation_id + nonce + "." + domain
        if test_id:
            self._test_nonces[nonce] = test_id
        return {
            "host": host,
            "url": "http://" + host,
            "https_url": "https://" + host,
            "test_id": test_id,
            "nonce": nonce,
        }

    def poll(self, timeout=15, interval=5):
        """Poll untuk callbacks. Return list of interactions."""
        if not self._registered:
            return []
        seen = set()
        results = []
        start = time.time()
        while (time.time() - start) < timeout:
            try:
                url = (self.server + "/poll?id=" + self.correlation_id
                       + "&secret=" + self.secret_key)
                req = urllib.request.Request(url, method="GET")
                with urllib.request.urlopen(req, timeout=self.timeout) as r:
                    data = json.loads(r.read())
                    for inter in data.get("data", []) or []:
                        uid = inter.get("unique-id", "")
                        if not uid or uid in seen:
                            continue
                        seen.add(uid)
                        try:
                            decrypted = self._decrypt(
                                inter.get("aes-key", ""),
                                inter.get("data", ""),
                            )
                        except Exception:
                            decrypted = "(decrypt failed)"
                        # Match ke test_id via nonce di subdomain
                        subdomain = self._extract_subdomain(decrypted)
                        test_id = None
                        if subdomain:
                            for nonce, tid in self._test_nonces.items():
                                if nonce in subdomain:
                                    test_id = tid
                                    break
                        results.append({
                            "protocol": inter.get("protocol", "?"),
                            "remote_address": inter.get("remote-address", "?"),
                            "timestamp": inter.get("timestamp", ""),
                            "data": decrypted,
                            "test_id": test_id,
                            "nonce": subdomain,
                        })
            except Exception:
                pass
            if results:
                return results
            time.sleep(interval)
        return results

    def _extract_subdomain(self, text):
        import re
        m = re.search(r'([a-z0-9]{20}[a-z0-9]{13})\.', text or "")
        return m.group(1) if m else None

    def _decrypt(self, b64_key, b64_data):
        if not b64_key or not b64_data:
            return ""
        encrypted_aes = base64.b64decode(b64_key)
        aes_key = self._private_key.decrypt(
            encrypted_aes, padding.PKCS1v15())
        iv = aes_key[:16]
        cipher = Cipher(algorithms.AES(aes_key), modes.CFB(iv),
                        backend=default_backend())
        decryptor = cipher.decryptor()
        data = base64.b64decode(b64_data)
        plain = decryptor.update(data) + decryptor.finalize()
        return plain.decode("utf-8", "ignore")

    def close(self):
        try:
            url = (self.server + "/deregister?id=" + (self.correlation_id or "")
                   + "&secret=" + (self.secret_key or ""))
            req = urllib.request.Request(url, method="GET")
            urllib.request.urlopen(req, timeout=5).read()
        except Exception:
            pass


def is_available():
    return HAS_CRYPTO


_instance = None


def get_client(server=DEFAULT_SERVER):
    global _instance
    if _instance is None:
        _instance = InteractshClient(server=server)
        _instance.register()
    return _instance
