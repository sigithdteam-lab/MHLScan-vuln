#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_menu.py - Interactive menu untuk mhlscan.py (v9)."""

import os
import sys
import json
import shutil
import subprocess
from pathlib import Path
from datetime import datetime, timedelta

CONFIG_FILE = Path.home() / ".mhlscan" / "menu_config.json"
SCRIPT_DIR = Path(__file__).parent
MHLSCAN = SCRIPT_DIR / "mhlscan.py"
REPORTS_DIR = SCRIPT_DIR / "reports"

RED    = '\033[91m'
GREEN  = '\033[32m'
YELLOW = '\033[1;33m'
BLUE   = '\033[94m'
CYAN   = '\033[96m'
BOLD   = '\033[1m'
DIM    = '\033[2m'
ENDC   = '\033[0m'

DEFAULT_CONFIG = {
    "severity": "high",
    "workers": 10,
    "timeout": 5,
    "stealth": True,
    "plugins": False,
    "deep_services": False,
    "rev_shell": False,
    "port_expand": True,
    "aggressive": False,
    "sqlmap": False,
    "amass": True,
    "coverage": True,
    "xss": False,
    "param_discovery": False,
    "jwt_analysis": False,
    "smuggle": False,
    "auto_exploit": False,
    "post_read": False,
    "post_write": False,
}


def load_config():
    try:
        if CONFIG_FILE.exists():
            cfg = json.loads(CONFIG_FILE.read_text())
            return {**DEFAULT_CONFIG, **cfg}
    except Exception:
        pass
    return dict(DEFAULT_CONFIG)


def save_config(cfg):
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2))


def clr():
    os.system("cls" if os.name == "nt" else "clear")


def build_cmd(mode_flag, target, cfg, extra_args=None):
    cmd = [sys.executable, str(MHLSCAN), mode_flag, target]
    cmd.extend(["--severity", cfg["severity"]])
    cmd.extend(["--workers", str(cfg["workers"])])
    cmd.extend(["--timeout", str(cfg["timeout"])])
    if not cfg["stealth"]:
        cmd.append("--no-stealth")
    if cfg["plugins"]:
        cmd.append("--plugins")
    if cfg["deep_services"]:
        cmd.append("--deep-services")
    if cfg["rev_shell"]:
        cmd.append("--rev-shell")
    if not cfg["port_expand"]:
        cmd.append("--no-port-expand")
    if cfg.get("aggressive"):
        cmd.append("--aggressive")
    if cfg.get("sqlmap"):
        cmd.append("--sqlmap")
    if not cfg.get("amass"):
        cmd.append("--no-amass")
    if cfg.get("coverage"):
        cmd.append("--coverage")
    if cfg.get("xss"):
        cmd.append("--xss")
    if cfg.get("param_discovery"):
        cmd.append("--param-discovery")
    if cfg.get("jwt_analysis"):
        cmd.append("--jwt-analysis")
    if cfg.get("smuggle"):
        cmd.append("--smuggle")
    if cfg.get("auto_exploit"):
        cmd.append("--auto-exploit")
    if cfg.get("post_read"):
        cmd.append("--post-read")
    if cfg.get("post_write"):
        cmd.append("--post-write")
    if extra_args:
        cmd.extend(extra_args)
    return cmd


def run_command(cmd):
    print(f"\n{DIM}Command: {' '.join(cmd)}{ENDC}")
    print(f"{CYAN}{'=' * 70}{ENDC}\n")
    try:
        subprocess.run(cmd, cwd=SCRIPT_DIR)
    except KeyboardInterrupt:
        print(f"\n{YELLOW}[!] Dihentikan{ENDC}")
    print(f"\n{CYAN}{'=' * 70}{ENDC}")


def pause():
    input(f"\n{DIM}[ENTER] untuk kembali ke menu...{ENDC}")


def header(title):
    clr()
    print(f"\n{BOLD}{CYAN}{title}{ENDC}")
    print(f"{DIM}{'=' * 70}{ENDC}\n")


# ============================================================
# MENU SCAN MODES
# ============================================================
def menu_single(cfg):
    header("[1] SINGLE TARGET")
    print("Format: URL, domain, IP, atau IP:port")
    print("Contoh: https://example.com  |  103.20.196.5  |  103.20.196.5:8080\n")
    target = input(f"{BOLD}Target (kosong=back): {ENDC}").strip()
    if not target:
        return
    run_command(build_cmd("--sodok", target, cfg))
    pause()


def menu_domain(cfg):
    header("[2] DOMAIN + SUBDOMAIN")
    domain = input(f"{BOLD}Domain target (kosong=back): {ENDC}").strip()
    if not domain:
        return
    limit = input("Subdomain limit [50]: ").strip() or "50"
    aggr = input("Aggressive mode [N]: ").strip().lower() == "y"
    extra = ["--subdomain-limit", limit]
    if aggr:
        extra.append("--subdomain-aggressive")
    run_command(build_cmd("--sodok", domain, cfg, extra))
    pause()


def menu_cidr(cfg):
    header("[3] IP / CIDR")
    print("Contoh: 192.168.1.5  atau  192.168.1.0/24  atau  192.168.1.1-100\n")
    target = input(f"{BOLD}Target IP/CIDR (kosong=back): {ENDC}").strip()
    if not target:
        return
    extra = []
    if "/" in target:
        mx = input("CIDR max hosts [256]: ").strip() or "256"
        th = input("CIDR threads [100]: ").strip() or "100"
        live = input("Live discovery [Y]: ").strip().lower() != "n"
        disc = input("Discovery method (arp/icmp/tcp/udp/all) [all]: ").strip() or "all"
        nb = input("Tampilkan neighbor board? [y/N]: ").strip().lower() == "y"
        extra = ["--cidr-max", mx, "--cidr-threads", th, "--discovery", disc]
        if not live:
            extra.append("--cidr-all")
        if nb:
            extra.append("--neighbor-board")
    run_command(build_cmd("--sodok", target, cfg, extra))
    pause()


def menu_country(cfg):
    header("[4] BY COUNTRY (GeoIP)")
    print(f"{YELLOW}PERINGATAN LEGAL:{ENDC}")
    print("Scan IP publik tanpa izin = ILLEGAL")
    print("Hanya scan IP milik sendiri atau authorized scope\n")
    cc = input(f"{BOLD}Country code (ID/US/SG/MY/JP/AU) [kosong=back]: {ENDC}").strip()
    if not cc:
        return
    limit = input("IP limit [50]: ").strip() or "50"
    confirm = input(f"{YELLOW}Authorized? [y/N]: {ENDC}").strip().lower()
    if confirm != "y":
        print(f"\n{YELLOW}[!] Dibatalkan{ENDC}")
        pause()
        return
    run_command(build_cmd("--ip-country", cc, cfg, ["--geo-limit", limit]))
    pause()


def menu_file(cfg):
    header("[5] BATCH FROM FILE")
    path = input(f"{BOLD}File path (kosong=back): {ENDC}").strip()
    if not path:
        return
    if not Path(path).exists():
        print(f"\n{RED}[!] File tidak ada: {path}{ENDC}")
        pause()
        return
    consume = input("Consume file setelah scan? [y/N]: ").strip().lower() == "y"
    extra = ["--consume"] if consume else []
    run_command(build_cmd("--sodok-file", path, cfg, extra))
    pause()


# ============================================================
# MENU MAINTENANCE
# ============================================================
def menu_update(cfg):
    while True:
        header("[6] UPDATE / RESET CVE DATABASE")
        print("  [1]  Update default (JBoss + WSO2)")
        print("  [2]  Update ALL stacks (WP, Laravel, Drupal, Joomla, ...)")
        print("  [3]  Update specific stack")
        print("  [4]  Update CVE DB (KEV/EPSS/EDB/GitHub/vendors)")
        print("  [5]  Rebuild dynamic STACK_KEYWORDS")
        print()
        print(f"  {YELLOW}--- RESET / DELETE ---{ENDC}")
        print("  [6]  Reset CVE DB (hapus KEV/EPSS/EDB/GitHub/vendor)")
        print("  [7]  Reset Nuclei cache (index + templates)")
        print("  [8]  Reset ALL cache (cve_db + nuclei + intel + nvd)")
        print("  [9]  Delete specific file")
        print("  [10] Reset tactical memory (SQLite)")
        print("  [11] Reset menu config (semua fitur OFF)")
        print()
        print("  [12] Lihat ukuran cache")
        print("  [0]  Kembali ke main menu\n")
        c = input(f"{BOLD}Pilih [0-12]: {ENDC}").strip()
        if c == "0":
            return
        if c == "1":
            run_command([sys.executable, str(MHLSCAN), "--update"])
            pause()
        elif c == "2":
            run_command([sys.executable, str(MHLSCAN), "--update-all"])
            pause()
        elif c == "3":
            stack = input("Stack (wordpress/joomla/drupal/tomcat/wso2/...): ").strip()
            if stack:
                run_command([sys.executable, str(MHLSCAN), "--update-stack", stack])
                pause()
        elif c == "4":
            run_command([sys.executable, str(MHLSCAN), "--update-cve-db"])
            pause()
        elif c == "5":
            try:
                import _stack_dynamic
                _stack_dynamic.build_auto_stacks()
            except Exception as e:
                print(f"{RED}[!] {e}{ENDC}")
            pause()
        elif c == "6":
            _reset_cve_db()
            pause()
        elif c == "7":
            _reset_nuclei()
            pause()
        elif c == "8":
            _reset_all_cache()
            pause()
        elif c == "9":
            _delete_specific_file()
            pause()
        elif c == "10":
            _reset_memory()
            pause()
        elif c == "11":
            _reset_config()
            pause()
        elif c == "12":
            _show_cache_size()
            pause()


def _cache_root():
    """Return ~/.mhlscan path."""
    from pathlib import Path as _P
    return _P.home() / ".mhlscan"


def _format_size(bytes_val):
    for unit in ("B", "KB", "MB", "GB"):
        if bytes_val < 1024:
            return f"{bytes_val:.1f} {unit}"
        bytes_val /= 1024
    return f"{bytes_val:.1f} TB"


def _dir_size(path):
    """Hitung total size folder."""
    from pathlib import Path as _P
    if not path.exists():
        return 0
    total = 0
    for f in path.rglob("*"):
        if f.is_file():
            try:
                total += f.stat().st_size
            except Exception:
                pass
    return total


def _show_cache_size():
    root = _cache_root()
    print()
    print(f"  {BOLD}Cache size di {root}:{ENDC}")
    if not root.exists():
        print(f"    {DIM}(belum ada cache){ENDC}")
        return
    for sub in sorted(root.iterdir()):
        if sub.is_dir():
            size = _dir_size(sub)
            files = len(list(sub.rglob("*")))
            print(f"    {sub.name:<20} {_format_size(size):>10}  ({files} files)")
        elif sub.is_file():
            size = sub.stat().st_size
            print(f"    {sub.name:<20} {_format_size(size):>10}")
    total = _dir_size(root)
    print(f"    {'TOTAL':<20} {_format_size(total):>10}")


def _reset_cve_db():
    """Hapus ~/.mhlscan/cve_db/."""
    import shutil
    root = _cache_root() / "cve_db"
    if not root.exists():
        print(f"  {YELLOW}[!] cve_db/ tidak ada{ENDC}")
        return
    size = _dir_size(root)
    files = list(root.glob("*.json"))
    print(f"\n  {BOLD}Reset CVE DB{ENDC}")
    print(f"  Folder: {root}")
    print(f"  Size: {_format_size(size)}")
    print(f"  Files: {len(files)}")
    for f in files:
        print(f"    - {f.name} ({_format_size(f.stat().st_size)})")
    confirm = input(f"\n  {YELLOW}Hapus semua? [y/N]: {ENDC}").strip().lower()
    if confirm != "y":
        print(f"  {DIM}Dibatalkan{ENDC}")
        return
    # Backup
    backup_dir = root.parent / f"cve_db.bak_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    try:
        shutil.move(str(root), str(backup_dir))
        print(f"  {GREEN}[+] Dipindahkan ke: {backup_dir}{ENDC}")
        print(f"  {GREEN}[+] Jalankan [4] Update CVE DB untuk download ulang{ENDC}")
    except Exception as e:
        print(f"  {RED}[!] {e}{ENDC}")


def _reset_nuclei():
    """Hapus ~/.mhlscan/nuclei/."""
    import shutil
    root = _cache_root() / "nuclei"
    if not root.exists():
        print(f"  {YELLOW}[!] nuclei/ tidak ada{ENDC}")
        return
    size = _dir_size(root)
    count = len(list(root.rglob("*")))
    print(f"\n  {BOLD}Reset Nuclei Cache{ENDC}")
    print(f"  Folder: {root}")
    print(f"  Size: {_format_size(size)}")
    print(f"  Items: {count}")
    # Subfolder list
    for sub in sorted(root.iterdir()):
        if sub.is_dir():
            sub_count = len(list(sub.rglob("*")))
            print(f"    - {sub.name}/ ({sub_count} files)")
        else:
            print(f"    - {sub.name}")
    confirm = input(f"\n  {YELLOW}Hapus semua? [y/N]: {ENDC}").strip().lower()
    if confirm != "y":
        print(f"  {DIM}Dibatalkan{ENDC}")
        return
    backup_dir = root.parent / f"nuclei.bak_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    try:
        shutil.move(str(root), str(backup_dir))
        print(f"  {GREEN}[+] Dipindahkan ke: {backup_dir}{ENDC}")
        print(f"  {GREEN}[+] Jalankan [2] Update ALL untuk download ulang (~5-10 menit){ENDC}")
    except Exception as e:
        print(f"  {RED}[!] {e}{ENDC}")


def _reset_all_cache():
    """Hapus semua cache."""
    import shutil
    root = _cache_root()
    if not root.exists():
        print(f"  {YELLOW}[!] Cache tidak ada{ENDC}")
        return
    size = _dir_size(root)
    print(f"\n  {BOLD}{RED}RESET ALL CACHE{ENDC}")
    print(f"  Folder: {root}")
    print(f"  Total size: {_format_size(size)}")
    print(f"  Yang akan dihapus:")
    for sub in sorted(root.iterdir()):
        s = _dir_size(sub) if sub.is_dir() else sub.stat().st_size
        print(f"    - {sub.name} ({_format_size(s)})")
    print()
    print(f"  {RED}⚠ Semua cache akan hilang. Download ulang ~15-30 menit.{ENDC}")
    confirm = input(f"  {YELLOW}Ketik 'RESET ALL' untuk konfirmasi: {ENDC}").strip()
    if confirm != "RESET ALL":
        print(f"  {DIM}Dibatalkan{ENDC}")
        return
    backup_dir = root.parent / f"mhlscan_cache.bak_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    try:
        shutil.move(str(root), str(backup_dir))
        root.mkdir(parents=True, exist_ok=True)
        print(f"  {GREEN}[+] Dipindahkan ke: {backup_dir}{ENDC}")
        print(f"  {GREEN}[+] Cache di-reset. Jalankan [2] Update ALL{ENDC}")
    except Exception as e:
        print(f"  {RED}[!] {e}{ENDC}")


def _delete_specific_file():
    """Delete file individual dalam cache."""
    root = _cache_root()
    if not root.exists():
        print(f"  {YELLOW}[!] Cache tidak ada{ENDC}")
        return
    # Kumpulkan file JSON
    files = list(root.rglob("*.json"))
    if not files:
        print(f"  {YELLOW}[!] Tidak ada file JSON{ENDC}")
        return
    print(f"\n  {BOLD}File dalam cache ({len(files)}):{ENDC}")
    for i, f in enumerate(sorted(files), 1):
        try:
            rel = f.relative_to(root)
            size = _format_size(f.stat().st_size)
            print(f"  [{i:3}] {str(rel):<60} {size}")
        except Exception:
            print(f"  [{i:3}] {f.name}")
    try:
        n = input(f"\n  Nomor file yang dihapus (kosong=batal): ").strip()
        if not n:
            return
        idx = int(n) - 1
        if 0 <= idx < len(files):
            target = sorted(files)[idx]
            confirm = input(f"  {YELLOW}Hapus {target.name}? [y/N]: {ENDC}").strip().lower()
            if confirm == "y":
                target.unlink()
                print(f"  {GREEN}[+] Dihapus: {target}{ENDC}")
    except (ValueError, EOFError, KeyboardInterrupt):
        pass


def _reset_memory():
    """Reset tactical memory SQLite."""
    root = _cache_root()
    mem = root / "memory.db"
    if not mem.exists():
        print(f"  {YELLOW}[!] memory.db tidak ada{ENDC}")
        return
    size = _format_size(mem.stat().st_size)
    print(f"\n  {BOLD}Reset Tactical Memory{ENDC}")
    print(f"  File: {mem} ({size})")
    print(f"  Berisi: success/failure CVE verification cache")
    confirm = input(f"  {YELLOW}Hapus? [y/N]: {ENDC}").strip().lower()
    if confirm == "y":
        try:
            mem.unlink()
            print(f"  {GREEN}[+] Dihapus{ENDC}")
        except Exception as e:
            print(f"  {RED}[!] {e}{ENDC}")


def _reset_config():
    """Reset menu config ke default."""
    cfg_file = Path.home() / ".mhlscan" / "menu_config.json"
    if not cfg_file.exists():
        print(f"  {YELLOW}[!] menu_config.json tidak ada{ENDC}")
        return
    print(f"\n  {BOLD}Reset Menu Config{ENDC}")
    print(f"  File: {cfg_file}")
    print(f"  Akan reset semua fitur ke OFF (default)")
    confirm = input(f"  {YELLOW}Reset? [y/N]: {ENDC}").strip().lower()
    if confirm == "y":
        try:
            backup = cfg_file.with_suffix(f".json.bak_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
            shutil.copy2(cfg_file, backup)
            cfg_file.unlink()
            print(f"  {GREEN}[+] Config di-reset (backup: {backup.name}){ENDC}")
            print(f"  {GREEN}[+] Fitur default semua OFF{ENDC}")
        except Exception as e:
            print(f"  {RED}[!] {e}{ENDC}")



def menu_settings(cfg):
    while True:
        header("[7] SETTINGS")
        print(f"  [1]  Severity minimum   : {BOLD}{cfg['severity']}{ENDC}")
        print(f"  [2]  Workers            : {BOLD}{cfg['workers']}{ENDC}")
        print(f"  [3]  Timeout (detik)    : {BOLD}{cfg['timeout']}{ENDC}")
        print(f"  [4]  Stealth mode       : {BOLD}{'ON' if cfg['stealth'] else 'OFF'}{ENDC}")
        print(f"  [5]  Plugins detection  : {BOLD}{'ON' if cfg['plugins'] else 'OFF'}{ENDC}")
        print(f"  [6]  Deep services      : {BOLD}{'ON' if cfg['deep_services'] else 'OFF'}{ENDC}")
        print(f"  [7]  Reverse shell      : {BOLD}{'ON' if cfg['rev_shell'] else 'OFF'}{ENDC}")
        print(f"  [8]  Port expansion     : {BOLD}{'ON' if cfg['port_expand'] else 'OFF'}{ENDC}")
        print(f"  [9]  Aggressive modules : {BOLD}{'ON' if cfg.get('aggressive') else 'OFF'}{ENDC}")
        print(f"  [10] SQLMap SQLi        : {BOLD}{'ON' if cfg.get('sqlmap') else 'OFF'}{ENDC}")
        print(f"  [11] Amass subdomain    : {BOLD}{'ON' if cfg.get('amass') else 'OFF'}{ENDC}")
        print(f"  [12] WSTG coverage      : {BOLD}{'ON' if cfg.get('coverage') else 'OFF'}{ENDC}")
        print(f"  [13] XSS scanner        : {BOLD}{'ON' if cfg.get('xss') else 'OFF'}{ENDC}")
        print(f"  [14] Param discovery    : {BOLD}{'ON' if cfg.get('param_discovery') else 'OFF'}{ENDC}")
        print(f"  [15] JWT analysis       : {BOLD}{'ON' if cfg.get('jwt_analysis') else 'OFF'}{ENDC}")
        print(f"  [16] HTTP smuggling     : {BOLD}{'ON' if cfg.get('smuggle') else 'OFF'}{ENDC}")
        print(f"  [17] Auto-exploit       : {BOLD}{'ON' if cfg.get('auto_exploit') else 'OFF'}{ENDC}")
        print(f"  [18] Post-exploit read  : {BOLD}{'ON' if cfg.get('post_read') else 'OFF'}{ENDC}")
        print(f"  [19] Post-exploit write : {BOLD}{'ON' if cfg.get('post_write') else 'OFF'}{ENDC}")
        print(f"  [20] Save & back\n")
        c = input(f"{BOLD}Pilih [1-20]: {ENDC}").strip()
        if c == "1":
            v = input("Severity (info/low/medium/high/critical): ").strip()
            if v in ("info", "low", "medium", "high", "critical"):
                cfg["severity"] = v
        elif c == "2":
            v = input("Workers [1-50]: ").strip()
            if v.isdigit() and 1 <= int(v) <= 50:
                cfg["workers"] = int(v)
        elif c == "3":
            v = input("Timeout detik [1-60]: ").strip()
            if v.isdigit() and 1 <= int(v) <= 60:
                cfg["timeout"] = int(v)
        elif c == "4":
            cfg["stealth"] = not cfg["stealth"]
        elif c == "5":
            cfg["plugins"] = not cfg["plugins"]
        elif c == "6":
            cfg["deep_services"] = not cfg["deep_services"]
        elif c == "7":
            cfg["rev_shell"] = not cfg["rev_shell"]
        elif c == "8":
            cfg["port_expand"] = not cfg["port_expand"]
        elif c == "9":
            cfg["aggressive"] = not cfg.get("aggressive", False)
        elif c == "10":
            cfg["sqlmap"] = not cfg.get("sqlmap", True)
        elif c == "11":
            cfg["amass"] = not cfg.get("amass", True)
        elif c == "12":
            cfg["coverage"] = not cfg.get("coverage", True)
        elif c == "13":
            cfg["xss"] = not cfg.get("xss", False)
        elif c == "14":
            cfg["param_discovery"] = not cfg.get("param_discovery", False)
        elif c == "15":
            cfg["jwt_analysis"] = not cfg.get("jwt_analysis", False)
        elif c == "16":
            cfg["smuggle"] = not cfg.get("smuggle", False)
        elif c == "17":
            cfg["auto_exploit"] = not cfg.get("auto_exploit", False)
            if cfg["auto_exploit"]:
                print(f"{YELLOW}  [!] Auto-exploit butuh --i-have-permission saat scan{ENDC}")
        elif c == "18":
            cfg["post_read"] = not cfg.get("post_read", False)
        elif c == "19":
            cfg["post_write"] = not cfg.get("post_write", False)
            if cfg["post_write"]:
                print(f"{RED}  [!] Post-write butuh --i-have-permission + konfirmasi{ENDC}")
        elif c == "20":
            save_config(cfg)
            print(f"\n{GREEN}[+] Settings saved ke {CONFIG_FILE}{ENDC}")
            pause()
            return


# ============================================================
# MENU UTILITY
# ============================================================
def menu_check(cfg):
    header("[8] CHECK DEPENDENCIES")
    mods = [
        "urllib3", "requests", "bs4", "yaml",
        "_memory", "_playbook", "_extractor", "_sslcheck", "_headers",
        "_wstg", "_cve_local", "_chain", "_sqlscan", "_discovery",
        "_mitm", "_dnspoison", "_paramdiscovery", "_jwt", "_httpsmuggle",
        "_payload_synth", "_exploits_db", "_payload_gen", "_post_exploit",
        "_xss", "_crawler2", "_aspnet_waf", "_stack_dynamic", "_cve_scan_all",
    ]
    for mod in mods:
        try:
            __import__(mod)
            print(f"  {GREEN}OK{ENDC}   {mod}")
        except ImportError as e:
            print(f"  {RED}FAIL{ENDC} {mod}  {DIM}({e}){ENDC}")

    print()
    for binary in ("nuclei", "sqlmap", "searchsploit", "msfvenom",
                   "subfinder", "amass", "wafw00f", "testssl.sh"):
        path = shutil.which(binary)
        if path:
            print(f"  {GREEN}OK{ENDC}   {binary}: {path}")
        else:
            print(f"  {YELLOW}MISS{ENDC} {binary} (optional)")

    print()
    if REPORTS_DIR.exists():
        n = len(list(REPORTS_DIR.rglob("*.json")))
        print(f"  {GREEN}OK{ENDC}   reports/ ({n} report files)")
    else:
        print(f"  {DIM}--{ENDC}   reports/ (belum ada)")
    pause()


# ============================================================
# REPORT VIEWER — MAIN
# ============================================================
def menu_reports(cfg):
    """List report + view isi langsung tanpa keluar menu."""
    while True:
        header("[9] SAVED REPORTS")
        REPORTS_DIR.mkdir(exist_ok=True)
        reports = sorted(REPORTS_DIR.rglob("report_mhlscan_*.json"),
                         key=lambda x: x.stat().st_mtime, reverse=True)[:20]
        if not reports:
            print(f"  {YELLOW}Tidak ada report tersimpan{ENDC}")
            print(f"  {DIM}Lokasi: {REPORTS_DIR}{ENDC}")
            print()
            print(f"  {CYAN}[m] Migrasi report lama dari root{ENDC}")
            print(f"  {CYAN}[0] Kembali{ENDC}")
            try:
                c = input(f"\n  {BOLD}Pilih [m, 0]: {ENDC}").strip().lower()
            except (EOFError, KeyboardInterrupt):
                return
            if c == "m":
                _migrate_reports()
                pause()
            elif c == "0" or not c:
                return
            continue

        for i, r in enumerate(reports, 1):
            try:
                size = r.stat().st_size
                rel = r.relative_to(REPORTS_DIR)
            except Exception:
                rel = r.name
                size = 0
            # Summary dari JSON
            try:
                data = json.loads(r.read_text())
                if isinstance(data, list):
                    n_targets = len(data)
                    n_findings = sum(len(t.get("findings", [])) for t in data)
                    n_vulns = sum(len(t.get("vulnerabilities", [])) for t in data)
                else:
                    n_targets = 1
                    n_findings = len(data.get("findings", []))
                    n_vulns = len(data.get("vulnerabilities", []))
                summary = f"{n_targets}t {n_findings}f {n_vulns}v"
            except Exception:
                summary = "?"
            mtime = datetime.fromtimestamp(r.stat().st_mtime).strftime("%m-%d %H:%M")
            print(f"  [{i:2}] {str(rel):<50} {DIM}{mtime} · {summary} · {size//1024}KB{ENDC}")

        print()
        print(f"  {CYAN}[v] Lihat · [o] Buka browser · [d] Hapus · [m] Migrasi · [a] Arsip · [0] Kembali{ENDC}")
        try:
            c = input(f"  {BOLD}Pilih [1-{len(reports)}, v, o, d, m, a, 0]: {ENDC}").strip().lower()
        except (EOFError, KeyboardInterrupt):
            return

        if c == "0" or not c:
            return
        elif c == "v":
            _view_report(reports)
        elif c == "o":
            _open_report(reports)
        elif c == "d":
            _delete_report(reports)
        elif c == "m":
            _migrate_reports()
            pause()
        elif c == "a":
            n = _archive_old_reports(months=6)
            print(f"  {GREEN}[+] {n} file diarsipkan ke reports/archive/{ENDC}")
            pause()
        else:
            try:
                idx = int(c) - 1
                if 0 <= idx < len(reports):
                    _show_report_content(reports[idx])
            except ValueError:
                pass


def _view_report(reports):
    try:
        n = input(f"  {BOLD}Nomor report [1-{len(reports)}]: {ENDC}").strip()
        idx = int(n) - 1
        if 0 <= idx < len(reports):
            _show_report_content(reports[idx])
    except (ValueError, EOFError, KeyboardInterrupt):
        pass


def _show_report_content(report_path):
    """Tampilkan isi report (JSON/MD/HTML/ringkasan)."""
    while True:
        header(f"[VIEW] {report_path.relative_to(REPORTS_DIR) if REPORTS_DIR in report_path.parents else report_path.name}")
        print(f"  {CYAN}[1]{ENDC} Ringkasan (summary)")
        print(f"  {CYAN}[2]{ENDC} Findings + Vulnerabilities")
        print(f"  {CYAN}[3]{ENDC} Raw JSON (paged)")
        print(f"  {CYAN}[4]{ENDC} Markdown (paged)")
        print(f"  {CYAN}[5]{ENDC} HTML di browser")
        print(f"  {CYAN}[0]{ENDC} Kembali")
        try:
            c = input(f"  {BOLD}Pilih [0-5]: {ENDC}").strip()
        except (EOFError, KeyboardInterrupt):
            return

        if c == "0":
            return
        elif c == "1":
            _show_summary(report_path)
            pause()
        elif c == "2":
            _show_findings(report_path)
            pause()
        elif c == "3":
            _show_raw_json(report_path)
        elif c == "4":
            _show_markdown(report_path)
        elif c == "5":
            _open_in_browser(report_path)


def _load_report(report_path):
    try:
        data = json.loads(report_path.read_text())
        return data if isinstance(data, list) else [data]
    except Exception as e:
        print(f"  {RED}[!] Gagal baca JSON: {e}{ENDC}")
        return []


def _show_summary(report_path):
    data = _load_report(report_path)
    if not data:
        return
    total_f = sum(len(t.get("findings", [])) for t in data)
    total_v = sum(len(t.get("vulnerabilities", [])) for t in data)
    print()
    print(f"  {BOLD}Report:{ENDC} {report_path.name}")
    print(f"  {BOLD}Target:{ENDC} {len(data)}")
    print(f"  {BOLD}Findings:{ENDC} {total_f}")
    print(f"  {BOLD}Vulnerabilities:{ENDC} {total_v}")
    print()
    # Per severity
    sev_count = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
    for t in data:
        for item in (t.get("findings", []) + t.get("vulnerabilities", [])):
            sev = (item.get("severity") or "info").lower()
            sev_count[sev] = sev_count.get(sev, 0) + 1
    print(f"  {BOLD}By severity:{ENDC}")
    for sev, count in sev_count.items():
        if count > 0:
            color = {"critical": RED, "high": RED, "medium": YELLOW,
                     "low": BLUE, "info": CYAN}.get(sev, ENDC)
            print(f"    {color}{sev:<10}{ENDC} {count}")
    print()
    print(f"  {BOLD}Per target:{ENDC}")
    for t in data:
        n_f = len(t.get("findings", []))
        n_v = len(t.get("vulnerabilities", []))
        stack = t.get("stack", "?")
        target_str = t.get("target", "?")
        print(f"    {CYAN}{target_str}{ENDC}")
        print(f"      stack={stack} · findings={n_f} · vulns={n_v}")


def _show_findings(report_path):
    data = _load_report(report_path)
    if not data:
        return
    print()
    for t in data:
        target = t.get("target", "?")
        print(f"  {BOLD}{CYAN}{target}{ENDC}")
        findings = t.get("findings", [])
        vulns = t.get("vulnerabilities", [])
        if not findings and not vulns:
            print(f"    {DIM}(tidak ada temuan){ENDC}")
            continue
        if findings:
            print(f"    {CYAN}Findings ({len(findings)}):{ENDC}")
            for f in findings:
                sev = (f.get("severity") or "info").lower()
                color = {"critical": RED, "high": RED, "medium": YELLOW,
                         "low": BLUE, "info": CYAN}.get(sev, ENDC)
                print(f"      {color}[{sev:>8}]{ENDC} {f.get('name', '?')[:60]}")
                if f.get("evidence"):
                    print(f"        {DIM}{f['evidence'][:100]}{ENDC}")
        if vulns:
            print(f"    {RED}Vulnerabilities ({len(vulns)}):{ENDC}")
            for v in vulns:
                sev = (v.get("severity") or "info").lower()
                color = {"critical": RED, "high": RED, "medium": YELLOW,
                         "low": BLUE, "info": CYAN}.get(sev, ENDC)
                print(f"      {color}[{sev:>8}]{ENDC} {v.get('id', '?')} {v.get('name', '')[:50]}")
                if v.get("verified_rce"):
                    print(f"        {GREEN}✓ VERIFIED RCE{ENDC}")


def _show_raw_json(report_path):
    try:
        content = report_path.read_text()
    except Exception as e:
        print(f"  {RED}[!] {e}{ENDC}")
        return
    _paged_view(content, "JSON", report_path.name)


def _show_markdown(report_path):
    md_path = report_path.with_suffix(".md")
    if not md_path.exists():
        print(f"  {YELLOW}[!] File .md tidak ada{ENDC}")
        pause()
        return
    try:
        content = md_path.read_text()
    except Exception as e:
        print(f"  {RED}[!] {e}{ENDC}")
        pause()
        return
    _paged_view(content, "Markdown", md_path.name)


def _paged_view(content, title, name=""):
    lines = content.splitlines()
    total = len(lines)
    page_size = 40
    page = 0
    max_page = max(0, (total - 1) // page_size)

    while True:
        clr()
        header(f"[{title}] {name}")
        start = page * page_size
        end = min(start + page_size, total)
        for i, line in enumerate(lines[start:end], start + 1):
            print(f"  {DIM}{i:5}{ENDC} {line}")
        print()
        print(f"  {DIM}Halaman {page + 1}/{max_page + 1} · baris {start + 1}-{end} dari {total}{ENDC}")
        print(f"  {CYAN}[n] Next · [p] Prev · [q] Quit{ENDC}")
        try:
            c = input(f"  {BOLD}Pilih: {ENDC}").strip().lower()
        except (EOFError, KeyboardInterrupt):
            return
        if c == "q" or c == "0":
            return
        elif c == "n" and page < max_page:
            page += 1
        elif c == "p" and page > 0:
            page -= 1


def _open_report(reports):
    try:
        n = input(f"  {BOLD}Nomor report [1-{len(reports)}]: {ENDC}").strip()
        idx = int(n) - 1
        if 0 <= idx < len(reports):
            _open_in_browser(reports[idx])
    except (ValueError, EOFError, KeyboardInterrupt):
        pass


def _open_in_browser(report_path):
    html_path = report_path.with_suffix(".html")
    if not html_path.exists():
        print(f"  {YELLOW}[!] File .html tidak ada{ENDC}")
        pause()
        return
    try:
        import webbrowser
        url = "file://" + str(html_path.absolute())
        print(f"  {CYAN}[*] Membuka: {url}{ENDC}")
        webbrowser.open(url)
        print(f"  {GREEN}[+] Dibuka di browser{ENDC}")
    except Exception as e:
        print(f"  {RED}[!] Gagal buka browser: {e}{ENDC}")
        print(f"  {YELLOW}Path manual: {html_path}{ENDC}")
    pause()


def _delete_report(reports):
    try:
        n = input(f"  {BOLD}Nomor report yang dihapus [1-{len(reports)}]: {ENDC}").strip()
        idx = int(n) - 1
        if not (0 <= idx < len(reports)):
            return
        r = reports[idx]
        confirm = input(f"  {YELLOW}Hapus {r.stem}? [y/N]: {ENDC}").strip().lower()
        if confirm != "y":
            return
        deleted = 0
        for ext in (".json", ".md", ".html", ".sarif"):
            p = r.with_suffix(ext)
            if p.exists():
                p.unlink()
                deleted += 1
        print(f"  {GREEN}[+] {deleted} file dihapus{ENDC}")
        pause()
    except (ValueError, EOFError, KeyboardInterrupt):
        pass


def _migrate_reports():
    """Migrasi report lama dari root ke reports/YYYY-MM/."""
    import re
    REPORTS_DIR.mkdir(exist_ok=True)
    existing = list(SCRIPT_DIR.glob("report_mhlscan_*.json"))
    if not existing:
        print(f"  {YELLOW}[!] Tidak ada report lama di root{ENDC}")
        return 0
    migrated = 0
    for json_file in existing:
        m = re.search(r'report_mhlscan_(\d{4})(\d{2})(\d{2})_\d{6}', json_file.name)
        if not m:
            continue
        subdir = REPORTS_DIR / f"{m.group(1)}-{m.group(2)}"
        subdir.mkdir(exist_ok=True)
        stem = json_file.stem
        for ext in (".json", ".md", ".html", ".sarif"):
            src = SCRIPT_DIR / f"{stem}{ext}"
            if src.exists():
                dst = subdir / src.name
                if dst.exists():
                    dst = subdir / f"{stem}_dup{ext}"
                shutil.move(str(src), str(dst))
        migrated += 1
    print(f"  {GREEN}[+] {migrated} report dimigrasi ke reports/{ENDC}")
    return migrated


def _archive_old_reports(months=6):
    """Pindahkan report > N bulan ke reports/archive/."""
    if not REPORTS_DIR.exists():
        return 0
    archive_dir = REPORTS_DIR / "archive"
    archive_dir.mkdir(exist_ok=True)
    cutoff = datetime.now() - timedelta(days=months * 30)
    moved = 0
    for subdir in REPORTS_DIR.iterdir():
        if not subdir.is_dir() or subdir.name == "archive":
            continue
        try:
            year, month = subdir.name.split("-")
            sub_date = datetime(int(year), int(month), 1)
        except (ValueError, IndexError):
            continue
        if sub_date >= cutoff:
            continue
        for f in subdir.iterdir():
            if f.is_file():
                dst = archive_dir / f.name
                if dst.exists():
                    dst = archive_dir / f"{f.stem}_{subdir.name}{f.suffix}"
                shutil.move(str(f), str(dst))
                moved += 1
        try:
            subdir.rmdir()
        except OSError:
            pass
    return moved


# ============================================================
# EXPLOIT DB / PAYLOAD LIST
# ============================================================
def menu_exploit_list(cfg):
    header("[10] EXPLOIT DB LIST")
    try:
        import _exploits_db
        st = _exploits_db.status()
        print(f"  Total: {st['total_cves']} CVE")
        print(f"  KEV:   {st['kev_count']}")
        print(f"  Auto:  {st['exploitable_count']}")
        print()
        for cid in sorted(_exploits_db.list_cves()):
            info = _exploits_db.get_cve(cid)
            kev = "[KEV]" if info.get("kev") else "     "
            auto = "[AUTO]" if info.get("exploit") else "      "
            print(f"  {info['severity']:<8} {cid:<18} {kev} {auto} {info['name'][:50]}")
    except Exception as e:
        print(f"  {RED}[!] {e}{ENDC}")
    pause()


def menu_payload_list(cfg):
    header("[11] PAYLOAD LIST")
    try:
        import _payload_gen
        st = _payload_gen.status()
        print(f"  Payloads: {st['payloads']}")
        print(f"  Encoders: {st['encoders']}")
        print(f"  Formats:  {st['formats']}")
        print(f"  msfvenom: {'OK' if st['msfvenom'] else 'NOT INSTALLED'}")
        print()
        print("  Payloads:")
        for p in st["catalog"]["payloads"]:
            info = _payload_gen.PAYLOAD_CATALOG.get(p, {})
            print(f"    - {p:<30} {info.get('note', '')[:50]}")
        print()
        print(f"  Encoders: {', '.join(st['catalog']['encoders'])}")
        print(f"  Formats : {', '.join(st['catalog']['formats'])}")
    except Exception as e:
        print(f"  {RED}[!] {e}{ENDC}")
    pause()


def menu_generate_payload(cfg):
    header("[12] GENERATE PAYLOAD")
    try:
        import _payload_gen
        print("  Available payloads:")
        for p in _payload_gen.list_payloads():
            print(f"    - {p}")
        print()
        name = input(f"{BOLD}Payload name: {ENDC}").strip()
        if not name:
            return
        lhost = input("LHOST: ").strip()
        lport = input("LPORT [4444]: ").strip() or "4444"
        try:
            lport = int(lport)
        except ValueError:
            lport = 4444
        encoder = input("Encoder (kosong=none): ").strip() or None
        fmt = input("Format [raw]: ").strip() or "raw"

        r = _payload_gen.generate(name, lhost=lhost, lport=lport,
                                  encoder=encoder, fmt=fmt)
        if r.get("success"):
            print(f"\n{GREEN}[+] Size: {r.get('raw_size')} bytes{ENDC}")
            if r.get("encoded"):
                print(f"{GREEN}[+] Encoder: {r['encoded']}{ENDC}")
            print(f"{GREEN}[+] Format: {r['format']}{ENDC}\n")
            print(r["payload"])
        else:
            print(f"\n{RED}[!] {r.get('error')}{ENDC}")
    except Exception as e:
        print(f"  {RED}[!] {e}{ENDC}")
    pause()


# ============================================================
# MAIN MENU
# ============================================================
def show_main(cfg):
    clr()
    print(f"""{RED}{BOLD}

         M H L S C A N   v9.0
         Interactive Security Scanner
         by sigit-hdteamlabs

{ENDC}""")
    print(f"  {CYAN}SCAN MODES{ENDC}")
    print(f"    {BOLD}[1]{ENDC}  Single Target           {DIM}URL / IP / Domain{ENDC}")
    print(f"    {BOLD}[2]{ENDC}  Domain + Subdomain      {DIM}Enumerate + scan semua{ENDC}")
    print(f"    {BOLD}[3]{ENDC}  IP Range / CIDR         {DIM}Scan blok + live detect{ENDC}")
    print(f"    {BOLD}[4]{ENDC}  By Country (GeoIP)      {DIM}Scan IP dari negara{ENDC}")
    print(f"    {BOLD}[5]{ENDC}  Batch from File         {DIM}Scan list dari .txt{ENDC}")
    print()
    print(f"  {CYAN}MAINTENANCE{ENDC}")
    print(f"    {BOLD}[6]{ENDC}  Update CVE Database     {DIM}Sinkronisasi Nuclei + CVE{ENDC}")
    print(f"    {BOLD}[7]{ENDC}  Settings                {DIM}Konfigurasi scan{ENDC}")
    print()
    print(f"  {CYAN}UTILITY{ENDC}")
    print(f"    {BOLD}[8]{ENDC}  Check Dependencies      {DIM}Verifikasi environment{ENDC}")
    print(f"    {BOLD}[9]{ENDC}  View Reports            {DIM}Lihat report langsung{ENDC}")
    print(f"    {BOLD}[10]{ENDC} Exploit DB List         {DIM}30 CVE dengan checker{ENDC}")
    print(f"    {BOLD}[11]{ENDC} Payload List            {DIM}Shellcode + encoder{ENDC}")
    print(f"    {BOLD}[12]{ENDC} Generate Payload        {DIM}Buat shellcode{ENDC}")
    print(f"    {BOLD}[0]{ENDC}  Exit")
    print()
    print(f"  {DIM}Current:{ENDC} sev={BOLD}{cfg['severity']}{ENDC}  "
          f"workers={BOLD}{cfg['workers']}{ENDC}  "
          f"stealth={BOLD}{'ON' if cfg['stealth'] else 'OFF'}{ENDC}  "
          f"xss={BOLD}{'ON' if cfg.get('xss') else 'OFF'}{ENDC}  "
          f"auto-exploit={BOLD}{'ON' if cfg.get('auto_exploit') else 'OFF'}{ENDC}")
    print()


def main():
    cfg = load_config()
    while True:
        show_main(cfg)
        c = input(f"{BOLD}Pilih menu [0-12]: {ENDC}").strip()
        if c == "0":
            print(f"\n{GREEN}Sampai jumpa!{ENDC}\n")
            return 0
        elif c == "1":
            menu_single(cfg)
        elif c == "2":
            menu_domain(cfg)
        elif c == "3":
            menu_cidr(cfg)
        elif c == "4":
            menu_country(cfg)
        elif c == "5":
            menu_file(cfg)
        elif c == "6":
            menu_update(cfg)
        elif c == "7":
            menu_settings(cfg)
        elif c == "8":
            menu_check(cfg)
        elif c == "9":
            menu_reports(cfg)
        elif c == "10":
            menu_exploit_list(cfg)
        elif c == "11":
            menu_payload_list(cfg)
        elif c == "12":
            menu_generate_payload(cfg)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print(f"\n{YELLOW}[!] Dihentikan{ENDC}")
        sys.exit(0)
