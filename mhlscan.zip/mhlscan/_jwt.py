# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_jwt.py - JWT analysis: decode, detect weakness, alg=none, weak secret."""

import base64
import hashlib
import hmac
import json
import re


def _b64url_decode(s):
    s = s + "=" * (4 - len(s) % 4)
    return base64.urlsafe_b64decode(s)


def _b64url_encode(b):
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def decode_jwt(token):
    """Decode JWT tanpa verify. Return dict {header, payload, signature, valid}."""
    if not token:
        return {"valid": False, "error": "empty"}
    parts = token.split(".")
    if len(parts) != 3:
        return {"valid": False, "error": "not 3 parts"}
    try:
        header = json.loads(_b64url_decode(parts[0]))
        payload = json.loads(_b64url_decode(parts[1]))
        return {
            "valid": True,
            "header": header,
            "payload": payload,
            "signature": parts[2],
            "raw": token,
        }
    except Exception as e:
        return {"valid": False, "error": str(e)}


WEAK_SECRETS = [
    "secret", "password", "123456", "1234567890", "qwerty",
    "admin", "root", "letmein", "welcome", "changeme",
    "jwt", "jwt_secret", "jwtsecret", "jwt-secret",
    "key", "apikey", "api_key", "token", "default",
    "test", "dev", "development", "prod", "production",
    "your-256-bit-secret", "your_jwt_secret", "s3cr3t",
    "secretkey", "secret_key", "supersecret", "topsecret",
    "password123", "admin123", "1234567890", "12345",
    "django-insecure", "flask-secret-key",
]


def test_none_algorithm(token):
    """Test alg=none: ubah header alg=none, hapus signature."""
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None
        header = json.loads(_b64url_decode(parts[0]))
        payload = json.loads(_b64url_decode(parts[1]))
        header["alg"] = "none"
        new_header = _b64url_encode(json.dumps(header, separators=(",", ":")).encode())
        new_payload = _b64url_encode(json.dumps(payload, separators=(",", ":")).encode())
        return f"{new_header}.{new_payload}."
    except Exception:
        return None


def test_alg_change(token, new_alg="HS256"):
    """Ganti alg ke HS256, signature kosong (server akan tolak, tapi berguna kalau tidak)."""
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None
        header = json.loads(_b64url_decode(parts[0]))
        payload = json.loads(_b64url_decode(parts[1]))
        header["alg"] = new_alg
        new_header = _b64url_encode(json.dumps(header, separators=(",", ":")).encode())
        new_payload = _b64url_encode(json.dumps(payload, separators=(",", ":")).encode())
        return f"{new_header}.{new_payload}.{parts[2]}"
    except Exception:
        return None


def test_weak_secret(token, secrets=None):
    """Bruteforce HMAC secret terhadap wordlist kecil."""
    secrets = secrets or WEAK_SECRETS
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None
        signing_input = f"{parts[0]}.{parts[1]}".encode()
        sig_bytes = _b64url_decode(parts[2])
        header = json.loads(_b64url_decode(parts[0]))
        alg = header.get("alg", "HS256")
        hash_fn = {"HS256": hashlib.sha256,
                   "HS384": hashlib.sha384,
                   "HS512": hashlib.sha512}.get(alg)
        if not hash_fn:
            return None

        for s in secrets:
            try:
                computed = hmac.new(s.encode(), signing_input, hash_fn).digest()
                if hmac.compare_digest(computed, sig_bytes):
                    return {"secret": s, "alg": alg}
            except Exception:
                continue
    except Exception:
        pass
    return None


def analyze_jwt(token):
    """Analisa lengkap JWT.

    Return dict {
        valid, header, payload, weaknesses: [...], findings: [...]
    }
    """
    dec = decode_jwt(token)
    if not dec.get("valid"):
        return {"valid": False, "error": dec.get("error")}

    findings = []
    weaknesses = []

    header = dec["header"]
    payload = dec["payload"]
    alg = header.get("alg", "").lower()

    # 1. alg=none
    if alg == "none":
        weaknesses.append("alg=none (no signature)")
        findings.append({"id": "JWT-ALG-NONE", "name": "alg=none accepted",
                         "severity": "critical", "evidence": "Header alg=none"})

    # 2. alg=HS* tapi secret lemah
    if alg.startswith("hs"):
        weak = test_weak_secret(token)
        if weak:
            weaknesses.append(f"weak secret: {weak['secret']}")
            findings.append({"id": "JWT-WEAK-SECRET",
                             "name": "Weak JWT secret",
                             "severity": "critical",
                             "evidence": f"Secret: {weak['secret']}"})

    # 3. Klaim sensitif di payload
    sensitive_claims = ["password", "passwd", "secret", "key", "token",
                        "credit_card", "ssn", "api_key"]
    for k in sensitive_claims:
        if k in str(payload).lower():
            weaknesses.append(f"sensitive data: {k}")
            findings.append({"id": "JWT-SENSITIVE",
                             "name": f"Sensitive claim: {k}",
                             "severity": "high",
                             "evidence": f"Found '{k}' in payload"})

    # 4. exp tidak ada
    if "exp" not in payload:
        findings.append({"id": "JWT-NO-EXP", "name": "No expiration (exp)",
                         "severity": "medium", "evidence": "No exp claim"})

    # 5. iat/exp tidak masuk akal
    try:
        if "exp" in payload and "iat" in payload:
            if payload["exp"] < payload["iat"]:
                findings.append({"id": "JWT-EXP-BEFORE-IAT",
                                 "name": "exp < iat",
                                 "severity": "medium"})
    except Exception:
        pass

    # 6. kid header (potential injection)
    if "kid" in header:
        findings.append({"id": "JWT-KID", "name": "kid header present",
                         "severity": "info",
                         "evidence": f"kid={header['kid']}"})

    # 7. Tidak ada signature
    if not dec.get("signature"):
        findings.append({"id": "JWT-NO-SIG", "name": "Empty signature",
                         "severity": "high"})

    return {
        "valid": True,
        "header": header,
        "payload": payload,
        "weaknesses": weaknesses,
        "findings": findings,
    }


def extract_jwts_from_text(text):
    """Ekstrak JWT dari body/HTML."""
    if not text:
        return []
    pattern = r'eyJ[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+'
    return list(set(re.findall(pattern, text)))[:10]


def extract_jwts_from_headers(headers):
    """Ekstrak JWT dari header (Authorization, Set-Cookie, dll)."""
    if not headers:
        return []
    tokens = []
    for k, v in headers.items():
        if isinstance(v, bytes):
            v = v.decode("utf-8", "ignore")
        tokens.extend(extract_jwts_from_text(str(v)))
    return list(set(tokens))[:10]


def status():
    return {
        "weak_secrets": len(WEAK_SECRETS),
        "tests": ["alg_none", "weak_secret", "sensitive_claims",
                  "exp_missing", "kid_present", "empty_signature"],
    }
