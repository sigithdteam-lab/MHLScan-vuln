# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_netdev.py - Network device detection (Mikrotik, Cisco, Juniper, Edgecore, dll)."""
import socket, re, ssl
from urllib.parse import urlparse

NL = chr(10)
CRLF = bytes([13, 10])

DEVICE_SIGNATURES = {
    "mikrotik_routeros": [(r'routeros', 'any'), (r'mikrotik', 'any'), (r'webfig', 'any')],
    "cisco_ios_xe": [(r'cisco.*ios.*xe', 'any'), (r'ios-xe', 'any'), (r'ciscowebui', 'any')],
    "cisco_ios": [(r'cisco', 'any'), (r'ciscowebui', 'any')],
    "cisco_asa": [(r'cisco.*adaptive', 'any'), (r'webvpn', 'any')],
    "juniper_junos": [(r'juniper', 'any'), (r'junos', 'any'), (r'jweb', 'any')],
    "edgecore": [(r'edge[- ]?core', 'any'), (r'edgecore', 'any')],
    "arista_eos": [(r'arista', 'any'), (r'eos', 'any')],
    "huawei": [(r'huawei', 'any'), (r'quidway', 'any'), (r'echolife', 'any')],
    "fortinet_fortigate": [(r'fortinet', 'any'), (r'fortigate', 'any'), (r'fortiweb', 'any')],
    "paloalto_panos": [(r'palo alto', 'any'), (r'panos', 'any')],
    "ubiquiti": [(r'ubiquiti', 'any'), (r'unifi', 'any'), (r'airmax', 'any')],
    "tp_link": [(r'tp-link', 'any')],
    "zte": [(r'zte', 'any'), (r'zxhn', 'any')],
    "openwrt": [(r'openwrt', 'any'), (r'luci', 'any')],
    "pfsense": [(r'pfsense', 'any')],
}

NETDEV_PORTS = {
    23: "telnet", 161: "snmp", 830: "netconf",
    2000: "cisco-sccp", 8291: "mikrotik-winbox",
    8728: "mikrotik-api", 8729: "mikrotik-api-ssl",
    4443: "cisco-anyconnect", 4433: "juniper-ssl",
}

# Fallback hints (jika cache Nuclei kosong / belum update)
NETDEV_CVES_FALLBACK = {
    "mikrotik_routeros": ["CVE-2018-14847", "CVE-2019-3924", "CVE-2023-30799"],
    "cisco_ios": ["CVE-2023-20198", "CVE-2023-20273", "CVE-2024-20399"],
    "cisco_ios_xe": ["CVE-2023-20198", "CVE-2023-20273", "CVE-2024-20399"],
    "cisco_asa": ["CVE-2020-3187"],
    "juniper_junos": ["CVE-2023-36844", "CVE-2023-36845", "CVE-2024-21591"],
    "fortinet_fortigate": ["CVE-2018-13379", "CVE-2022-40684", "CVE-2024-55591"],
    "paloalto_panos": ["CVE-2024-0012", "CVE-2024-9474"],
    "huawei": ["CVE-2017-17215", "CVE-2018-10561"],
    "zte": ["CVE-2014-2321"],
    "arista_eos": ["CVE-2020-10188"],
}

def get_netdev_cves(device_type, verbose=False):
    try:
        import _nuclei
        idx = _nuclei.load_index()
        if idx:
            keyword_map = {
                "mikrotik_routeros": "mikrotik",
                "cisco_ios": "cisco", "cisco_ios_xe": "cisco",
                "cisco_asa": "cisco asa",
                "juniper_junos": "juniper",
                "huawei": "huawei",
                "fortinet_fortigate": "fortinet",
                "paloalto_panos": "palo alto",
                "arista_eos": "arista",
                "edgecore": "edgecore",
                "ubiquiti": "ubiquiti",
                "openwrt": "openwrt",
                "pfsense": "pfsense",
                "tp_link": "tp-link",
                "zte": "zte",
            }
            keyword = keyword_map.get(device_type)
            if keyword:
                found = []
                for e in idx:
                    name = (e.get("Info", {}).get("Name") or "").lower()
                    path = (e.get("file_path") or "").lower()
                    cve_id = e.get("ID", "")
                    if cve_id.startswith("CVE-") and (keyword in name or keyword in path):
                        sev = (e.get("Info", {}).get("Severity") or "").lower()
                        if sev in ("critical", "high"):
                            found.append(cve_id)
                if found:
                    if verbose:
                        print(f"    [dynamic] {device_type}: {len(found)} CVE dari Nuclei cache")
                    return found[:20]
    except Exception as e:
        if verbose:
            print(f"    [dynamic] error: {e}")

    fallback = NETDEV_CVES_FALLBACK.get(device_type, [])
    if fallback and verbose:
        print(f"    [fallback] {device_type}: {len(fallback)} CVE hardcoded")
    return fallback

NETDEV_HTTP_PATHS = [
    ("/", "root"),
    ("/webfig/", "mikrotik_webfig"),
    ("/winbox/", "mikrotik_winbox"),
    ("/webui/", "cisco_webui"),
    ("/webui/logoutconfirm.html?logon_hash=1", "cisco_iosxe_webui"),
    ("/admin/", "generic_admin"),
    ("/jweb/", "juniper_jweb"),
    ("/cgi-bin/luci", "openwrt_luci"),
    ("/+CSCOE+/logon.html", "cisco_anyconnect"),
    ("/login", "login_page"),
    ("/login.jsp", "juniper_login"),
    ("/remote/login", "fortinet_ssl_vpn"),
    ("/global-protect/login.esp", "paloalto_gp"),
]


def grab_banner_tcp(host, port, timeout=3):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect((host, port))
        if port == 23:
            s.send(CRLF)
        try:
            data = s.recv(2048)
        except socket.timeout:
            data = b""
        s.close()
        return data.decode("utf-8", errors="ignore").strip() if data else None
    except Exception:
        return None


def probe_snmp(host, timeout=3):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(timeout)
        pkt = (b'\x30\x26\x02\x01\x01\x04\x06public'
               b'\xa0\x19\x02\x04\x00\x00\x00\x01\x02\x01\x00'
               b'\x02\x01\x00\x30\x0b\x30\x09\x06\x05\x2b\x06'
               b'\x01\x02\x01\x01\x05\x00')
        sock.sendto(pkt, (host, 161))
        try:
            data, _ = sock.recvfrom(2048)
            sock.close()
            if data and len(data) > 10:
                text = data.decode("utf-8", errors="ignore").lower()
                for vendor in ["mikrotik", "cisco", "juniper", "huawei",
                               "edgecore", "arista", "linux", "fortinet"]:
                    if vendor in text:
                        return {"community": "public", "vendor": vendor,
                                "raw": data[:200].decode("utf-8", errors="ignore")}
                return {"community": "public", "vendor": "unknown",
                        "raw": data[:200].decode("utf-8", errors="ignore")}
        except socket.timeout:
            pass
        sock.close()
    except Exception:
        pass
    return None


def probe_http_devices(url, pool, timeout=5):
    results = []
    for path, label in NETDEV_HTTP_PATHS:
        try:
            r = pool.request('GET', url.rstrip('/') + path,
                            timeout=timeout, redirect=False)
            if r.status in (200, 401, 403, 302):
                body = (r.data or b'')[:8192].decode('utf-8', errors='ignore').lower()
                headers = str(r.headers).lower()
                combined = body + " " + headers
                for device, sigs in DEVICE_SIGNATURES.items():
                    for pattern, _ in sigs:
                        if re.search(pattern, combined, re.IGNORECASE):
                            results.append({
                                "device": device, "path": path,
                                "status": r.status,
                                "evidence": f"signature '{pattern}' di {path}",
                            })
                            break
        except Exception:
            pass
    return results


def detect_netdev(url, open_ports, pool, timeout=5):
    host = urlparse(url).hostname or url
    result = {
        "is_network_device": False, "device_type": None, "vendor": None,
        "evidence": [], "open_netdev_ports": [], "snmp": None,
        "banners": {}, "http_probes": [], "cves_hint": [],
    }

    # 1. Port khas network device
    for port, svc in NETDEV_PORTS.items():
        if port in open_ports:
            result["open_netdev_ports"].append({"port": port, "service": svc})
            result["evidence"].append(f"port {port} ({svc}) terbuka")

    # 2. HTTP device signature
    http_hits = probe_http_devices(url, pool, timeout)
    if http_hits:
        result["http_probes"] = http_hits
        result["device_type"] = http_hits[0]["device"]
        result["vendor"] = http_hits[0]["device"].split("_")[0]
        result["evidence"].append(http_hits[0]["evidence"])
        result["is_network_device"] = True

    # 3. SNMP
    if 161 in open_ports:
        snmp = probe_snmp(host, timeout)
        if snmp:
            result["snmp"] = snmp
            result["evidence"].append(f"SNMP public responds: {snmp['vendor']}")
            if not result["is_network_device"]:
                result["vendor"] = snmp["vendor"]
                result["is_network_device"] = True

    # 4. TCP banner SSH/Telnet
    for port in (22, 23):
        if port in open_ports:
            banner = grab_banner_tcp(host, port, timeout)
            if banner:
                result["banners"][port] = banner
                low = banner.lower()
                for vendor in ["mikrotik", "cisco", "juniper", "huawei",
                               "edgecore", "arista", "zte"]:
                    if vendor in low:
                        result["vendor"] = vendor
                        result["evidence"].append(f"banner port {port}: {vendor}")
                        result["is_network_device"] = True

    # 5. CVE hint — dari Nuclei cache (dynamic) atau fallback
    if result["device_type"]:
        result["cves_hint"] = get_netdev_cves(result["device_type"])
    elif result["vendor"]:
        # Coba map vendor ke device_type yang lebih umum
        for dt in NETDEV_CVES_FALLBACK:
            if result["vendor"] in dt:
                result["cves_hint"] = get_netdev_cves(dt)
                break

    return result
