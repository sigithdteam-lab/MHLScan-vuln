# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_payloads.py - Service payloads (12 services)."""

import socket
import re

CRLF = bytes([13, 10])


def _send_recv(host, port, payload, timeout=5, recv=4096):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect((host, port))
        if payload:
            s.send(payload)
        data = s.recv(recv)
        s.close()
        return data
    except Exception:
        return None


def check_redis(host, port=6379, timeout=5):
    r = _send_recv(host, port, b"PING" + CRLF, timeout)
    if r and b"+PONG" in r:
        info = _send_recv(host, port, b"INFO server" + CRLF, timeout)
        ver = None
        if info:
            m = re.search(rb"redis_version:([\d.]+)", info)
            if m:
                ver = m.group(1).decode()
        return {"status": "vulnerable", "service": "redis", "port": port,
                "details": "Redis unauth" + (f" v{ver}" if ver else ""),
                "version": ver, "severity": "high"}
    return None


def check_memcached(host, port=11211, timeout=5):
    r = _send_recv(host, port, b"stats" + CRLF, timeout)
    if r and b"STAT " in r:
        m = re.search(rb"STAT version ([\d.]+)", r)
        ver = m.group(1).decode() if m else None
        return {"status": "vulnerable", "service": "memcached", "port": port,
                "details": "Memcached unauth" + (f" v{ver}" if ver else ""),
                "version": ver, "severity": "high"}
    return None


def check_elasticsearch(host, port=9200, timeout=5):
    r = _send_recv(host, port, b"GET / HTTP/1.0" + CRLF + CRLF, timeout)
    if r and b'"cluster_name"' in r.lower() and b'"version"' in r.lower():
        return {"status": "vulnerable", "service": "elasticsearch", "port": port,
                "details": "ES unauth cluster info", "severity": "high"}
    return None


def check_mongodb(host, port=27017, timeout=5):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect((host, port))
        query = b"admin.$cmd" + bytes([0]) + bytes([0, 0, 0, 0]) + bytes([1, 0, 0, 0])
        bson = bytes([0x13, 0, 0, 0, 0x10]) + b"isMaster" + bytes([0]) + bytes([1, 0, 0, 0, 0])
        body = bytes([0, 0, 0, 0]) + query + bson
        total = 16 + len(body)
        hdr = bytes([total & 0xff, (total >> 8) & 0xff,
                     (total >> 16) & 0xff, (total >> 24) & 0xff,
                     0, 0, 0, 0, 0, 0, 0, 0, 0xd4, 0x07, 0, 0])
        s.send(hdr + body)
        resp = s.recv(1024)
        s.close()
        if resp and len(resp) > 20 and b"ismaster" in resp.lower():
            return {"status": "vulnerable", "service": "mongodb", "port": port,
                    "details": "MongoDB isMaster unauth", "severity": "high"}
    except Exception:
        pass
    return None


def check_mysql(host, port=3306, timeout=5):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect((host, port))
        data = s.recv(1024)
        s.close()
        if data and len(data) > 5 and data[4] == 10:
            idx = data.find(bytes([0]), 5)
            if idx > 5:
                ver = data[5:idx].decode("utf-8", "ignore")
                return {"status": "info", "service": "mysql", "port": port,
                        "details": f"MySQL {ver}", "version": ver, "severity": "info"}
    except Exception:
        pass
    return None


def check_postgresql(host, port=5432, timeout=5):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect((host, port))
        s.send(bytes([0, 0, 0, 8, 0x04, 0xd2, 0x16, 0x2f]))
        resp = s.recv(1)
        s.close()
        if resp and resp in (b"S", b"N"):
            return {"status": "info", "service": "postgresql", "port": port,
                    "details": f"PostgreSQL SSL {resp.decode()}", "severity": "info"}
    except Exception:
        pass
    return None


def check_ftp_anon(host, port=21, timeout=5):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect((host, port))
        s.recv(256)
        s.send(b"USER anonymous" + CRLF)
        s.recv(256)
        s.send(b"PASS anonymous@test.com" + CRLF)
        r2 = s.recv(256)
        s.close()
        if r2 and (b"230" in r2 or b"logged in" in r2.lower()):
            return {"status": "vulnerable", "service": "ftp", "port": port,
                    "details": "FTP anonymous login allowed", "severity": "high"}
    except Exception:
        pass
    return None


def check_docker_api(host, port=2375, timeout=5):
    r = _send_recv(host, port, b"GET /version HTTP/1.0" + CRLF + CRLF, timeout)
    if r and b'"Version"' in r and b'"ApiVersion"' in r:
        return {"status": "vulnerable", "service": "docker", "port": port,
                "details": "Docker API unauth", "severity": "critical"}
    return None


def check_telnet(host, port=23, timeout=5):
    r = _send_recv(host, port, None, timeout)
    if r:
        return {"status": "info", "service": "telnet", "port": port,
                "details": r[:100].decode("utf-8", "ignore").strip(),
                "severity": "info"}
    return None


def check_ssh(host, port=22, timeout=5):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect((host, port))
        banner = s.recv(256).decode("utf-8", "ignore").strip()
        s.close()
        if banner:
            return {"status": "info", "service": "ssh", "port": port,
                    "details": banner, "severity": "info"}
    except Exception:
        pass
    return None


def check_smb(host, port=445, timeout=5):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect((host, port))
        nb = bytes([0x00, 0x00, 0x00, 0x2f])
        smb = (bytes([0xff, 0x53, 0x4d, 0x42, 0x72]) +
               bytes([0, 0, 0, 0, 0x18, 0x53, 0xc8, 0, 0, 0, 0, 0, 0, 0, 0,
                      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                      0, 0x20]))
        s.send(nb + smb)
        data = s.recv(1024)
        s.close()

        if not data or b"\xffSMB" not in data:
            return None

        has_smb2 = b"\xfeSMB" in data
        smb1_enabled = b"\xffSMB" in data

        if has_smb2:
            return {"status": "info", "service": "smb", "port": port,
                    "details": "SMB2/3 capable (SMB1 maybe enabled)",
                    "severity": "info"}

        if smb1_enabled:
            return {"status": "info", "service": "smb", "port": port,
                    "details": "SMB1 enabled, no SMB2 (EternalBlue risk — verify patch MS17-010)",
                    "severity": "medium"}
    except Exception:
        pass
    return None


def check_vnc(host, port=5900, timeout=5):
    r = _send_recv(host, port, None, timeout)
    if r and b"RFB" in r[:20]:
        return {"status": "info", "service": "vnc", "port": port,
                "details": r[:50].decode("utf-8", "ignore").strip(),
                "severity": "info"}
    return None


CHECKERS = {
    "redis": check_redis, "memcached": check_memcached,
    "elasticsearch": check_elasticsearch, "mongodb": check_mongodb,
    "mysql": check_mysql, "postgresql": check_postgresql,
    "ftp": check_ftp_anon, "docker": check_docker_api,
    "telnet": check_telnet, "ssh": check_ssh,
    "smb": check_smb, "vnc": check_vnc,
}


def run_payloads(host, open_ports, service_map, timeout=5):
    findings = []
    for port in open_ports:
        svc = service_map.get(port, "unknown")
        if svc in CHECKERS:
            try:
                r = CHECKERS[svc](host, port, timeout)
                if r:
                    findings.append(r)
            except Exception:
                pass
    return findings
