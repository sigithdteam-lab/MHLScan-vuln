# -*- coding: utf-8 -*-
# GNU GPL License V3
# mhlscan by sigit-hdteamlabs
"""_wstg.py - WSTG v4.2 + OWASP API Top 10 hybrid.

Mode:
1. Coverage report (default): checklist semua test, tandai covered/not-covered
   berdasarkan findings yang sudah ada.
2. Eksekusi check (opsional): menjalankan probe pasif untuk test yang aman.
"""

WSTG_CATEGORIES = {
    "WSTG-INFO": {"name": "Information Gathering", "tests": [
        {"id": "WSTG-INFO-01", "name": "Search Engine Discovery"},
        {"id": "WSTG-INFO-02", "name": "Fingerprint Web Server"},
        {"id": "WSTG-INFO-05", "name": "Review Webpage Content"},
        {"id": "WSTG-INFO-08", "name": "Fingerprint Web Framework"},
    ]},
    "WSTG-CONF": {"name": "Configuration", "tests": [
        {"id": "WSTG-CONF-01", "name": "Network Infrastructure Config"},
        {"id": "WSTG-CONF-02", "name": "Application Platform Config"},
        {"id": "WSTG-CONF-04", "name": "Backup Files"},
        {"id": "WSTG-CONF-05", "name": "Admin Interfaces"},
    ]},
    "WSTG-IDNT": {"name": "Identity Management", "tests": [
        {"id": "WSTG-IDNT-01", "name": "Role Definitions"},
        {"id": "WSTG-IDNT-02", "name": "Registration Process"},
        {"id": "WSTG-IDNT-04", "name": "Account Enumeration"},
    ]},
    "WSTG-ATHN": {"name": "Authentication", "tests": [
        {"id": "WSTG-ATHN-01", "name": "Credentials Transport"},
        {"id": "WSTG-ATHN-02", "name": "Default Credentials"},
        {"id": "WSTG-ATHN-03", "name": "Weak Lock Out"},
        {"id": "WSTG-ATHN-04", "name": "Bypassing Auth"},
        {"id": "WSTG-ATHN-07", "name": "Weak Password Policy"},
    ]},
    "WSTG-ATHZ": {"name": "Authorization", "tests": [
        {"id": "WSTG-ATHZ-01", "name": "Directory Traversal"},
        {"id": "WSTG-ATHZ-02", "name": "Bypassing Authz"},
        {"id": "WSTG-ATHZ-03", "name": "Privilege Escalation"},
        {"id": "WSTG-ATHZ-04", "name": "IDOR"},
    ]},
    "WSTG-SESS": {"name": "Session Management", "tests": [
        {"id": "WSTG-SESS-01", "name": "Session Schema"},
        {"id": "WSTG-SESS-02", "name": "Cookies Attributes"},
        {"id": "WSTG-SESS-05", "name": "CSRF"},
    ]},
    "WSTG-INPV": {"name": "Input Validation", "tests": [
        {"id": "WSTG-INPV-01", "name": "Reflected XSS"},
        {"id": "WSTG-INPV-02", "name": "Stored XSS"},
        {"id": "WSTG-INPV-05", "name": "SQL Injection"},
        {"id": "WSTG-INPV-11", "name": "Code Injection"},
        {"id": "WSTG-INPV-12", "name": "Command Injection"},
        {"id": "WSTG-INPV-17", "name": "Host Header Injection"},
        {"id": "WSTG-INPV-18", "name": "SSTI"},
        {"id": "WSTG-INPV-19", "name": "SSRF"},
    ]},
    "WSTG-ERRH": {"name": "Error Handling", "tests": [
        {"id": "WSTG-ERRH-01", "name": "Improper Error Handling"},
        {"id": "WSTG-ERRH-02", "name": "Stack Traces"},
    ]},
    "WSTG-CRYP": {"name": "Cryptography", "tests": [
        {"id": "WSTG-CRYP-01", "name": "Weak TLS"},
        {"id": "WSTG-CRYP-02", "name": "Padding Oracle"},
        {"id": "WSTG-CRYP-03", "name": "Sensitive Data Unencrypted"},
    ]},
    "WSTG-BUSL": {"name": "Business Logic", "tests": [
        {"id": "WSTG-BUSL-01", "name": "Business Logic Data Validation"},
        {"id": "WSTG-BUSL-02", "name": "Forge Requests"},
        {"id": "WSTG-BUSL-05", "name": "Function Limits"},
        {"id": "WSTG-BUSL-06", "name": "Work Flow Circumvention"},
        {"id": "WSTG-BUSL-08", "name": "Upload Unexpected Files"},
    ]},
    "WSTG-CLNT": {"name": "Client-side", "tests": [
        {"id": "WSTG-CLNT-01", "name": "DOM XSS"},
        {"id": "WSTG-CLNT-02", "name": "JS Execution"},
        {"id": "WSTG-CLNT-07", "name": "CORS"},
        {"id": "WSTG-CLNT-09", "name": "Clickjacking"},
    ]},
}

API_TOP10 = {
    "API1:2023": "Broken Object Level Authorization (BOLA)",
    "API2:2023": "Broken Authentication",
    "API3:2023": "Broken Object Property Level Authorization",
    "API4:2023": "Unrestricted Resource Consumption",
    "API5:2023": "Broken Function Level Authorization",
    "API6:2023": "Unrestricted Access to Business Flows",
    "API7:2023": "Server Side Request Forgery",
    "API8:2023": "Security Misconfiguration",
    "API9:2023": "Improper Inventory Management",
    "API10:2023": "Unsafe Consumption of APIs",
}


# Mapping finding ID / nama finding -> WSTG test ID
_FINDING_TO_WSTG = [
    (r"git-config|git-head|backup-sql|env-file|env-prod|htaccess|web-config",
     ["WSTG-CONF-04"]),
    (r"admin-panel|swagger|api-docs",
     ["WSTG-CONF-05"]),
    (r"dirlist|directory listing",
     ["WSTG-CONF-01"]),
    (r"header-missing|hdr-missing",
     ["WSTG-CLNT-09"]),
    (r"xss|reflected-xss|stored-xss",
     ["WSTG-INPV-01", "WSTG-INPV-02"]),
    (r"sql|sqli|sql-inject",
     ["WSTG-INPV-05"]),
    (r"rce|command|exec",
     ["WSTG-INPV-12"]),
    (r"lfi|traversal|lfi-wplang",
     ["WSTG-ATHZ-01"]),
    (r"tls|ssl|poodle|sweet32",
     ["WSTG-CRYP-01"]),
    (r"csrf",
     ["WSTG-SESS-05"]),
    (r"jwt|bearer",
     ["WSTG-SESS-01"]),
    (r"idor",
     ["WSTG-ATHZ-04"]),
    (r"enum|users",
     ["WSTG-IDNT-04"]),
]


def compute_coverage(findings):
    """Return dict {covered: [...], uncovered: [...], percent, wstg_map}."""
    finding_blob = " ".join(
        str(f.get("id", "")) + " " + str(f.get("name", ""))
        for f in (findings or [])
    ).lower()

    covered = set()
    for pattern, tests in _FINDING_TO_WSTG:
        if any(w in finding_blob for w in pattern.split("|")):
            covered.update(tests)

    all_tests = []
    for cat_id, cat in WSTG_CATEGORIES.items():
        for t in cat["tests"]:
            all_tests.append({**t, "category": cat_id,
                              "category_name": cat["name"]})

    for t in all_tests:
        t["covered"] = t["id"] in covered

    n_total = len(all_tests)
    n_covered = sum(1 for t in all_tests if t["covered"])
    percent = round(100 * n_covered / n_total, 1) if n_total else 0.0

    return {
        "total": n_total,
        "covered": n_covered,
        "percent": percent,
        "tests": all_tests,
    }


def api_coverage(findings):
    """Estimasi coverage OWASP API Top 10 (semua ditandai belum kalau tidak ada API)."""
    blob = " ".join(
        str(f.get("id", "")) + " " + str(f.get("name", ""))
        for f in (findings or [])
    ).lower()
    result = {}
    for aid, aname in API_TOP10.items():
        result[aid] = {
            "name": aname,
            "covered": False,
            "evidence": None,
        }
    if "api" in blob or "/api/" in blob:
        for aid in ("API1:2023", "API5:2023", "API8:2023"):
            result[aid]["covered"] = True
            result[aid]["evidence"] = "API endpoint detected"
    return result
